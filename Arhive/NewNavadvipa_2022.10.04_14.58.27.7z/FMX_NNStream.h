// Nizhnyaya Navadvipa library - author Navadvipa Chandra das e-mail navadvipa.chandra.das@nizhnyaya-navadvipa.ru
#ifndef FMX_NNStreamH
#define FMX_NNStreamH
#include <System.Classes.hpp>
class PACKAGE TNNFTextStream : public TStream
{
private :
  typedef PACKAGE TStream inherited;
  TStream *fStream;
  bool fIsDeleteStream;
protected :
public :
  __fastcall TNNFTextStream( TStream *AStream );
  __fastcall ~TNNFTextStream();
  virtual int __fastcall Read( void *Buffer, int Count ) { return Stream->Read( Buffer, Count ); };
  virtual int __fastcall Write( const void *Buffer, int Count ) { return Stream->Write( Buffer, Count ); };
  virtual __int64 __fastcall Seek( const __int64 Offset, TSeekOrigin Origin ) /* overload */
  {
    return Stream->Seek( Offset, Origin );
  }; /* overload */
  bool __fastcall IsEof() { return (Position == Size); };
  bool __fastcall ReadBool();

  inline void __fastcall WriteBool( bool Value )
  {
    Write( &Value, sizeof( Value ) );
  };
  char __fastcall ReadChar();

  inline void __fastcall WriteChar( char Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  unsigned char __fastcall ReadUnsignedChar();

  inline void __fastcall WriteUnsignedChar( unsigned char Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  int __fastcall ReadInt();

  inline void __fastcall WriteInt( int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  short int __fastcall ReadShortInt();

  inline void __fastcall WriteShortInt( short int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  unsigned short int __fastcall ReadUnsignedShortInt();

  inline void __fastcall WriteUnsignedShortInt( unsigned short int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  std::size_t __fastcall ReadSizeType();

  inline void __fastcall WriteSizeType( std::size_t Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  NativeInt __fastcall ReadNativeInt();

  inline void __fastcall WriteNativeInt( NativeInt Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  unsigned int __fastcall ReadUnsignedInt();

  inline void __fastcall WriteUnsignedInt( unsigned int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  TDateTime __fastcall ReadDateTime();

  inline void __fastcall WriteDateTime( TDateTime Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  short int __fastcall ReadShort();

  inline void __fastcall WriteShort( short int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  unsigned short int __fastcall ReadUnsignedShort();

  inline void __fastcall WriteUnsignedShort( unsigned short int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  long int __fastcall ReadLongInt();

  inline void __fastcall WriteLongInt( long int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  long long int __fastcall ReadLongLongInt();

  inline void __fastcall WriteLongLongInt( long long int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  unsigned long int __fastcall ReadUnsignedLongInt();

  inline void __fastcall WriteLongInt( unsigned long int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  unsigned long long int __fastcall ReadUnsignedLongLongInt();

  inline void __fastcall WriteLongLongInt( unsigned long long int Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  float __fastcall ReadFloat();

  inline void __fastcall WriteFloat( float Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  double __fastcall ReadDouble();

  inline void __fastcall WriteDouble( double Value )
  {
    Write( &Value, sizeof( Value ) );
  };

  long double __fastcall ReadLongDouble();

  inline void __fastcall WriteLongDouble( long double Value )
  {
    Write( &Value, sizeof( Value ) );
  };
  TAlphaColor __fastcall ReadColor();
  void __fastcall WriteColor( TAlphaColor value ) { Write( &value, sizeof( value ) ); };
  TTextAlign __fastcall ReadTextAlign();
  void __fastcall WriteTextAlign( TTextAlign value ) { Write( &value, sizeof( value ) ); };
  TTextTrimming __fastcall ReadTextTrimming();
  void __fastcall WriteTextTrimming( TTextTrimming value ) { Write( &value, sizeof( value ) ); };
  String __fastcall ReadString();
  void __fastcall WriteString( const String &value );
  bool __fastcall ReadStringLine( String &S );
  AnsiString __fastcall ReadAnsiString();
  void __fastcall WriteAnsiString( const AnsiString &value );
  void __fastcall ReadBinaryData( void *Buffer );
  void __fastcall WriteBinaryData( void *Buffer, int BufSize )
    {
      Write( &BufSize, sizeof( BufSize ) );
      Write( Buffer, BufSize );
    };
  void __fastcall ReadFiler( TNNFTextStream *filer );
  void __fastcall WriteFiler( TNNFTextStream *filer );
  void __fastcall ReadFont( TFont* AFont );
  void __fastcall WriteFont( TFont* AFont );
  void __fastcall ReadTextSettings( TTextSettings* ATextSettings );
  void __fastcall WriteTextSettings( TTextSettings* ATextSettings );
  void __fastcall ReadFontColorForState( TFontColorForState* AFontColorForState );
  void __fastcall WriteFontColorForState( TFontColorForState* AFontColorForState );
  TShortCut __fastcall ReadShortCut();
  void __fastcall WriteShortCut( TShortCut value ) { Write( &value, sizeof( value ) ); };
  void __fastcall ResetVersion();
  // ��������� ������ ����� ����� ��� ������ � ������ ������
  Variant __fastcall ReadDoubleVariant();
  void __fastcall WriteDoubleVariant( const Variant &Value );
  Variant __fastcall ReadDateTimeVariant();
  void __fastcall WriteDateTimeVariant( const Variant &Value );
  Variant __fastcall ReadStringVariant();
  void __fastcall WriteStringVariant( const Variant &Value );
  __property TStream* Stream = { read = fStream };
};
#endif
