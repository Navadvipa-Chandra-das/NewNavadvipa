// ---------------------------------------------------------------------------
// New Navadvipa library - author Navadvipa Chandra das e-mail navadvipa.chandra.das@nizhnyaya-navadvipa.ru
#include <fmx.h>
#pragma hdrstop
#include "FMX_NNConfig.h"
#include "FMX_NNCommon.h"
#include "FMX_NNConst.h"
#include <memory>

#if (!__ANDROID__)
#pragma resource "*.res"
#endif

#pragma package(smart_init)

static inline void ValidCtrCheck( TNNFConfig * )
{
  new TNNFConfig( NULL );
}

TNNFConfig::TNNFConfig( TComponent* Owner )
  : inherited( Owner )
  , fStoreKind( skDB )
  , fEnabled( true )
  , fVersion( char() )
  , fTableUserReg( NNFConst::TableUserReg )
  , fFieldUserRegKey( NNFConst::FieldUserRegKey )
  , fFieldUserData( NNFConst::FieldUserData )
  , FUseUserNameInRegistryKey( true )
  , FUseOwnerNameInRegistryKey( true )
{
}

bool __fastcall TNNFConfig::StoredTableUserReg()
{
  return fTableUserReg != NNFConst::TableUserReg;
}

bool __fastcall TNNFConfig::StoredFieldUserRegKey()
{
  return fFieldUserRegKey != NNFConst::FieldUserRegKey;
}

bool __fastcall TNNFConfig::StoredFieldUserData()
{
  return fFieldUserData != NNFConst::FieldUserData;
}

void __fastcall TNNFConfig::Notification( TComponent *AComponent, TOperation Operation )
{
  inherited::Notification( AComponent, Operation );
  if ( ( Operation == opRemove ) && ( AComponent == Connection ) )
    fConnection = nullptr;
}

void __fastcall TNNFConfig::Load()
{
  if ( !Enabled )
    return;

  switch ( StoreKind ) {
  case skFile:
    PrepareFilerFromFile();
    break;
  case skFiler:
    PrepareFilerFromUserEvent();
    break;
  case skDB:
    PrepareFilerFromDB();
  }
}

void __fastcall TNNFConfig::Save()
{
  if ( !Enabled )
    return;

  switch ( StoreKind ) {
  case skFile:
    SaveToFile();
    break;
  case skFiler:
    SaveToFiler();
    break;
  case skDB:
    SaveToDB();
  }
}

void __fastcall TNNFConfig::DoLoad()
{
  DoBeginLoad();
  try {
    if ( FOnLoad )
      FOnLoad(this);
  } __finally {
    DoEndLoad();
  }
}

void __fastcall TNNFConfig::DoDefault()
{
  DoBeginLoad();
  try {
    if ( FOnDefault )
      FOnDefault( this );
  } __finally {
    DoEndLoad();
  }
}

void __fastcall TNNFConfig::DoSave()
{
  DoBeginSave();
  try {
    if ( FOnSave )
      FOnSave( this );
  } __finally {
    DoEndSave();
  }
}

void __fastcall TNNFConfig::LoadFilerFromUserEvent()
{
  bool B = true;
  Filer->Position = 0;
  if ( Version == Filer->ReadChar() ) {
    DoLoad();
    if ( Version != Filer->ReadChar() )
      throw Exception( L"������ ������ ������ TNNFConfig" );
    else
      B = false;
  }
  if ( B )
    DoDefault();
}

void __fastcall TNNFConfig::SaveFilerFromUserEvent()
{
  Filer->Position = 0;
  Filer->WriteChar( Version );
  DoSave();
  Filer->WriteChar( Version );
  Filer->Size = Filer->Position;
}

void __fastcall TNNFConfig::PrepareFilerFromFile()
{
  String fn = RegistryKey();
  if ( !FileExists( fn ) ) {
    DoDefault();
    return;
  }

  std::unique_ptr< TFileStream >fs( new TFileStream( fn, fmOpenRead ) );
  fFiler = new TNNFTextStream( fs.get() );
  try {
    LoadFilerFromUserEvent();
  } __finally {
    delete fFiler;
    fFiler = nullptr;
  }
}

void __fastcall TNNFConfig::PrepareFilerFromDB()
{
  fFiler = new TNNFTextStream( nullptr );

  try {
    if ( LoadFromDB() )
      LoadFilerFromUserEvent();
    else
      DoDefault();
  } __finally {
    delete fFiler;
    fFiler = nullptr;
  }
}

void __fastcall TNNFConfig::PrepareFilerFromUserEvent()
{
  if ( Filer )
    throw Exception( L"�� �������� fFiler" );

  DoGetFiler();
  if ( Filer && ( Filer->Size != 0 ) )
    LoadFilerFromUserEvent();
  else
    DoDefault();
}

void __fastcall TNNFConfig::SaveToFile()
{
  String fn = RegistryKey();
  if ( !FileExists( fn ) ) {
    NativeUInt H = FileCreate( fn );
    FileClose( H );
  }
  TFileStream* fs = new TFileStream( fn, fmOpenWrite );
  fFiler = new TNNFTextStream( fs );
  try {
    SaveFilerFromUserEvent();
  } __finally {
    delete fFiler;
    fFiler = nullptr;
    if ( fs )
      delete fs;
  }
}

void __fastcall TNNFConfig::SaveToFiler()
{
  fFiler = nullptr;
  DoGetFiler();
  if ( Filer )
    SaveFilerFromUserEvent();
}

void __fastcall TNNFConfig::SetConnection(TFDConnection *value)
{
  if ( Connection != value ) {
    fConnection = value;
    if ( value )
      value->FreeNotification( this );
  }
}

void __fastcall TNNFConfig::PrepareQuerySQL( TFDQuery *quReg, const String &UserRegKey )
{
  quReg->SQL->Text = "select " + FieldUserRegKey + "," + FieldUserData +
                    " from " + TableUserReg +
                    " where " + FieldUserRegKey + " = :UserRegKey_";
  quReg->Params->Items[ 0 ]->DataType = ftString;
  quReg->Params->Items[ 0 ]->AsString = UserRegKey;
  quReg->UpdateOptions->AutoCommitUpdates = true;
  quReg->Open();
}

void __fastcall TNNFConfig::SaveToDB()
{
  if ( !IsConnection() )
    return;

  String RK = RegistryKey();
  fFiler = new TNNFTextStream( nullptr );
  try {
    SaveFilerFromUserEvent();
    std::unique_ptr< TFDQuery > quReg( new TFDQuery( this ) );
    std::unique_ptr< TFDTransaction > trReg( new TFDTransaction( this ) );
    quReg->Connection = Connection;
    trReg->Connection = Connection;
    quReg->Transaction = trReg.get();
    PrepareQuerySQL( quReg.get(), RK );
    if ( quReg->RecordCount == 0 ) {
      quReg->Insert();
      quReg->Fields->Fields[ 0 ]->AsString = RK;
    }
    else
      quReg->Edit();
    TBlobField *bf = ( ( TBlobField* )( quReg->Fields->Fields[ 1 ] ) );
    bf->LoadFromStream( Filer );
    quReg->Post();
  } __finally {
    delete fFiler;
    fFiler = nullptr;
  }
}

bool __fastcall TNNFConfig::LoadFromDB()
{
  if ( !IsConnection() )
    return false;

  bool B = false;
  std::unique_ptr< TFDQuery > quReg( new TFDQuery( this ) );
  std::unique_ptr< TFDTransaction > trReg( new TFDTransaction( this ) );
  quReg->Connection = Connection;
  trReg->Connection = Connection;
  quReg->Transaction = trReg.get();
  String RK = RegistryKey();
  PrepareQuerySQL( quReg.get(), RK );
  if ( quReg->RecordCount == 1 ) {
    TBlobField *bf = ( ( TBlobField* )( quReg->Fields->Fields[ 1 ] ) );
    bf->SaveToStream( Filer );
    B = true;
  }
  return B;
}

String __fastcall TNNFConfig::RegistryKey()
{
  String S;
  if ( StaticRegistryKey.IsEmpty() )
    S = NNF::ComponentToKey( Owner, UseOwnerNameInRegistryKey );
  else
    S = StaticRegistryKey;

  if ( UseUserNameInRegistryKey ) {
    String AUserName;
    if ( StaticUserName.IsEmpty() ) {
      if ( Connection != nullptr ) {
        AUserName = Connection->Params->UserName;
        if ( !AUserName.IsEmpty() )
          S = AUserName + L"-" + S;
      }
    } else
      S = StaticUserName + L"-" + S;
  }
  return S;
}

bool __fastcall TNNFConfig::IsConnection()
{
  if ( Connection == nullptr )
    return false;
  else
    return Connection->Connected;
}

// ---------------------------------------------------------------------------
namespace Fmx_nnconfig
{
  void __fastcall PACKAGE Register() {
    TComponentClass classes[1] = { __classid( TNNFConfig ) };
    RegisterComponents( L"FMX New Navadvipa", classes, 0 );
  }
}
// ---------------------------------------------------------------------------

