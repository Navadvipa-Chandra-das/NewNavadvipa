--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "UserRolesUsersFK";
ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "UserRolesRoleFK";
ALTER TABLE IF EXISTS ONLY public."UserRights" DROP CONSTRAINT IF EXISTS "UserRightsUsersFK";
ALTER TABLE IF EXISTS ONLY public."UserRights" DROP CONSTRAINT IF EXISTS "UserRightsRightsFK";
ALTER TABLE IF EXISTS ONLY public."RoleRights" DROP CONSTRAINT IF EXISTS "RoleRightsRoleFK";
ALTER TABLE IF EXISTS ONLY public."RoleRights" DROP CONSTRAINT IF EXISTS "RoleRightsRightsFK";
ALTER TABLE IF EXISTS ONLY public."RoleKind" DROP CONSTRAINT IF EXISTS "RoleKindParentFK";
ALTER TABLE IF EXISTS ONLY public."Role" DROP CONSTRAINT IF EXISTS "RoleKindFK";
ALTER TABLE IF EXISTS ONLY public."RightsKind" DROP CONSTRAINT IF EXISTS "RightsKindParentFK";
ALTER TABLE IF EXISTS ONLY public."Rights" DROP CONSTRAINT IF EXISTS "RightsKindFK";
ALTER TABLE IF EXISTS ONLY public."Translate" DROP CONSTRAINT IF EXISTS "LanguagesFK";
ALTER TABLE IF EXISTS ONLY public."LanguageKind" DROP CONSTRAINT IF EXISTS "LanguageKindParentFK";
ALTER TABLE IF EXISTS ONLY public."Language" DROP CONSTRAINT IF EXISTS "LanguageKindFK";
ALTER TABLE IF EXISTS ONLY public."Translate" DROP CONSTRAINT IF EXISTS "LanguageFK";
ALTER TABLE IF EXISTS ONLY public."Kind" DROP CONSTRAINT IF EXISTS "KindParent_fk";
ALTER TABLE IF EXISTS ONLY public."Entity" DROP CONSTRAINT IF EXISTS "KindFK";
ALTER TABLE IF EXISTS ONLY public."CommodKind" DROP CONSTRAINT IF EXISTS "CommodKindParentFK";
ALTER TABLE IF EXISTS ONLY public."Commod" DROP CONSTRAINT IF EXISTS "CommodKindFK";
ALTER TABLE IF EXISTS ONLY public."ColorKind" DROP CONSTRAINT IF EXISTS "ColorKindParentFK";
ALTER TABLE IF EXISTS ONLY public."Users" DROP CONSTRAINT IF EXISTS "Users_pkey";
ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "UserRoles_pkey";
ALTER TABLE IF EXISTS ONLY public."UserRights" DROP CONSTRAINT IF EXISTS "UserRights_pkey";
ALTER TABLE IF EXISTS ONLY public."UserReg" DROP CONSTRAINT IF EXISTS "UserReg_pkey";
ALTER TABLE IF EXISTS ONLY public."Translate" DROP CONSTRAINT IF EXISTS "Translate_pkey";
ALTER TABLE IF EXISTS ONLY public."Role" DROP CONSTRAINT IF EXISTS "Role_pkey";
ALTER TABLE IF EXISTS ONLY public."RoleRights" DROP CONSTRAINT IF EXISTS "RoleRights_pkey";
ALTER TABLE IF EXISTS ONLY public."RoleKind" DROP CONSTRAINT IF EXISTS "RoleKind_pkey";
ALTER TABLE IF EXISTS ONLY public."Rights" DROP CONSTRAINT IF EXISTS "Rights_pkey";
ALTER TABLE IF EXISTS ONLY public."RightsKind" DROP CONSTRAINT IF EXISTS "RightsKind_pkey";
ALTER TABLE IF EXISTS ONLY public."Kind" DROP CONSTRAINT IF EXISTS "ParentKind";
ALTER TABLE IF EXISTS ONLY public."Languages" DROP CONSTRAINT IF EXISTS "Languages_pkey";
ALTER TABLE IF EXISTS public."Translate" DROP CONSTRAINT IF EXISTS "LanguagesCK";
ALTER TABLE IF EXISTS ONLY public."Language" DROP CONSTRAINT IF EXISTS "Language_pkey";
ALTER TABLE IF EXISTS ONLY public."LanguageKind" DROP CONSTRAINT IF EXISTS "LanguageKind_pkey";
ALTER TABLE IF EXISTS ONLY public."Language" DROP CONSTRAINT IF EXISTS "LanguageKindID_Entity_UN";
ALTER TABLE IF EXISTS ONLY public."Kind" DROP CONSTRAINT IF EXISTS "Kind_pkey";
ALTER TABLE IF EXISTS ONLY public."Color" DROP CONSTRAINT IF EXISTS "EnumLiteralUN";
ALTER TABLE IF EXISTS ONLY public."Entity" DROP CONSTRAINT IF EXISTS "Entity_pkey";
ALTER TABLE IF EXISTS ONLY public."Commod" DROP CONSTRAINT IF EXISTS "Commod_pkey";
ALTER TABLE IF EXISTS ONLY public."CommodKind" DROP CONSTRAINT IF EXISTS "CommodKind_pkey";
ALTER TABLE IF EXISTS ONLY public."Color" DROP CONSTRAINT IF EXISTS "Color_pkey";
ALTER TABLE IF EXISTS ONLY public."ColorKind" DROP CONSTRAINT IF EXISTS "ColorKind_pkey";
ALTER TABLE IF EXISTS public."Translate" ALTER COLUMN "TranslateID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."RoleKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."RoleKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Role" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Role" ALTER COLUMN "EntityID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."RightsKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."RightsKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Rights" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Rights" ALTER COLUMN "EntityID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Languages" ALTER COLUMN "LanguagesID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."LanguageKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."LanguageKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Language" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Language" ALTER COLUMN "EntityID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."CommodKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."CommodKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Commod" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Commod" ALTER COLUMN "EntityID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."ColorKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."ColorKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Color" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS public."Color" ALTER COLUMN "EntityID" DROP DEFAULT;
DROP TABLE IF EXISTS public."Users";
DROP SEQUENCE IF EXISTS public."Users_UserID_seq";
DROP TABLE IF EXISTS public."UserRoles";
DROP SEQUENCE IF EXISTS public."UserRoles_UserRolesID_seq";
DROP TABLE IF EXISTS public."UserRights";
DROP SEQUENCE IF EXISTS public."UserRights_UserRightsID_seq";
DROP TABLE IF EXISTS public."UserReg";
DROP SEQUENCE IF EXISTS public."Translate_TranslateID_seq";
DROP TABLE IF EXISTS public."Translate";
DROP TABLE IF EXISTS public."RoleRights";
DROP SEQUENCE IF EXISTS public."RoleRights_RoleRightsID_seq";
DROP TABLE IF EXISTS public."RoleKind";
DROP TABLE IF EXISTS public."Role";
DROP TABLE IF EXISTS public."RightsKind";
DROP TABLE IF EXISTS public."Rights";
DROP SEQUENCE IF EXISTS public."Languages_LanguagesID_seq";
DROP TABLE IF EXISTS public."Languages";
DROP TABLE IF EXISTS public."LanguageKind";
DROP TABLE IF EXISTS public."Language";
DROP TABLE IF EXISTS public."CommodKind";
DROP TABLE IF EXISTS public."Commod";
DROP TABLE IF EXISTS public."ColorKind";
DROP TABLE IF EXISTS public."Kind";
DROP SEQUENCE IF EXISTS public."Kind_KindID_seq";
DROP TABLE IF EXISTS public."Color";
DROP TABLE IF EXISTS public."Entity";
DROP SEQUENCE IF EXISTS public."Entity_EntityID_seq";
DROP PROCEDURE IF EXISTS public."SetUserRole"(IN "AUser" character varying, IN "ARole" character varying, IN "IsGrant" boolean);
DROP PROCEDURE IF EXISTS public."SetNewUserPassword"(IN "AUser" character varying, IN "APassword" character varying);
DROP FUNCTION IF EXISTS public."RoleKindDelete"();
DROP FUNCTION IF EXISTS public."RoleIDToName"("ARoleID" bigint);
DROP FUNCTION IF EXISTS public."RoleIDToKindID"("ARoleID" bigint);
DROP FUNCTION IF EXISTS public."RoleDelete"();
DROP FUNCTION IF EXISTS public."RightsKindDelete"();
DROP PROCEDURE IF EXISTS public."RightsIndexGenerate"();
DROP FUNCTION IF EXISTS public."RightsDelete"();
DROP FUNCTION IF EXISTS public."RightIndexToName"("ARightIndex" bigint);
DROP FUNCTION IF EXISTS public."RightIDToName"("ARightID" bigint);
DROP FUNCTION IF EXISTS public."RightIDToKindID"("ARightID" bigint);
DROP PROCEDURE IF EXISTS public."ResetConfig"(IN "AUser" character varying);
DROP PROCEDURE IF EXISTS public."PasteUserRoles"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS public."PasteUserRights"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS public."PasteTranslate"(IN "ANewLanguageID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS public."PasteRoleRights"(IN "ANewRoleID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS public."PasteEntity"(IN "ANewKindID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS public."LoadRightsUser"(IN "AUserID" bigint);
DROP FUNCTION IF EXISTS public."LanguagesIDToName"("ALanguagesID" bigint);
DROP FUNCTION IF EXISTS public."IsRight"("ARightIndex" bigint, "ANeedException" boolean);
DROP PROCEDURE IF EXISTS public."InsertLanguageRow"(IN "AKindID" bigint, IN "ALanguage" character varying, IN "ATranslate" character varying);
DROP FUNCTION IF EXISTS public."GetUserID"("AName" character varying);
DROP FUNCTION IF EXISTS public."GetUserID"();
DROP FUNCTION IF EXISTS public."EntityIDToKindID"("AEntityID" bigint);
DROP PROCEDURE IF EXISTS public."DeleteUser"(IN "AUser" character varying);
DROP PROCEDURE IF EXISTS public."CreateUser"(IN "AUser" character varying, IN "APassword" character varying, IN "ARole" character varying, IN "IsSuperUser" boolean);
DROP PROCEDURE IF EXISTS public."CreateRightsUser"();
DROP FUNCTION IF EXISTS public."CommodKindDelete"();
DROP FUNCTION IF EXISTS public."ColorKindDelete"();
DROP PROCEDURE IF EXISTS public."ColorIndexGenerate"();
DROP PROCEDURE IF EXISTS public."AfterLogon"(IN "AUserID" bigint);
DROP TYPE IF EXISTS public."TBufferIntBox";
DROP TYPE IF EXISTS public."TAnketa";
--
-- Name: TAnketa; Type: TYPE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TYPE public."TAnketa" AS (
	"FIO" character varying(100),
	"INN" character varying(12),
	"Passport" character varying(12),
	"PassportKemVydan" character varying(50),
	"PassportDate" date
);


ALTER TYPE public."TAnketa" OWNER TO "Navadvipa Chandra das";

--
-- Name: TYPE "TAnketa"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TYPE public."TAnketa" IS 'Анкетные данные пользователей';


--
-- Name: TBufferIntBox; Type: TYPE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TYPE public."TBufferIntBox" AS (
	"IsCut" boolean,
	"Label" character varying(50),
	"VectorID" bigint[]
);


ALTER TYPE public."TBufferIntBox" OWNER TO "Navadvipa Chandra das";

--
-- Name: TYPE "TBufferIntBox"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TYPE public."TBufferIntBox" IS 'Тип, для работы с буфером обмена!';


--
-- Name: AfterLogon(bigint); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."AfterLogon"(IN "AUserID" bigint)
    LANGUAGE plpgsql
    AS $$begin
  call "CreateRightsUser"();
  call "LoadRightsUser"( "AUserID" );
end;
$$;


ALTER PROCEDURE public."AfterLogon"(IN "AUserID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: PROCEDURE "AfterLogon"(IN "AUserID" bigint); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON PROCEDURE public."AfterLogon"(IN "AUserID" bigint) IS 'Выполняется сразу после входа в базу данных NewNavadvipa';


--
-- Name: ColorIndexGenerate(); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."ColorIndexGenerate"()
    LANGUAGE plpgsql
    AS $$
declare
  I bigint := 0;
  pr record;
begin
  for pr in ( select
                a."EntityID"
              , a."KindID"
              , a."Entity"
              from
                "Color" a
              order by a."KindID", a."Entity" ) loop
    update "Color"
    set
      "VectorIndex" = I
    where
      "EntityID" = pr."EntityID";
    I := I + 1;
  end loop;
end;
$$;


ALTER PROCEDURE public."ColorIndexGenerate"() OWNER TO "Navadvipa Chandra das";

--
-- Name: PROCEDURE "ColorIndexGenerate"(); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON PROCEDURE public."ColorIndexGenerate"() IS 'Создание индексов для цветов, начиная от нуля и прибавляя единичку для всех записей таблицы "Color"!';


--
-- Name: ColorKindDelete(); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."ColorKindDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from "Color" where "KindID" = OLD."KindID";
  return NULL;
end;
$$;


ALTER FUNCTION public."ColorKindDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: CommodKindDelete(); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."CommodKindDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from "Commod" where "KindID" = OLD."KindID";
  return NULL;
end;
$$;


ALTER FUNCTION public."CommodKindDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: CreateRightsUser(); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."CreateRightsUser"()
    LANGUAGE plpgsql
    AS $$
declare
  "Command" varchar;
begin
  "Command" := 'CREATE TEMP TABLE IF NOT EXISTS "RightsUser"(
    "RightIndex" bigint NOT NULL,
    "Value" Boolean NOT NULL )
     ON COMMIT PRESERVE ROWS TABLESPACE pg_default;';

  EXECUTE "Command";
end;
$$;


ALTER PROCEDURE public."CreateRightsUser"() OWNER TO "Navadvipa Chandra das";

--
-- Name: CreateUser(character varying, character varying, character varying, boolean); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."CreateUser"(IN "AUser" character varying, IN "APassword" character varying, IN "ARole" character varying, IN "IsSuperUser" boolean)
    LANGUAGE plpgsql
    AS $$

declare
  "Command" character varying;
  SU character varying(12);
begin
  if "IsSuperUser" then
    SU := 'SUPERUSER ';
  else
    SU := 'NOSUPERUSER ';
  end if;
  "Command" := 'CREATE ROLE ' || '"' || "AUser" || '"' || ' WITH ' || SU ||
  ' LOGIN 
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION ' ||
   'IN ROLE "' || "ARole" || '"' ||
  ' PASSWORD ' || '''' || "APassword" || '''';
  
  EXECUTE "Command";
end;
$$;


ALTER PROCEDURE public."CreateUser"(IN "AUser" character varying, IN "APassword" character varying, IN "ARole" character varying, IN "IsSuperUser" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: DeleteUser(character varying); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."DeleteUser"(IN "AUser" character varying)
    LANGUAGE plpgsql
    AS $$
declare
  "DeleteUserCommand" varchar;
begin
  "DeleteUserCommand" := 'DROP ROLE ' || '"' || "AUser" || '"';
  
  EXECUTE "DeleteUserCommand";
end;
$$;


ALTER PROCEDURE public."DeleteUser"(IN "AUser" character varying) OWNER TO "Navadvipa Chandra das";

--
-- Name: EntityIDToKindID(bigint); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."EntityIDToKindID"("AEntityID" bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor for
  select a."KindID" from "Entity" a where a."EntityID" = "AEntityID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."EntityIDToKindID"("AEntityID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "EntityIDToKindID"("AEntityID" bigint); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION public."EntityIDToKindID"("AEntityID" bigint) IS 'Разыменование идентификатора Entity (сущности) в идентификатор её типа (KindID)!';


--
-- Name: GetUserID(); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."GetUserID"() RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor( "AName" character varying ) for
  select a."UserID" from "Users" a where a."Name" = "AName";
  "СurrentUser" character varying(32);
begin
  select current_user into "СurrentUser";
  open rk( "CurrentUser" );
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."GetUserID"() OWNER TO "Navadvipa Chandra das";

--
-- Name: GetUserID(character varying); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."GetUserID"("AName" character varying) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor( "AName" character varying ) for
  select a."UserID" from "Users" a where a."Name" = "AName";
begin
  open rk( "AName" );
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."GetUserID"("AName" character varying) OWNER TO "Navadvipa Chandra das";

--
-- Name: InsertLanguageRow(bigint, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."InsertLanguageRow"(IN "AKindID" bigint, IN "ALanguage" character varying, IN "ATranslate" character varying)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
  "AEntityID" bigint;
  R bigint;

  rk cursor for
  select a."EntityID"
  from
    "Entity" a
  where
      a."KindID" = "AKindID"
  and a."Entity" = "ALanguage";

  dk cursor ( "ALanguagesID" bigint ) for
  select a."TranslateID"
  from
    "Translate" a
  where
      a."LanguageID" = "AEntityID"
  and a."LanguagesID" = "ALanguagesID";
begin
  open rk;
  fetch rk into "AEntityID";
  close rk;
  if ( not found ) then
    insert into "Language" (
      "KindID"
    , "Entity"
    , "Original"
    ) values (
      "AKindID"
    , "ALanguage"
    , "ATranslate"
    ) returning "EntityID" into "AEntityID";
  end if;

  for pr in ( select
                a."LanguagesID"
              from
                "Languages" a
              where
                  a."LanguagesID" > 1
              order by a."Languages" ) loop
    open dk( pr."LanguagesID" );
    fetch dk into R;
    close dk;
    if ( not found ) then
      insert into "Translate" (
        "LanguageID"
      , "LanguagesID"
      , "Translate"
      ) values (
        "AEntityID"
      , pr."LanguagesID"
      , "ATranslate"
      );
    end if;
  end loop;
end;
$$;


ALTER PROCEDURE public."InsertLanguageRow"(IN "AKindID" bigint, IN "ALanguage" character varying, IN "ATranslate" character varying) OWNER TO "Navadvipa Chandra das";

--
-- Name: IsRight(bigint, boolean); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."IsRight"("ARightIndex" bigint, "ANeedException" boolean DEFAULT false) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
  R Boolean;
  S character varying( 200 );
  rk cursor for
  select a."Value" from "RightsUser" a where a."RightIndex" = "ARightIndex";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := false;
  end if;
  close rk;

  S := "RightIndexToName"( "ARightIndex" );
  if ( not R and "ANeedException" ) then
    raise exception 'Извините, пожалуйста, но у вас нет права % ', S;
  end if;

  return R;
end;
$$;


ALTER FUNCTION public."IsRight"("ARightIndex" bigint, "ANeedException" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "IsRight"("ARightIndex" bigint, "ANeedException" boolean); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION public."IsRight"("ARightIndex" bigint, "ANeedException" boolean) IS 'Есть ли право?';


--
-- Name: LanguagesIDToName(bigint); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."LanguagesIDToName"("ALanguagesID" bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
  R character varying(32);
  rk cursor for
  select a."Languages" from "Languages" a where a."LanguagesID" = "ALanguagesID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 'Error ' || "ALanguagesID";
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."LanguagesIDToName"("ALanguagesID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: LoadRightsUser(bigint); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."LoadRightsUser"(IN "AUserID" bigint)
    LANGUAGE plpgsql
    AS $$
declare
  I bigint;
  L bigint;
  RI bigint;
  pr record;
  dr record;
  rk cursor( "ARightID" bigint ) for select a."VectorIndex" from "Rights" a where a."EntityID" = "ARightID";
begin
  delete from "RightsUser";
  select max( a."VectorIndex" ) from "Rights" a into L;
  for I in 0 .. L loop
    insert into "RightsUser" ( "RightIndex", "Value" ) values ( I, false );
  end loop;

  for pr in ( select
                a."EntityID" as "RoleID"
              from
                "UserRoles" a
              where
                  a."UserID" = "AUserID" ) loop
    for dr in ( select
                  a."EntityID" as "RightID"
                from
                  "RoleRights" a
                where
                    a."RoleID" = pr."RoleID" ) loop
      open rk( dr."RightID" );
      fetch rk into RI;
      if ( not found ) then
        raise exception 'Не найдено право RightID == % !', dr."RightID";
      end if;
      close rk;

      update "RightsUser" set "Value" = true where "RightIndex" = RI;
    end loop;
  end loop;

  for pr in ( select
                a."EntityID" as "RightID"
              , a."IsPlus"
              from
                "UserRights" a
              where
                  a."UserID" = "AUserID" ) loop
    open rk( pr."RightID" );
    fetch rk into RI;
    if ( not found ) then
      raise exception 'Не найдено право RightID == % !', dr."RightID";
    end if;
    close rk;

    update "RightsUser" set "Value" = pr."IsPlus" where "RightIndex" = RI;
  end loop;
end;
$$;


ALTER PROCEDURE public."LoadRightsUser"(IN "AUserID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: PROCEDURE "LoadRightsUser"(IN "AUserID" bigint); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON PROCEDURE public."LoadRightsUser"(IN "AUserID" bigint) IS 'Заполнение правами пользователя такблицы "RightsUser"!';


--
-- Name: PasteEntity(bigint, bigint, boolean); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."PasteEntity"(IN "ANewKindID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  --for i in 1 .. "AVectorID".COUNT loop
    update "Entity" set "KindID" = "ANewKindID"
    where "EntityID" = "AVectorID";
  --end loop;
end;
$$;


ALTER PROCEDURE public."PasteEntity"(IN "ANewKindID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: PasteRoleRights(bigint, bigint, boolean); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."PasteRoleRights"(IN "ANewRoleID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  if ( "IsCut" ) then
  --for i in 1 .. "AVectorID".COUNT loop
    update "RoleRights" set "RoleID" = "ANewRoleID"
    where "RoleRightsID" = "AVectorID";
  --end loop;
  else
    for pr in ( select
                  a."EntityID"
                from
                  "RoleRights" a
                where "RoleRightsID" = "AVectorID" ) loop
      insert into "RoleRights" ( "RoleID", "EntityID" ) values ( "ANewRoleID", pr."EntityID" );
    end loop;
  end if;
end;
$$;


ALTER PROCEDURE public."PasteRoleRights"(IN "ANewRoleID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: PasteTranslate(bigint, bigint, boolean); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."PasteTranslate"(IN "ANewLanguageID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  if ( "IsCut" ) then
  --for i in 1 .. "AVectorID".COUNT loop
    update "Translate" set "LanguageID" = "ANewLanguageID"
    where "TranslateID" = "AVectorID";
  --end loop;
  else
    for pr in ( select
			            a."LanguagesID"
                , a."Translate"
                from
                  "Translate" a
                where a."TranslateID" = "AVectorID" ) loop
      insert into "Translate" (
    		"LanguageID"
	    , "LanguagesID"
	    , "Translate"
      ) values (
        "ANewLanguageID"
      , pr."LanguagesID"
	    , pr."Translate"
      );
    end loop;
  end if;
end;
$$;


ALTER PROCEDURE public."PasteTranslate"(IN "ANewLanguageID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: PasteUserRights(bigint, bigint, boolean); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."PasteUserRights"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  if ( "IsCut" ) then
  --for i in 1 .. "AVectorID".COUNT loop
    update "UserRights" set "UserID" = "ANewUserID"
    where "UserRightsID" = "AVectorID";
  --end loop;
  else
    for pr in ( select
                  a."EntityID"
                , a."IsPlus"
                from
                  "UserRights" a
                where "UserRightsID" = "AVectorID" ) loop
      insert into "UserRights" ( "UserID", "EntityID", "IsPlus" ) values ( "ANewUserID", pr."EntityID", pr."IsPlus" );
    end loop;
  end if;
end;
$$;


ALTER PROCEDURE public."PasteUserRights"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: PasteUserRoles(bigint, bigint, boolean); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."PasteUserRoles"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  if ( "IsCut" ) then
  --for i in 1 .. "AVectorID".COUNT loop
    update "UserRoles" set "UserID" = "ANewUserID"
    where "UserRolesID" = "AVectorID";
  --end loop;
  else
    for pr in ( select
                  a."EntityID"
                from
                  "UserRoles" a
                where "UserRolesID" = "AVectorID" ) loop
      insert into "UserRoles" ( "UserID", "EntityID" ) values ( "ANewUserID", pr."EntityID" );
    end loop;
  end if;
end;
$$;


ALTER PROCEDURE public."PasteUserRoles"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: ResetConfig(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public."ResetConfig"(IN "AUser" character varying)
    LANGUAGE plpgsql
    AS $$begin
  delete from "UserReg" a where a."UserRegKey" like "AUser" || '-%';
end;$$;


ALTER PROCEDURE public."ResetConfig"(IN "AUser" character varying) OWNER TO postgres;

--
-- Name: PROCEDURE "ResetConfig"(IN "AUser" character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON PROCEDURE public."ResetConfig"(IN "AUser" character varying) IS 'Сброс настроек пользователя';


--
-- Name: RightIDToKindID(bigint); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RightIDToKindID"("ARightID" bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor for
  select a."KindID" from "Rights" a where a."EntityID" = "ARightID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."RightIDToKindID"("ARightID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RightIDToKindID"("ARightID" bigint); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION public."RightIDToKindID"("ARightID" bigint) IS 'Получение из идентификатора права идентификатор его вида ("KindID")!';


--
-- Name: RightIDToName(bigint); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RightIDToName"("ARightID" bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
  R character varying(200);
  rk cursor for
  select a."Entity" from "Rights" a where a."EntityID" = "ARightID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 'Error ' || "ARightID";
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."RightIDToName"("ARightID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RightIDToName"("ARightID" bigint); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION public."RightIDToName"("ARightID" bigint) IS 'Разыменовать идентификатор права в его имя!';


--
-- Name: RightIndexToName(bigint); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RightIndexToName"("ARightIndex" bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
  R character varying(200);
  rk cursor for
  select a."Entity" from "Rights" a where a."VectorIndex" = "ARightIndex";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 'Error "RightIndex" == ' || "ARightIndex";
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."RightIndexToName"("ARightIndex" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RightIndexToName"("ARightIndex" bigint); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION public."RightIndexToName"("ARightIndex" bigint) IS 'Разыменовать индекс права в его имя!';


--
-- Name: RightsDelete(); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RightsDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$begin
  delete from "RoleRights" where "EntityID" = OLD."EntityID";
  return NULL;
end;$$;


ALTER FUNCTION public."RightsDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: RightsIndexGenerate(); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."RightsIndexGenerate"()
    LANGUAGE plpgsql
    AS $$
declare
  I bigint := 0;
  pr record;
begin
  for pr in ( select
                a."EntityID"
              , a."KindID"
              , a."Entity"
              from
                "Rights" a
              order by a."KindID", a."Entity" ) loop

    update "Rights" set "VectorIndex" = I where "EntityID" = pr."EntityID";

    I := I + 1;
  end loop;
end;
$$;


ALTER PROCEDURE public."RightsIndexGenerate"() OWNER TO "Navadvipa Chandra das";

--
-- Name: PROCEDURE "RightsIndexGenerate"(); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON PROCEDURE public."RightsIndexGenerate"() IS 'Создание индексов для прав, начиная от нуля и прибавляя единичку для всех записей таблицы "Rights"!';


--
-- Name: RightsKindDelete(); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RightsKindDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from "Rights" where "KindID" = OLD."KindID";
  return NULL;
end;
$$;


ALTER FUNCTION public."RightsKindDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: RoleDelete(); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RoleDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$begin
  delete from "RoleRights" where "RoleID" = OLD."EntityID";
  return NULL;
end;$$;


ALTER FUNCTION public."RoleDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RoleDelete"(); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION public."RoleDelete"() IS 'Удаление роли';


--
-- Name: RoleIDToKindID(bigint); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RoleIDToKindID"("ARoleID" bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor for
  select a."KindID" from "Role" a where a."EntityID" = "ARoleID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."RoleIDToKindID"("ARoleID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RoleIDToKindID"("ARoleID" bigint); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION public."RoleIDToKindID"("ARoleID" bigint) IS 'Получение из идентификатора роли идентификатор её вида ("KindID")!';


--
-- Name: RoleIDToName(bigint); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RoleIDToName"("ARoleID" bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
  R character varying(200);
  rk cursor for
  select a."Entity" from "Role" a where a."EntityID" = "ARoleID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 'Error ' || "ARoleID";
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION public."RoleIDToName"("ARoleID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RoleIDToName"("ARoleID" bigint); Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION public."RoleIDToName"("ARoleID" bigint) IS 'Разыменовать идентификатор роли в её имя!';


--
-- Name: RoleKindDelete(); Type: FUNCTION; Schema: public; Owner: Navadvipa Chandra das
--

CREATE FUNCTION public."RoleKindDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from "Role" where "KindID" = OLD."KindID";
  return NULL;
end;
$$;


ALTER FUNCTION public."RoleKindDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: SetNewUserPassword(character varying, character varying); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."SetNewUserPassword"(IN "AUser" character varying, IN "APassword" character varying)
    LANGUAGE plpgsql
    AS $$
declare
  "SetNewUserPasswordCommand" varchar;
begin
  "SetNewUserPasswordCommand" := 'ALTER ROLE ' || '"' || "AUser" || '"' ||
  'PASSWORD ' || '''' || "APassword" || '''';
  
  EXECUTE "SetNewUserPasswordCommand";
end;
$$;


ALTER PROCEDURE public."SetNewUserPassword"(IN "AUser" character varying, IN "APassword" character varying) OWNER TO "Navadvipa Chandra das";

--
-- Name: SetUserRole(character varying, character varying, boolean); Type: PROCEDURE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE public."SetUserRole"(IN "AUser" character varying, IN "ARole" character varying, IN "IsGrant" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  "Command" varchar;
  S character varying(10);
  D character varying(10);
begin
  if ( "IsGrant" ) then
    S := 'GRANT';
    D := 'TO';
  else
    S := 'REVOKE';
    D := 'FROM';
  end if;
  "Command" := S || ' "' || "ARole" || '" ' || D || ' "' || "AUser" || '";'; 
  EXECUTE "Command";
end;
$$;


ALTER PROCEDURE public."SetUserRole"(IN "AUser" character varying, IN "ARole" character varying, IN "IsGrant" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: Entity_EntityID_seq; Type: SEQUENCE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE public."Entity_EntityID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Entity_EntityID_seq" OWNER TO "Navadvipa Chandra das";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Entity; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Entity" (
    "EntityID" bigint DEFAULT nextval('public."Entity_EntityID_seq"'::regclass) NOT NULL,
    "KindID" bigint NOT NULL,
    "Entity" character varying(200) NOT NULL,
    "Actual" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Entity" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Entity"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."Entity" IS 'Таблиа сущностей, связана с таблицей Kind как master-detail. Kind отображается деревом с помощью компонета TNNVDBTreeView, а Entity отображается в виде листиков веточек этогго дерева или его плодами с помощью компонета TNNVDBGrid. Это обычная практика.';


--
-- Name: Color; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Color" (
    "FonColor" integer NOT NULL,
    "FontColor" integer NOT NULL,
    "VectorIndex" bigint NOT NULL,
    "EnumLiteral" character varying(64)
)
INHERITS (public."Entity");


ALTER TABLE public."Color" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Color"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."Color" IS 'Цвета';


--
-- Name: Kind_KindID_seq; Type: SEQUENCE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE public."Kind_KindID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Kind_KindID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: Kind; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Kind" (
    "KindID" bigint DEFAULT nextval('public."Kind_KindID_seq"'::regclass) NOT NULL,
    "ParentID" bigint,
    "Kind" character varying(100) NOT NULL,
    "Actual" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Kind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Kind"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."Kind" IS 'Таблица древовидная для видов чего-нибудь!';


--
-- Name: ColorKind; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."ColorKind" (
)
INHERITS (public."Kind");


ALTER TABLE public."ColorKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "ColorKind"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."ColorKind" IS 'Виды цветов';


--
-- Name: Commod; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Commod" (
    "Price" double precision DEFAULT 0 NOT NULL
)
INHERITS (public."Entity");


ALTER TABLE public."Commod" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Commod"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."Commod" IS 'Товары и услуги';


--
-- Name: CommodKind; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."CommodKind" (
    "InPrice" boolean
)
INHERITS (public."Kind");


ALTER TABLE public."CommodKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: COLUMN "CommodKind"."InPrice"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN public."CommodKind"."InPrice" IS 'Включать ли в прайс';


--
-- Name: Language; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Language" (
    "Original" text
)
INHERITS (public."Entity");


ALTER TABLE public."Language" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Language"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."Language" IS 'Слова для перевода!';


--
-- Name: LanguageKind; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."LanguageKind" (
)
INHERITS (public."Kind");


ALTER TABLE public."LanguageKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "LanguageKind"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."LanguageKind" IS 'Виды слов для перевода';


--
-- Name: Languages; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Languages" (
    "LanguagesID" bigint NOT NULL,
    "LanguagesStringID" character varying(5) NOT NULL,
    "Languages" character varying(32) NOT NULL
);


ALTER TABLE public."Languages" OWNER TO "Navadvipa Chandra das";

--
-- Name: Languages_LanguagesID_seq; Type: SEQUENCE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE public."Languages_LanguagesID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Languages_LanguagesID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: Languages_LanguagesID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Navadvipa Chandra das
--

ALTER SEQUENCE public."Languages_LanguagesID_seq" OWNED BY public."Languages"."LanguagesID";


--
-- Name: Rights; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Rights" (
    "Literal" character varying(64),
    "VectorIndex" bigint
)
INHERITS (public."Entity");


ALTER TABLE public."Rights" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Rights"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."Rights" IS 'Полномочия пользователей!';


--
-- Name: RightsKind; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."RightsKind" (
)
INHERITS (public."Kind");


ALTER TABLE public."RightsKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "RightsKind"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."RightsKind" IS 'Виды полномочий';


--
-- Name: Role; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Role" (
)
INHERITS (public."Entity");


ALTER TABLE public."Role" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Role"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."Role" IS 'Роли пользователей!';


--
-- Name: RoleKind; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."RoleKind" (
)
INHERITS (public."Kind");


ALTER TABLE public."RoleKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "RoleKind"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."RoleKind" IS 'Виды ролей пользователей';


--
-- Name: RoleRights_RoleRightsID_seq; Type: SEQUENCE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE public."RoleRights_RoleRightsID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."RoleRights_RoleRightsID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: RoleRights; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."RoleRights" (
    "RoleRightsID" bigint DEFAULT nextval('public."RoleRights_RoleRightsID_seq"'::regclass) NOT NULL,
    "RoleID" bigint NOT NULL,
    "EntityID" bigint NOT NULL
);


ALTER TABLE public."RoleRights" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "RoleRights"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."RoleRights" IS 'Права ролей пользователей!';


--
-- Name: Translate; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Translate" (
    "TranslateID" bigint NOT NULL,
    "LanguageID" bigint NOT NULL,
    "LanguagesID" bigint NOT NULL,
    "Translate" text
);


ALTER TABLE public."Translate" OWNER TO "Navadvipa Chandra das";

--
-- Name: Translate_TranslateID_seq; Type: SEQUENCE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE public."Translate_TranslateID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Translate_TranslateID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: Translate_TranslateID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Navadvipa Chandra das
--

ALTER SEQUENCE public."Translate_TranslateID_seq" OWNED BY public."Translate"."TranslateID";


--
-- Name: UserReg; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."UserReg" (
    "UserRegKey" character varying(720) NOT NULL,
    "UserData" bytea
);


ALTER TABLE public."UserReg" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "UserReg"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."UserReg" IS 'Таблица, содержащая настройки пользователей в бинарном виде!';


--
-- Name: COLUMN "UserReg"."UserRegKey"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN public."UserReg"."UserRegKey" IS 'Поле - первичный ключ для настройки!';


--
-- Name: COLUMN "UserReg"."UserData"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN public."UserReg"."UserData" IS 'Поле - натройки пользователей в бинарном виде!';


--
-- Name: UserRights_UserRightsID_seq; Type: SEQUENCE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE public."UserRights_UserRightsID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserRights_UserRightsID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: UserRights; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."UserRights" (
    "UserRightsID" bigint DEFAULT nextval('public."UserRights_UserRightsID_seq"'::regclass) NOT NULL,
    "UserID" bigint NOT NULL,
    "EntityID" bigint NOT NULL,
    "IsPlus" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."UserRights" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "UserRights"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."UserRights" IS 'Права пользователей!';


--
-- Name: UserRoles_UserRolesID_seq; Type: SEQUENCE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE public."UserRoles_UserRolesID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserRoles_UserRolesID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: UserRoles; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."UserRoles" (
    "UserRolesID" bigint DEFAULT nextval('public."UserRoles_UserRolesID_seq"'::regclass) NOT NULL,
    "UserID" bigint NOT NULL,
    "EntityID" bigint NOT NULL
);


ALTER TABLE public."UserRoles" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "UserRoles"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."UserRoles" IS 'Роль пользователей!';


--
-- Name: Users_UserID_seq; Type: SEQUENCE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE public."Users_UserID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_UserID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: Users; Type: TABLE; Schema: public; Owner: Navadvipa Chandra das
--

CREATE TABLE public."Users" (
    "UserID" bigint DEFAULT nextval('public."Users_UserID_seq"'::regclass) NOT NULL,
    "Name" character varying(32) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" boolean DEFAULT false NOT NULL,
    "BirthDate" timestamp without time zone,
    "CreateDate" timestamp without time zone,
    "Anketa" public."TAnketa"
);


ALTER TABLE public."Users" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Users"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE public."Users" IS 'Таблица пользователей';


--
-- Name: COLUMN "Users"."UserID"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN public."Users"."UserID" IS 'Первичный ключ пользователя';


--
-- Name: COLUMN "Users"."Name"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN public."Users"."Name" IS 'Логин имя для базы данных';


--
-- Name: COLUMN "Users"."Note"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN public."Users"."Note" IS 'Комментарий';


--
-- Name: COLUMN "Users"."IsDeleted"; Type: COMMENT; Schema: public; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN public."Users"."IsDeleted" IS 'Удалён ли пользователь?';


--
-- Name: Color EntityID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Color" ALTER COLUMN "EntityID" SET DEFAULT nextval('public."Entity_EntityID_seq"'::regclass);


--
-- Name: Color Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Color" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: ColorKind KindID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."ColorKind" ALTER COLUMN "KindID" SET DEFAULT nextval('public."Kind_KindID_seq"'::regclass);


--
-- Name: ColorKind Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."ColorKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Commod EntityID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Commod" ALTER COLUMN "EntityID" SET DEFAULT nextval('public."Entity_EntityID_seq"'::regclass);


--
-- Name: Commod Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Commod" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: CommodKind KindID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."CommodKind" ALTER COLUMN "KindID" SET DEFAULT nextval('public."Kind_KindID_seq"'::regclass);


--
-- Name: CommodKind Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."CommodKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Language EntityID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Language" ALTER COLUMN "EntityID" SET DEFAULT nextval('public."Entity_EntityID_seq"'::regclass);


--
-- Name: Language Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Language" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: LanguageKind KindID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."LanguageKind" ALTER COLUMN "KindID" SET DEFAULT nextval('public."Kind_KindID_seq"'::regclass);


--
-- Name: LanguageKind Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."LanguageKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Languages LanguagesID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Languages" ALTER COLUMN "LanguagesID" SET DEFAULT nextval('public."Languages_LanguagesID_seq"'::regclass);


--
-- Name: Rights EntityID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Rights" ALTER COLUMN "EntityID" SET DEFAULT nextval('public."Entity_EntityID_seq"'::regclass);


--
-- Name: Rights Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Rights" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: RightsKind KindID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RightsKind" ALTER COLUMN "KindID" SET DEFAULT nextval('public."Kind_KindID_seq"'::regclass);


--
-- Name: RightsKind Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RightsKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Role EntityID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Role" ALTER COLUMN "EntityID" SET DEFAULT nextval('public."Entity_EntityID_seq"'::regclass);


--
-- Name: Role Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Role" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: RoleKind KindID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RoleKind" ALTER COLUMN "KindID" SET DEFAULT nextval('public."Kind_KindID_seq"'::regclass);


--
-- Name: RoleKind Actual; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RoleKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Translate TranslateID; Type: DEFAULT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Translate" ALTER COLUMN "TranslateID" SET DEFAULT nextval('public."Translate_TranslateID_seq"'::regclass);


--
-- Data for Name: Color; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (38, 83, 'Циклический цвет 00', true, 13828095, 0, 0, 'CycleColor0');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (41, 83, 'Циклический цвет 03', true, 9830346, 0, 1, 'CycleColor3');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (42, 83, 'Циклический цвет 04', true, 2424831, 0, 2, 'CycleColor4');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (20, 78, 'Услуга', true, 12976060, 0, 3, 'Service');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (22, 78, 'Комплект', true, 16632202, 0, 4, 'CommodAss');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (23, 78, ' Редактирование комплекта', true, 4783944, 0, 5, 'CommodAssOwner');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (25, 90, 'Детали комплекта', true, 12123900, 0, 6, 'CommodAssDetail');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (26, 90, 'Отсутствующий на складе товар', true, 65535, 255, 7, 'CommodLack');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (27, 90, 'Залежалый на складе товар', true, 13762468, 16711808, 8, 'CommodOld');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (28, 90, 'Товар с описанием', true, 16711680, 65535, 9, 'CommodWithNote');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (29, 90, 'Комментарий в документе', true, 12648384, 0, 10, 'CommentInPrim');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (114, 86, 'Табель выходов: отпуск', true, 16776960, 16711680, 115, 'TabelVyhodovOtpusk');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (52, 83, 'Циклический цвет 14', true, 10550435, 16711680, 67, 'CycleColor14');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (53, 83, 'Циклический цвет 15', true, 8454016, 0, 68, 'CycleColor15');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (115, 86, 'Табель выходов: больничный', true, 16711680, 65535, 116, 'TabelVyhodovBolnichnyi');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (116, 86, 'Табель выходов: не стандартное время', true, 65535, 255, 117, 'TabelVyhodovNotStandartTime');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (117, 86, 'Табель выходов: половина ставки', true, 9225983, 255, 118, 'TabelVyhodovPolovinaStavka');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (136, 85, 'Сервис клиент не возвращен 08 - 14 дней', true, 11468718, 0, 110, 'ServiceClient8_14');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (138, 85, 'Сервис клиент не возвращен 22 - 28 дней', true, 65280, 0, 113, 'ServiceClient22_28');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (128, 89, 'Коварный пользователь создан', true, 65535, 255, 87, 'SlyUserCreate');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (137, 85, 'Сервис клиент не возвращен 15 - 21 дней', true, 7995257, 0, 112, 'ServiceClient15_21');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (126, 89, 'Коварный пользователь вошел в "Троянду"', true, 255, 16777215, 85, 'SlyUserEnter');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (40, 83, 'Циклический цвет 02', true, 16771327, 255, 107, 'CycleColor2');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (39, 83, 'Циклический цвет 01', true, 16777107, 0, 108, 'CycleColor1');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (97, 84, 'Серийный номер не совпадает с товаром', true, 16711680, 65535, 111, 'SerialDifferentCommod');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (82, 90, 'В документе товар имеет отрицательный остаток', true, 65535, 255, 66, 'InDialogCommodMinusQuantity');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (98, 90, 'Склад в операции отличается от склада в документе!', true, 65535, 32768, 88, 'StorehousOperAndPrimDifferent');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (99, 90, 'Каёмочка индикатора в нормальном положении', true, 65535, 16711680, 89, 'KaemkaIndicatorNormal');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (100, 90, 'Поле индикатора в нормальном положении', true, 32768, 65535, 90, 'FieldIndicatorNormal');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (101, 90, 'Каёмочка индикатора в сигнальном положении', true, 65535, 16711680, 91, 'KaemkaIndicatorSignal');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (102, 90, 'Поле индикатора в сигнальном положении', true, 255, 65535, 92, 'FieldIndicatorSignal');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (110, 90, 'Документ оплачен, но не отгружен', true, 5635925, 16711680, 93, 'PrimPayAndNotShipment');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (111, 90, 'Документ отгружен, но не оплачен', true, 255, 65535, 94, 'PrimShipmentAndNotPay');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (112, 90, 'Табель выходов: неизвестно', true, 16777215, 16711680, 95, 'TabelVyhodovNotAny');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (113, 90, 'Табель выходов: прогул', true, 255, 65535, 96, 'TabelVyhodovProgul');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (118, 90, 'Цена последней закупки товара', true, 16376153, 16711680, 97, 'PriceLastCommod');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (119, 90, 'Серийника продался', true, 9225983, 255, 98, 'SerialPay');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (120, 90, 'Серийника продался, но не прошёл нужный срок ещё', true, 12902911, 32768, 99, 'SerialPayByNotSrok');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (121, 90, 'Опер-Комок - нет оплаты в приходном счете', true, 16777119, 14614528, 100, 'OperComokNotPayDebetPrim');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (122, 90, 'Опер-Комок - нет оплаты в расходном счете', true, 9225983, 255, 101, 'OperComokNotPayCreditPrim');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (124, 90, 'Товар устарел', true, 12632256, 0, 102, 'CommodVeryOld');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (125, 90, 'Комментарий - цвет окна', true, 9225983, 255, 103, 'CommentColorWinow');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (129, 90, 'Расходный счет оплачен по безналу и нет документов', true, 9225983, 255, 104, 'SchetCreditPayBeznalAndNotDocuments');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (130, 90, 'Расходный счет проведён и не оплачен и не отгружен', true, 65535, 255, 105, 'SchetCreditAcceptlAndNotPayAndNotOtgr');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (131, 90, 'Товар (серийник) взят на реализацию и не оплачен поставщику', true, 16711680, 65535, 106, 'SerialStoreButNotPayProvider');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (133, 90, 'Товар (серийник) куплен и не оплачен поставщику', true, 255, 65535, 120, 'SerialPayButNotPayProvider');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (140, 90, 'Выход из программы', true, 8454016, 12615680, 121, 'ExitFromProgram');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (141, 90, 'Печать документов', true, 8454143, 32768, 122, 'PrintPrim');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (142, 90, 'Попытка взлома "Троянды"', true, 16777215, 255, 123, 'ProgramTryVzlom');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (147, 90, 'Товар выкуплен', true, 10419870, 32768, 124, 'CommodPay');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (148, 90, 'Бухгалтерский товар', true, 255, 65535, 125, 'BuhgalterCommod');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (149, 90, 'В окне "Доктор" заявка не выполнена', true, 255, 65535, 126, 'DoctorZayavkaNotExecute');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (135, 85, 'Сервис клиент не возвращен 01 - 07 дней', true, 14548957, 0, 109, 'ServiceClient1_7');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (139, 85, 'Сервис клиент не возвращен более 29 дней', true, 55040, 0, 114, 'ServiceClientMore29');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (34, 90, 'Комментарий ко второй части суммы документа', true, 16777215, 255, 11, 'CommentSummaSecond');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (30, 90, 'Ошибочное субконто', true, 16777215, 255, 12, 'ErrorSubconto');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (31, 90, 'Серая строка при печати', true, 15658734, 0, 13, 'GrayLine');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (70, 90, 'Горячая клавиша', true, 16777215, 16711680, 56, 'HotKey');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (127, 89, 'Коварный пользователь удален', true, 9225983, 255, 86, 'SlyUserDelete');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (54, 83, 'Циклический цвет 16', true, 16381375, 16711680, 69, 'CycleColor16');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (55, 83, 'Циклический цвет 17', true, 16711808, 16777215, 70, 'CycleColor17');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (56, 83, 'Циклический цвет 18', true, 13303785, 0, 71, 'CycleColor18');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (143, 88, 'Произведена одна уценка товара', true, 16771839, 16711680, 81, 'CommodMarkdown1');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (144, 88, 'Произведено две уценки товара', true, 16765695, 16711680, 82, 'CommodMarkdown2');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (145, 88, 'Произведены три уценки товара', true, 16758783, 16711680, 83, 'CommodMarkdown3');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (146, 88, 'Произведены четыре и более уценки товара', true, 16753919, 16711680, 84, 'CommodMarkdown4');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (104, 87, 'Сумма мелкого опта', true, 65535, 255, 75, 'SummaSmallOpt');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (105, 87, 'Сумма дилерская', true, 12058551, 255, 76, 'SummaDiler');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (106, 87, 'Сумма оптовая', true, 16777119, 255, 77, 'SummaOpt');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (107, 87, 'Сумма входная', true, 5614335, 8421376, 78, 'SummaEntry');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (108, 87, 'Сумма ниже входной', true, 255, 65535, 79, 'SummaSmallThanEntry');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (109, 87, 'Сумма выше розничной', true, 16759773, 12124160, 80, 'SummaMoreThanRetail');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (57, 83, 'Циклический цвет 19', true, 65535, 255, 72, 'CycleColor19');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (58, 83, 'Циклический цвет 20', true, 16777215, 32768, 73, 'CycleColor20');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (63, 83, 'Циклический цвет 25', true, 8388863, 16777215, 74, 'CycleColor25');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (96, 84, 'Серийные номера замененные поставщиком, просрочена гарантия', true, 16777215, 255, 48, 'SerialChangeSupplierWithoutGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (78, 90, 'В диалоге выбранное количество', true, 65535, 255, 17, 'InDialogQuantity');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (79, 90, 'В диалоге цена больше обычной', true, 65535, 16711680, 18, 'InDialogPriceBig');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (132, 90, 'Товар (серийник) куплен и оплачен поставщику', true, 16777215, 0, 40, 'SerialPayAndStore');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (123, 90, 'Товар (серийник) принят на реализацию и оплачен поставщику', true, 16776960, 16711808, 46, 'SerialNotPayAndStore');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (36, 90, 'Комментарий к третьей части суммы документа', true, 16777215, 16711935, 49, 'CommentPartSumma3');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (37, 90, 'Третяя часть суммы документа', true, 16777215, 0, 50, 'PartSumma3');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (65, 90, 'Неактуальная операция', true, 255, 65535, 51, 'NotActualOper');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (66, 90, 'Документы с комментариями', true, 16294002, 128, 52, 'PrimWithComment');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (67, 90, 'Актуальный комментарий', true, 16777092, 0, 53, 'ActualComment');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (68, 90, 'Закупочная цена товара больше входной', true, 255, 16777215, 54, 'PriceCommodPayBig');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (69, 90, 'Частичная оплата', true, 16767449, 0, 55, 'PartPay');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (32, 90, 'Комментарий к первой части суммы документа', true, 16777215, 16711680, 14, 'CommentSummaFirst');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (33, 90, 'Первая часть суммы документа', true, 16777215, 0, 15, 'SummaFirst');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (35, 90, 'Вторая часть суммы документа', true, 16777215, 32768, 16, 'SummaSecond');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (59, 83, 'Циклический цвет 21', true, 65280, 16711680, 19, 'CycleColor21');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (83, 84, 'Серийные номера на складе с гарантией', true, 16777215, 0, 20, 'SerialWithGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (87, 84, 'Серийные номера ожидаются с гарантийного ремонта', true, 12975900, 0, 21, 'SerialWaitWithGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (92, 84, 'Серийные номера на ремонте у поставщика, просрочена гарантия', true, 16777058, 255, 22, 'SerialSupplierWithoutGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (48, 83, 'Циклический цвет 10', true, 12975900, 0, 23, 'CycleColor10');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (49, 83, 'Циклический цвет 11', true, 16772351, 0, 24, 'CycleColor11');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (50, 83, 'Циклический цвет 12', true, 60138, 0, 25, 'CycleColor12');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (51, 83, 'Циклический цвет 13', true, 16744576, 16777215, 26, 'CycleColor13');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (60, 83, 'Циклический цвет 22', true, 8454143, 16711935, 27, 'CycleColor22');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (61, 83, 'Циклический цвет 23', true, 16777190, 0, 28, 'CycleColor23');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (62, 83, 'Циклический цвет 24', true, 16777215, 255, 29, 'CycleColor24');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (64, 83, 'Циклический цвет 26', true, 16777215, 16711680, 30, 'CycleColor26');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (84, 84, 'Серийные номера на складе гарантия просрочена', true, 16777215, 255, 31, 'SerialWithoutGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (85, 84, 'Серийные номера проданные с гарантией', true, 10878647, 255, 32, 'SerialSaleWithGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (86, 84, 'Серийные номера проданные гарантия просрочена', true, 65535, 255, 33, 'SerialSaleWithoutGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (88, 84, 'Серийные номера ожидаются с гарантийного ремонта, просрочена гарантия', true, 12975900, 255, 34, 'SerialWaitWithoutGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (89, 84, 'Серийные номера на временной замене', true, 12713915, 4210816, 35, 'SerialTemporaryWithGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (90, 84, 'Серийные номера на временной замене, просрочена гарантия', true, 12713915, 255, 36, 'SerialTemporaryWithoutGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (91, 84, 'Серийные номера на ремонте у поставщика происхождения', true, 16777058, 16711680, 37, 'SerialSupplierWithGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (93, 84, 'Серийные номера неизвестного происхождения', true, 16777181, 16711680, 38, 'SerialXWithGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (94, 84, 'Серийные номера неизвестного происхождения, просрочена гарантия', true, 16777181, 255, 39, 'SerialXWithoutGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (43, 83, 'Циклический цвет 05', true, 16777088, 0, 41, 'CycleColor5');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (44, 83, 'Циклический цвет 06', true, 14281983, 16711935, 42, 'CycleColor6');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (45, 83, 'Циклический цвет 07', true, 130763, 255, 43, 'CycleColor7');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (46, 83, 'Циклический цвет 08', true, 16708563, 0, 44, 'CycleColor8');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (47, 83, 'Циклический цвет 09', true, 16768991, 255, 45, 'CycleColor9');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (95, 84, 'Серийные номера замененные поставщиком', true, 16777215, 16711680, 47, 'SerialChangeSupplierWithGuaranty');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (71, 90, 'Горячая клавиша без клавиш сдвига', true, 16777215, 255, 57, 'HotKeyWithoutShift');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (72, 90, 'Пустая горячая клавиша', true, 16777215, 32768, 58, 'EmptyHotKey');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (73, 90, 'Шахматка: отрицательная сумма', true, 65535, 255, 59, 'ChessMinusSumma');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (74, 90, 'Шахматка: нейтральные проводки', true, 16777177, 16711680, 60, 'ChessNeutralConstr');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (75, 90, 'Шахматка: имена счетов', true, 65535, 0, 61, 'ChessAccount');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (76, 90, 'Шахматка: итоги', true, 16776960, 16711680, 62, 'ChessItog');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (77, 90, 'Машина времени / проводки / измененный счет', true, 65535, 255, 63, 'KalaYantra');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (80, 90, 'В диалоге цена меньше обычной', true, 65535, 32768, 64, 'InDialogPriceSmall');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (81, 90, 'В документе товар имеет нулевой остаток', true, 65535, 0, 65, 'InDialogCommodNullQuantity');
INSERT INTO public."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (103, 87, 'Сумма розничная и выше', true, 16777215, 0, 119, 'SummaRetail');


--
-- Data for Name: ColorKind; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (78, 72, 'Товар', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (83, 72, 'Циклический цвет', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (84, 72, 'Серийники', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (85, 72, 'Сервис-клиент', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (86, 72, 'Табель выходов', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (87, 72, 'Сумма', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (88, 72, 'Уценка товара', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (89, 72, 'Коварный пользователь', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (90, 72, 'Сборная солянка', true);
INSERT INTO public."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (72, 0, 'Цвета', true);


--
-- Data for Name: Commod; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (3, 2, 'ffdefdfd', true, 8);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (1, 1, 'Мячик', true, 2);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (2, 1, 'Гантеля', false, 44);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (6, 4, 'eweew', true, 2);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (7, 4, 'eeee', false, 2);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (11, 4, '555', true, 55);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (12, 60, 'Гиря', true, 2);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (13, 60, 'Биллиард', true, 3);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (10, 8, 'fggffg', true, 4);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (9, 8, 'gffg', true, 45);
INSERT INTO public."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (4, 3, 'Крыша', true, 6);


--
-- Data for Name: CommodKind; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (10, 2, 'Трикотах', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (28, 26, 'Сигары', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (29, 26, 'Шары', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (14, 3, 'Материнские платы', false, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (15, 3, 'SSD Накопители', false, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (26, 1, 'Дирижабли', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (5, 2, 'Пальто', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (9, 2, 'Трусы', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (12, 3, 'Корпуса', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (13, 3, 'Блоки питания', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (16, 3, 'HDD Накопители', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (17, 3, 'Принтеры', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (8, 2, 'Брюки2', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (23, 7, 'Сари', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (7, 2, 'Платья', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (6, 2, 'Рубашки', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (30, 12, 'Rere', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (31, 12, '232323232323', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (32, 31, 'eeee', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (33, 31, 'rereerrere', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (18, 3, 'Сетевое оборудование', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (22, 7, 'Повседневные', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (35, 34, 'Иволга', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (36, 34, 'уцууц', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (39, 38, 'rtrtrtrt', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (21, 7, 'Бальные', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (2, 1, 'Одежда', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (41, 38, 'rttrtrrrtrt', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (42, 41, 'ReRE', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (43, 41, '443ererer', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (46, 45, 'dfdfddfdfdfdffddf', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (48, 47, 'dddsdsdsdseterretrt', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (49, 28, 'Ангары', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (50, 49, 'Корпуса', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (51, 50, 'Кактуса', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (52, 51, 'Кучки', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (53, 52, 'Колючки', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (54, 53, 'Веревочки', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (55, 54, 'Маковочки', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (56, 37, '37', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (58, 29, 'Водяные', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (59, 58, 'Курукшетра', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (63, 62, 'dddsd', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (64, 63, 'asassa', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (66, 61, 'Джива итаттва', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (68, 67, 'dddsds', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (69, 68, 'fggfgffgfggf', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (4, 1, 'Мебель!', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (71, 70, 'ddddddsdsds!!', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (60, 29, 'Краска', false, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (3, 1, 'Компьютеры', false, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (95, 2, 'Панчо', true, NULL);
INSERT INTO public."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (1, 0, 'Товар', true, NULL);


--
-- Data for Name: Entity; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--



--
-- Data for Name: Kind; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Kind" ("KindID", "ParentID", "Kind", "Actual") VALUES (0, 0, 'Виды', true);


--
-- Data for Name: Language; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9760, 116, 'TfmvExplorer.fmvExplorer.Caption', true, 'Проводник "Джая Шрила Прабхупада"');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9761, 116, 'TfmvExplorer.coRes.TableUserReg', true, '"UserReg"');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9762, 116, 'TfmvExplorer.coRes.FieldUserRegKey', true, '"UserRegKey"');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9763, 116, 'TfmvExplorer.coRes.FieldUserData', true, '"UserData"');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9764, 116, 'TfmvExplorer.nwExamples.Rubl1', true, 'рубль');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9765, 116, 'TfmvExplorer.nwExamples.Rubl24', true, 'рубля');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9766, 116, 'TfmvExplorer.nwExamples.Rubl5', true, 'рублей');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9767, 116, 'TfmvExplorer.nwExamples.Copyica1', true, 'копейка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9768, 116, 'TfmvExplorer.nwExamples.Copyica24', true, 'копейки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9769, 116, 'TfmvExplorer.nwExamples.Copyica5', true, 'копеек');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9770, 116, 'TfmvExplorer.aActionListSetup.Caption', true, 'Горячие клавиши');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9771, 116, 'TfmvExplorer.aActionListSetup.Hint', true, 'Горячие клавиши');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9772, 116, 'TfmvExplorer.aRelease.Caption', true, 'Аварийное закрытие окна');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9773, 116, 'TfmvExplorer.aRelease.Hint', true, 'Аварийное закрытие окна');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9774, 116, 'TfmvExplorer.aClearCase.Caption', true, 'Пустой выбор');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9775, 116, 'TfmvExplorer.aClearCase.Hint', true, 'Пустой выбор');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9776, 116, 'TfmvExplorer.aPrepareLanguage.Caption', true, 'Подготовить язык');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9777, 116, 'TfmvExplorer.aPrepareLanguage.Hint', true, 'Подготовить язык');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9778, 116, 'TfmvExplorer.tsDB.Caption', true, 'База данных');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9779, 116, 'TfmvExplorer.tbrDBTree.Caption', true, 'tbrDBTree');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9780, 116, 'TfmvExplorer.tbDBAutoEdit.Caption', true, 'Авто-редактирование таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9781, 116, 'TfmvExplorer.tbDBAutoEdit.Hint', true, 'Авто-редактирование таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9782, 116, 'TfmvExplorer.tbRowInspector.Caption', true, 'Инспектор строки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9783, 116, 'TfmvExplorer.tbRowInspector.Hint', true, 'Инспектор строки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9784, 116, 'TfmvExplorer.tbDBSelectAll.Caption', true, 'Выделить все');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9785, 116, 'TfmvExplorer.tbDBSelectAll.Hint', true, 'Выделить все');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9786, 116, 'TfmvExplorer.tbDBCut.Caption', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9787, 116, 'TfmvExplorer.tbDBCut.Hint', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9788, 116, 'TfmvExplorer.tbDBCopy.Caption', true, 'Копировать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9789, 116, 'TfmvExplorer.tbDBCopy.Hint', true, 'Копировать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9790, 116, 'TfmvExplorer.tbDBPaste.Caption', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9791, 116, 'TfmvExplorer.tbDBPaste.Hint', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9792, 116, 'TfmvExplorer.tbDBMerge.Caption', true, 'Слить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9793, 116, 'TfmvExplorer.tbDBMerge.Hint', true, 'Слить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9794, 116, 'TfmvExplorer.tbDBCachedUpdates.Caption', true, 'Кэшировать данные');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9795, 116, 'TfmvExplorer.tbDBCachedUpdates.Hint', true, 'Кэшировать данные');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9796, 116, 'TfmvExplorer.tbRemeberRow.Caption', true, 'Запомнить строку');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9797, 116, 'TfmvExplorer.tbRemeberRow.Hint', true, 'Запомнить строку');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9798, 116, 'TfmvExplorer.tbStoreData.Caption', true, 'Установить поля строк');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9799, 116, 'TfmvExplorer.tbStoreData.Hint', true, 'Установить поля строк');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9800, 116, 'TfmvExplorer.tbTVNodeAdminReload.Caption', true, 'Обновить ветку дерева');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9801, 116, 'TfmvExplorer.tbTVNodeAdminReload.Hint', true, 'Обновить ветку дерева');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9802, 116, 'TfmvExplorer.tbDBTreeViewReload.Caption', true, 'Обновить всё дерево');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9803, 116, 'TfmvExplorer.tbDBTreeViewReload.Hint', true, 'Обновить всё дерево');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9804, 116, 'TfmvExplorer.tbDBTreeNodeActualInvert.Caption', true, 'Инвертировать актуальность веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9805, 116, 'TfmvExplorer.tbDBTreeNodeActualInvert.Hint', true, 'Инвертировать актуальность веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9806, 116, 'TfmvExplorer.tbDBTreeViewActualOnly.Caption', true, 'Только актуальные веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9807, 116, 'TfmvExplorer.tbDBTreeViewActualOnly.Hint', true, 'Только актуальные веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9808, 116, 'TfmvExplorer.tbDBTreeViewEndToEndViewing.Caption', true, 'Сквозной просмотр');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9809, 116, 'TfmvExplorer.tbDBTreeViewEndToEndViewing.Hint', true, 'Сквозной просмотр');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9810, 116, 'TfmvExplorer.tbDBTreeNodePrev.Caption', true, 'Предыдущая веточка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9811, 116, 'TfmvExplorer.tbDBTreeNodePrev.Hint', true, 'Предыдущая
веточка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9812, 116, 'TfmvExplorer.tbDBTreeNodeNext.Caption', true, 'Следующая веточка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9813, 116, 'TfmvExplorer.tbDBTreeNodeNext.Hint', true, 'Следующая
веточка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9814, 116, 'TfmvExplorer.deKindID.Hint', true, 'Номер веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9815, 116, 'TfmvExplorer.tsSetup.Caption', true, 'Настройка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9816, 116, 'TfmvExplorer.tsSetup.Hint', true, 'Настройка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9817, 116, 'TfmvExplorer.tbrSetup.Caption', true, 'tbrSetup');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9818, 116, 'TfmvExplorer.tbActionListSetup.Caption', true, 'Горячие клавиши');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9819, 116, 'TfmvExplorer.tbActionListSetup.Hint', true, 'Горячие клавиши');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9820, 116, 'TfmvExplorer.tbDBGridProperty.Caption', true, 'Свойства таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9821, 116, 'TfmvExplorer.tbDBGridProperty.Hint', true, 'Свойства таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9822, 116, 'TfmvExplorer.tbAutoMergeMainMenu.Caption', true, 'Слить главное меню');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9823, 116, 'TfmvExplorer.tbAutoMergeMainMenu.Hint', true, 'Слить главное меню');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9824, 116, 'TfmvExplorer.cbEnterKind.Text', true, 'Обычный');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9825, 116, 'TfmvExplorer.cbEnterKind.Hint', true, 'Тип Enter');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9826, 116, 'TfmvExplorer.tbRelease.Caption', true, 'Аварийное закрытие окна');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9827, 116, 'TfmvExplorer.tbRelease.Hint', true, 'Аварийное закрытие окна');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9828, 116, 'TfmvExplorer.tbClearCase.Caption', true, 'Пустой выбор');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9829, 116, 'TfmvExplorer.tbClearCase.Hint', true, 'Пустой выбор');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9830, 116, 'TfmvExplorer.tbPrepareLanguage.Caption', true, 'Подготовить язык');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9831, 116, 'TfmvExplorer.tbPrepareLanguage.Hint', true, 'Подготовить язык');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9832, 116, 'TfmvExplorer.tbrDB.Caption', true, 'tbrDB');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9833, 116, 'TfmvExplorer.tbDBSearch.Caption', true, 'Найти');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9834, 116, 'TfmvExplorer.tbDBSearch.Hint', true, 'Найти');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9835, 116, 'TfmvExplorer.tbDBQuickSearch.Caption', true, 'Быстрый поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9836, 116, 'TfmvExplorer.tbDBQuickSearch.Hint', true, 'Быстрый поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9837, 116, 'TfmvExplorer.tbDBSearchNext.Caption', true, 'Найти далее');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9838, 116, 'TfmvExplorer.tbDBSearchNext.Hint', true, 'Найти далее');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9839, 116, 'TfmvExplorer.tbDBSearchReset.Caption', true, 'Прервать поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9840, 116, 'TfmvExplorer.tbDBSearchReset.Hint', true, 'Прервать поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9841, 116, 'TfmvExplorer.tbrStatus.Caption', true, 'tbrStatus');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9842, 116, 'TfmvExplorer.tbEraseFilterSearch.Caption', true, 'Удалить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9843, 116, 'TfmvExplorer.tbEraseFilterSearch.Hint', true, 'Удалить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9844, 116, 'TfmvExplorer.tbDBSearchVectorClear.Caption', true, 'Очистить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9845, 116, 'TfmvExplorer.tbDBSearchVectorClear.Hint', true, 'Очистить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9846, 116, 'TfmvExplorer.aDBGridProperty.Caption', true, 'Свойства таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9847, 116, 'TfmvExplorer.aDBGridProperty.Hint', true, 'Свойства таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9848, 116, 'TfmvExplorer.aDBCut.Caption', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9849, 116, 'TfmvExplorer.aDBCut.Hint', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9850, 116, 'TfmvExplorer.aDBCopy.Caption', true, 'Копировать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9851, 116, 'TfmvExplorer.aDBCopy.Hint', true, 'Копировать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9852, 116, 'TfmvExplorer.aDBPaste.Caption', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9853, 116, 'TfmvExplorer.aDBPaste.Hint', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9854, 116, 'TfmvExplorer.aDBMerge.Caption', true, 'Слить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9855, 116, 'TfmvExplorer.aDBMerge.Hint', true, 'Слить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9856, 116, 'TfmvExplorer.aDBCachedUpdates.Caption', true, 'Кэшировать данные');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9857, 116, 'TfmvExplorer.aDBCachedUpdates.Hint', true, 'Кэшировать данные');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9858, 116, 'TfmvExplorer.aDBAutoEdit.Caption', true, 'Авто-редактирование таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9859, 116, 'TfmvExplorer.aDBAutoEdit.Hint', true, 'Авто-редактирование таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9860, 116, 'TfmvExplorer.aRemeberRow.Caption', true, 'Запомнить строку');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9861, 116, 'TfmvExplorer.aRemeberRow.Hint', true, 'Запомнить строку');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9862, 116, 'TfmvExplorer.aStoreData.Caption', true, 'Установить поля строк');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9863, 116, 'TfmvExplorer.aStoreData.Hint', true, 'Установить поля строк');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9864, 116, 'TfmvExplorer.aTVNodeAdminReload.Caption', true, 'Обновить ветку дерева');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9865, 116, 'TfmvExplorer.aTVNodeAdminReload.Hint', true, 'Обновить ветку дерева');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9866, 116, 'TfmvExplorer.aDBTreeViewReload.Caption', true, 'Обновить всё дерево');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9867, 116, 'TfmvExplorer.aDBTreeViewReload.Hint', true, 'Обновить всё дерево');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9868, 116, 'TfmvExplorer.aDBTreeViewNodeActualInvert.Caption', true, 'Инвертировать актуальность веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9869, 116, 'TfmvExplorer.aDBTreeViewNodeActualInvert.Hint', true, 'Инвертировать актуальность веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9870, 116, 'TfmvExplorer.aDBTreeViewActualOnly.Caption', true, 'Только актуальные веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9871, 116, 'TfmvExplorer.aDBTreeViewActualOnly.Hint', true, 'Только актуальные веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9872, 116, 'TfmvExplorer.aTVNodeAdminPrint.Caption', true, 'Печать ветки дерева');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9873, 116, 'TfmvExplorer.aTVNodeAdminPrint.Hint', true, 'Печать ветки дерева');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9874, 116, 'TfmvExplorer.aDBTreeViewEndToEndViewing.Caption', true, 'Сквозной просмотр');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9875, 116, 'TfmvExplorer.aDBTreeViewEndToEndViewing.Hint', true, 'Сквозной просмотр');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9876, 116, 'TfmvExplorer.aAutoMergeMainMenu.Caption', true, 'Слить главное меню');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9877, 116, 'TfmvExplorer.aAutoMergeMainMenu.Hint', true, 'Слить главное меню');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9878, 116, 'TfmvExplorer.aDBSearch.Caption', true, 'Найти');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9879, 116, 'TfmvExplorer.aDBSearch.Hint', true, 'Найти');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9880, 116, 'TfmvExplorer.aDBSearchNext.Caption', true, 'Найти далее');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9881, 116, 'TfmvExplorer.aDBSearchNext.Hint', true, 'Найти далее');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9882, 116, 'TfmvExplorer.aDBQuickSearch.Caption', true, 'Быстрый поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9883, 116, 'TfmvExplorer.aDBQuickSearch.Hint', true, 'Быстрый поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9884, 116, 'TfmvExplorer.aDBSearchReset.Caption', true, 'Прервать поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9885, 116, 'TfmvExplorer.aDBSearchReset.Hint', true, 'Прервать поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9886, 116, 'TfmvExplorer.aEraseFilterSearch.Caption', true, 'Удалить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9887, 116, 'TfmvExplorer.aEraseFilterSearch.Hint', true, 'Удалить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9888, 116, 'TfmvExplorer.aDBTreeNodePrev.Caption', true, 'Предыдущая веточка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9889, 116, 'TfmvExplorer.aDBTreeNodePrev.Hint', true, 'Предыдущая
веточка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9890, 116, 'TfmvExplorer.aDBTreeNodeNext.Caption', true, 'Следующая веточка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9891, 116, 'TfmvExplorer.aDBTreeNodeNext.Hint', true, 'Следующая
веточка');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9892, 116, 'TfmvExplorer.aDBSelectAll.Caption', true, 'Выделить все');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9893, 116, 'TfmvExplorer.aDBSelectAll.Hint', true, 'Выделить все');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9894, 116, 'TfmvExplorer.aDBSearchVectorClear.Caption', true, 'Очистить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9895, 116, 'TfmvExplorer.aDBSearchVectorClear.Hint', true, 'Очистить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9896, 116, 'TfmvExplorer.aRowInspector.Caption', true, 'Инспектор строки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9897, 116, 'TfmvExplorer.aRowInspector.Hint', true, 'Инспектор строки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9898, 116, 'TfmvExplorer.miDB.Caption', true, 'База данных');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9899, 116, 'TfmvExplorer.miDBAutoEdit.Caption', true, 'Авто-редактирование таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9900, 116, 'TfmvExplorer.miDBAutoEdit.Hint', true, 'Авто-редактирование таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9901, 116, 'TfmvExplorer.miDBSelectAll.Caption', true, 'Выделить все');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9902, 116, 'TfmvExplorer.miDBSelectAll.Hint', true, 'Выделить все');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9903, 116, 'TfmvExplorer.miDBCut.Caption', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9904, 116, 'TfmvExplorer.miDBCut.Hint', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9905, 116, 'TfmvExplorer.miDBCopy.Caption', true, 'Копировать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9906, 116, 'TfmvExplorer.miDBCopy.Hint', true, 'Копировать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9907, 116, 'TfmvExplorer.miDBPaste.Caption', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9908, 116, 'TfmvExplorer.miDBPaste.Hint', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9909, 116, 'TfmvExplorer.miDBMerge.Caption', true, 'Слить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9910, 116, 'TfmvExplorer.miDBMerge.Hint', true, 'Слить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9911, 116, 'TfmvExplorer.miDBCachedUpdates.Caption', true, 'Кэшировать данные');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9912, 116, 'TfmvExplorer.miDBCachedUpdates.Hint', true, 'Кэшировать данные');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9913, 116, 'TfmvExplorer.miRemeberRow.Caption', true, 'Запомнить строку');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9914, 116, 'TfmvExplorer.miRemeberRow.Hint', true, 'Запомнить строку');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9915, 116, 'TfmvExplorer.miStoreData.Caption', true, 'Установить поля строк');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9916, 116, 'TfmvExplorer.miStoreData.Hint', true, 'Установить поля строк');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9917, 116, 'TfmvExplorer.miTVNodeAdminReload.Caption', true, 'Обновить ветку дерева');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9918, 116, 'TfmvExplorer.miTVNodeAdminReload.Hint', true, 'Обновить ветку дерева');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9919, 116, 'TfmvExplorer.miDBTreeViewReload.Caption', true, 'Обновить всё дерево');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9920, 116, 'TfmvExplorer.miDBTreeViewReload.Hint', true, 'Обновить всё дерево');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9921, 116, 'TfmvExplorer.miDBTreeViewNodeActualInvert.Caption', true, 'Инвертировать актуальность веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9922, 116, 'TfmvExplorer.miDBTreeViewNodeActualInvert.Hint', true, 'Инвертировать актуальность веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9923, 116, 'TfmvExplorer.miDBTreeViewActualOnly.Caption', true, 'Только актуальные веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9924, 116, 'TfmvExplorer.miDBTreeViewActualOnly.Hint', true, 'Только актуальные веточки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9925, 116, 'TfmvExplorer.miDBTreeViewEndToEndViewing.Caption', true, 'Сквозной просмотр');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9926, 116, 'TfmvExplorer.miDBTreeViewEndToEndViewing.Hint', true, 'Сквозной просмотр');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9927, 116, 'TfmvExplorer.miDBSearch.Caption', true, 'Найти');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9928, 116, 'TfmvExplorer.miDBSearch.Hint', true, 'Найти');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9929, 116, 'TfmvExplorer.miDBSearchNext.Caption', true, 'Найти далее');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9930, 116, 'TfmvExplorer.miDBSearchNext.Hint', true, 'Найти далее');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9931, 116, 'TfmvExplorer.miDBSearchReset.Caption', true, 'Прервать поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9932, 116, 'TfmvExplorer.miDBSearchReset.Hint', true, 'Прервать поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9933, 116, 'TfmvExplorer.miSearchEdit.Caption', true, 'Быстрый поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9934, 116, 'TfmvExplorer.miSearchEdit.Hint', true, 'Быстрый поиск');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9935, 116, 'TfmvExplorer.miEraseFilterSearch.Caption', true, 'Удалить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9936, 116, 'TfmvExplorer.miEraseFilterSearch.Hint', true, 'Удалить фильтр поиска');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9937, 116, 'TfmvExplorer.miRowInspector.Caption', true, 'Инспектор строки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9938, 116, 'TfmvExplorer.miRowInspector.Hint', true, 'Инспектор строки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9939, 116, 'TfmvExplorer.miDBProperty.Caption', true, 'Свойства');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9940, 116, 'TfmvExplorer.miActionListSetup.Caption', true, 'Горячие клавиши');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9941, 116, 'TfmvExplorer.miActionListSetup.Hint', true, 'Горячие клавиши');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9942, 116, 'TfmvExplorer.miDBGridProperty.Caption', true, 'Свойства таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9943, 116, 'TfmvExplorer.miDBGridProperty.Hint', true, 'Свойства таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9944, 116, 'TfmvExplorer.miAutoMergeMainMenu.Caption', true, 'Слить главное меню');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9945, 116, 'TfmvExplorer.miAutoMergeMainMenu.Hint', true, 'Слить главное меню');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9946, 116, 'TfmvExplorer.miRelease.Caption', true, 'Аварийное закрытие окна');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9947, 116, 'TfmvExplorer.miRelease.Hint', true, 'Аварийное закрытие окна');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9948, 116, 'TfmvExplorer.miClearCase.Caption', true, 'Пустой выбор');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9949, 116, 'TfmvExplorer.miClearCase.Hint', true, 'Пустой выбор');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9950, 116, 'TfmvExplorer.miPrepareLanguage.Caption', true, 'Подготовить язык');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9951, 116, 'TfmvExplorer.miPrepareLanguage.Hint', true, 'Подготовить язык');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9952, 116, 'TfmvExplorer.mipDBCut.Caption', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9953, 116, 'TfmvExplorer.mipDBCut.Hint', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9954, 116, 'TfmvExplorer.mipDBCopy.Caption', true, 'Копировать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9955, 116, 'TfmvExplorer.mipDBCopy.Hint', true, 'Копировать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9956, 116, 'TfmvExplorer.mipDBPaste.Caption', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9957, 116, 'TfmvExplorer.mipDBPaste.Hint', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9958, 116, 'TfmvExplorer.mipDBMerge.Caption', true, 'Слить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9959, 116, 'TfmvExplorer.mipDBMerge.Hint', true, 'Слить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9960, 116, 'TfmvExplorer.mipDBGridSeparator.Caption', true, '-');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9961, 116, 'TfmvExplorer.mipDBAutoEdit.Caption', true, 'Авто-редактирование таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9962, 116, 'TfmvExplorer.mipDBAutoEdit.Hint', true, 'Авто-редактирование таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9963, 116, 'TfmvExplorer.mipDBCachedUpdates.Caption', true, 'Кэшировать данные');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9964, 116, 'TfmvExplorer.mipDBCachedUpdates.Hint', true, 'Кэшировать данные');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9965, 116, 'TfmvExplorer.mipRemeberRow.Caption', true, 'Запомнить строку');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9966, 116, 'TfmvExplorer.mipRemeberRow.Hint', true, 'Запомнить строку');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9967, 116, 'TfmvExplorer.mipStoreData.Caption', true, 'Установить поля строк');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9968, 116, 'TfmvExplorer.mipStoreData.Hint', true, 'Установить поля строк');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9969, 116, 'TfmvExplorer.mipDBSelectAll.Caption', true, 'Выделить все');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9970, 116, 'TfmvExplorer.mipDBSelectAll.Hint', true, 'Выделить все');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9971, 116, 'TfmvExplorer.mipDBGridProperty.Caption', true, 'Свойства таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9972, 116, 'TfmvExplorer.mipDBGridProperty.Hint', true, 'Свойства таблицы');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9973, 116, 'TfmvExplorer.mipRowInspector.Caption', true, 'Инспектор строки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9974, 116, 'TfmvExplorer.mipRowInspector.Hint', true, 'Инспектор строки');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9975, 116, 'TfmvExplorer.mitDBCut.Caption', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9976, 116, 'TfmvExplorer.mitDBCut.Hint', true, 'Вырезать');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9977, 116, 'TfmvExplorer.mitDBPaste.Caption', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9978, 116, 'TfmvExplorer.mitDBPaste.Hint', true, 'Вставить');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9979, 116, 'TfmvExplorer.laNumberToWords.Caption', true, 'Введите число и нажмите Enter!');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9980, 116, 'TfmvExplorer.edNumberToWords.Text', true, '1234567890');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9981, 116, 'TfmvExplorer.laEntityCommodID.Caption', true, 'Товар ИД');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9982, 116, 'TfmvExplorer.laKindCommodID1q.Caption', true, 'Вид товара ИД');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9983, 116, 'TfmvExplorer.laEntityCommod.Caption', true, 'Товар');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9984, 116, 'TfmvExplorer.laPriceCommod.Caption', true, 'Цена');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9985, 116, 'TfmvExplorer.edEntityCommodID.DataField', true, 'EntityID');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9986, 116, 'TfmvExplorer.edKindCommodID.DataField', true, 'KindID');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9987, 116, 'TfmvExplorer.edEntityCommod.DataField', true, 'Entity');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9988, 116, 'TfmvExplorer.dePriceCommod.DataField', true, 'Price');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9989, 116, 'TfmvExplorer.tbColor.Caption', true, 'tbColor');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9990, 116, 'TfmvExplorer.tbColorIndexGenerate.Caption', true, 'Генерация индексов цветов');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9991, 116, 'TfmvExplorer.tbColorIndexGenerate.Hint', true, 'Генерация индексов цветов');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9992, 116, 'TfmvExplorer.tbGenerateColorConsts.Caption', true, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9993, 116, 'TfmvExplorer.tbGenerateColorConsts.Hint', true, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9994, 116, 'TfmvExplorer.tbGenerateColorConstsWithoutIndex.Caption', true, 'Создание списка констант цветов для *.h');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9995, 116, 'TfmvExplorer.tbGenerateColorConstsWithoutIndex.Hint', true, 'Создание списка констант цветов для *.h');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9996, 116, 'TfmvExplorer.paFonValueChange.Caption', true, 'Пример');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9997, 116, 'TfmvExplorer.paFonValueChange.Hint', true, 'Цвет фона элементов ввода диапазонов');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9998, 116, 'TfmvExplorer.paFontValueChange.Hint', true, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (9999, 116, 'TfmvExplorer.tbrRights.Caption', true, 'tbrRights');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10000, 116, 'TfmvExplorer.tbRightsIndexGenerate.Caption', true, 'Генерация индексов прав');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10001, 116, 'TfmvExplorer.tbRightsIndexGenerate.Hint', true, 'Генерация индексов прав');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10002, 116, 'TfmvExplorer.tbGenerateRightsConsts.Caption', true, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10003, 116, 'TfmvExplorer.tbGenerateRightsConsts.Hint', true, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10004, 116, 'TfmvExplorer.tbGenerateRightsConstsWithoutIndex.Caption', true, 'Создание списка констант прав для *.h');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10005, 116, 'TfmvExplorer.tbGenerateRightsConstsWithoutIndex.Hint', true, 'Создание списка констант прав для *.h');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10006, 116, 'TfmvExplorer.tbrUsers.Caption', true, 'tbrUsers');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10007, 116, 'TfmvExplorer.tbNewUser.Caption', true, 'Создать пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10008, 116, 'TfmvExplorer.tbNewUser.Hint', true, 'Создать пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10009, 116, 'TfmvExplorer.tbSetUserPassord.Caption', true, 'Задать пароль пользователю');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10010, 116, 'TfmvExplorer.tbSetUserPassord.Hint', true, 'Задать пароль пользователю');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10011, 116, 'TfmvExplorer.tbDeleteUser.Caption', true, 'Удалить пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10012, 116, 'TfmvExplorer.tbDeleteUser.Hint', true, 'Удалить пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10013, 116, 'TfmvExplorer.tbNewSuperUser.Caption', true, 'Создать супер пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10014, 116, 'TfmvExplorer.tbNewSuperUser.Hint', true, 'Создать супер пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10015, 116, 'TfmvExplorer.tbGrantSuperUser.Caption', true, 'Дать права суперпользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10016, 116, 'TfmvExplorer.tbGrantSuperUser.Hint', true, 'Дать права суперпользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10017, 116, 'TfmvExplorer.tbRevokeSuperUser.Caption', true, 'Забрать права суперпользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10018, 116, 'TfmvExplorer.tbRevokeSuperUser.Hint', true, 'Забрать права суперпользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10019, 116, 'TfmvExplorer.ddtUsersPassportDate.DataField', true, 'Anketa.PassportDate');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10020, 116, 'TfmvExplorer.ddtUsersPassportDate.FormatStr', true, 'dd.mm.yyyy');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10021, 116, 'TfmvExplorer.ddtUsersPassportDate.EditMask', true, '!99/99/9999;1;_');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10022, 116, 'TfmvExplorer.ddtUsersPassportDate.Text', true, '02.10.2022');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10023, 116, 'TfmvExplorer.ddtUsersPassportDate.EditText', true, '02.10.2022');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10024, 116, 'TfmvExplorer.dcbUsersNote.DataField', true, 'Note');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10025, 116, 'TfmvExplorer.ddtUsersBirthDate.DataField', true, 'BirthDate');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10026, 116, 'TfmvExplorer.ddtUsersBirthDate.FormatStr', true, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10027, 116, 'TfmvExplorer.ddtUsersBirthDate.EditMask', true, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10028, 116, 'TfmvExplorer.ddtUsersBirthDate.Text', true, '02.10.2022 11:50:33');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10029, 116, 'TfmvExplorer.ddtUsersBirthDate.EditText', true, '02.10.2022 11:50:33');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10030, 116, 'TfmvExplorer.ddtUsersCreateDate.DataField', true, 'CreateDate');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10031, 116, 'TfmvExplorer.ddtUsersCreateDate.FormatStr', true, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10032, 116, 'TfmvExplorer.ddtUsersCreateDate.EditMask', true, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10033, 116, 'TfmvExplorer.ddtUsersCreateDate.Text', true, '02.10.2022 11:50:33');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10034, 116, 'TfmvExplorer.ddtUsersCreateDate.EditText', true, '02.10.2022 11:50:33');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10035, 116, 'TfmvExplorer.tbrRole.Caption', true, 'tbrRole');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10036, 116, 'TfmvExplorer.tbrGolovolomka15.Caption', true, 'tbrGolovolomka15');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10037, 116, 'TfmvExplorer.tbGolovolomka15StartPosition.Caption', true, 'Стартовая позиция');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10038, 116, 'TfmvExplorer.tbGolovolomka15StartPosition.Hint', true, 'Стартовая позиция');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10039, 116, 'TfmvExplorer.tbGolovolomka15Mix.Caption', true, 'Головоломка 15');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10040, 116, 'TfmvExplorer.tbGolovolomka15Mix.Hint', true, 'Головоломка 15');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10041, 116, 'TfmvExplorer.nbGolovolomka15MixCount.CurrencyString', true, '?');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10042, 116, 'TfmvExplorer.nbGolovolomka15MixCount.Text', true, '25');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10043, 116, 'TfmvExplorer.nbGolovolomka15MixCount.Hint', true, 'Сколько ходов перемешивать?');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10044, 116, 'TfmvExplorer.nbGolovolomka15HodPause.CurrencyString', true, '?');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10045, 116, 'TfmvExplorer.nbGolovolomka15HodPause.Text', true, '300');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10046, 116, 'TfmvExplorer.nbGolovolomka15HodPause.Hint', true, 'Пауза при перемешивании в миллисекундах');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10047, 116, 'TfmvExplorer.aRightsIndexGenerate.Caption', true, 'Генерация индексов прав');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10048, 116, 'TfmvExplorer.aRightsIndexGenerate.Hint', true, 'Генерация индексов прав');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10049, 116, 'TfmvExplorer.aNewUser.Caption', true, 'Создать пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10050, 116, 'TfmvExplorer.aNewUser.Hint', true, 'Создать пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10051, 116, 'TfmvExplorer.aSetUserPassord.Caption', true, 'Задать пароль пользователю');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10052, 116, 'TfmvExplorer.aSetUserPassord.Hint', true, 'Задать пароль пользователю');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10053, 116, 'TfmvExplorer.aDeleteUser.Caption', true, 'Удалить пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10054, 116, 'TfmvExplorer.aDeleteUser.Hint', true, 'Удалить пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10055, 116, 'TfmvExplorer.aColorIndexGenerate.Caption', true, 'Генерация индексов цветов');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10056, 116, 'TfmvExplorer.aColorIndexGenerate.Hint', true, 'Генерация индексов цветов');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10057, 116, 'TfmvExplorer.aGenerateColorConsts.Caption', true, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10058, 116, 'TfmvExplorer.aGenerateColorConsts.Hint', true, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10059, 116, 'TfmvExplorer.aGenerateColorConstsWithoutIndex.Caption', true, 'Создание списка констант цветов для *.h');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10060, 116, 'TfmvExplorer.aGenerateColorConstsWithoutIndex.Hint', true, 'Создание списка констант цветов для *.h');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10061, 116, 'TfmvExplorer.aNewSuperUser.Caption', true, 'Создать супер пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10062, 116, 'TfmvExplorer.aNewSuperUser.Hint', true, 'Создать супер пользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10063, 116, 'TfmvExplorer.aGrantSuperUser.Caption', true, 'Дать права суперпользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10064, 116, 'TfmvExplorer.aGrantSuperUser.Hint', true, 'Дать права суперпользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10065, 116, 'TfmvExplorer.aRevokeSuperUser.Caption', true, 'Забрать права суперпользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10066, 116, 'TfmvExplorer.aRevokeSuperUser.Hint', true, 'Забрать права суперпользователя');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10067, 116, 'TfmvExplorer.aGenerateRightsConsts.Caption', true, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10068, 116, 'TfmvExplorer.aGenerateRightsConsts.Hint', true, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10069, 116, 'TfmvExplorer.aGenerateRightsConstsWithoutIndex.Caption', true, 'Создание списка констант прав для *.h');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10070, 116, 'TfmvExplorer.aGenerateRightsConstsWithoutIndex.Hint', true, 'Создание списка констант прав для *.h');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10071, 116, 'TfmvExplorer.aGolovolomka15StartPosition.Caption', true, 'Стартовая позиция');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10072, 116, 'TfmvExplorer.aGolovolomka15StartPosition.Hint', true, 'Стартовая позиция');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10073, 116, 'TfmvExplorer.aGolovolomka15Mix.Caption', true, 'Головоломка 15');
INSERT INTO public."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10074, 116, 'TfmvExplorer.aGolovolomka15Mix.Hint', true, 'Головоломка 15');


--
-- Data for Name: LanguageKind; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."LanguageKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (115, NULL, 'Язык', true);
INSERT INTO public."LanguageKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (117, 115, 'TForm2', true);
INSERT INTO public."LanguageKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (116, 115, 'TfmvExplorer', true);


--
-- Data for Name: Languages; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (2, 'EN-US', 'English');
INSERT INTO public."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (3, 'ES-ES', 'Espanol');
INSERT INTO public."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (4, 'CS-CZ', 'Cesky');
INSERT INTO public."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (5, 'PT-BR', 'Portugues');
INSERT INTO public."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (1, 'RU-RU', 'Русский');


--
-- Data for Name: Rights; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (152, 91, 'Редактирование пользователей', true, 'UserEdit', 0);
INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (177, 91, 'Редактировать права', true, 'RightsEdit', 1);
INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (154, 91, 'Редактировать товар', true, 'CommodEdit', 2);
INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (176, 91, 'Редактировать цвета', true, 'ColorEdit', 3);
INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (153, 91, 'Ссоздавать роли', true, 'RoleEdit', 4);
INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (174, 96, ' Право счет фактура', true, 'SchetFactura', 5);
INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (186, 96, 'ffddrf', true, NULL, 0);
INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (3405, 91, 'Редактировать языки программы', true, 'LanguagesEdit', 6);
INSERT INTO public."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (3406, 91, 'Редактировать строки для разных языков программы', true, 'LanguageStringEdit', 7);


--
-- Data for Name: RightsKind; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."RightsKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (91, 79, 'Управление', true);
INSERT INTO public."RightsKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (96, 79, 'Торговля', true);
INSERT INTO public."RightsKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (79, 0, 'Права', true);


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (155, 82, 'Менеджер', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (156, 82, 'Стажер', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (157, 82, 'Кассир', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (160, 92, 'Кассир', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (161, 92, 'Приёмщик', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (162, 82, 'Кладовщик', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (166, 92, 'Мастер', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (169, 93, 'Rere', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (170, 93, 'Куку', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (171, 93, 'Малина', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (172, 94, 'Миша', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (173, 93, 'Калина', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (175, 82, 'Каменщик', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (167, 93, 'Турагент', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (168, 93, 'Турист', true);
INSERT INTO public."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (187, 80, 'Программист', true);


--
-- Data for Name: RoleKind; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (82, 80, 'Торговля', true);
INSERT INTO public."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (92, 80, 'Сервисный центр', true);
INSERT INTO public."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (94, 93, 'Михаил Светлов', true);
INSERT INTO public."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (93, 80, 'Туризм', true);
INSERT INTO public."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (80, 0, 'Роли', true);


--
-- Data for Name: RoleRights; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (15, 166, 174);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (18, 160, 174);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (19, 187, 152);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (20, 187, 177);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (21, 187, 154);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (22, 187, 176);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (23, 187, 153);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (24, 187, 174);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (25, 187, 186);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (26, 187, 3405);
INSERT INTO public."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (27, 187, 3406);


--
-- Data for Name: Translate; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25739, 9761, 4, '"UserReg"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25740, 9761, 2, '"UserReg"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25741, 9761, 3, '"UserReg"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25742, 9761, 5, '"UserReg"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25743, 9762, 4, '"UserRegKey"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25744, 9762, 2, '"UserRegKey"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25745, 9762, 3, '"UserRegKey"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25746, 9762, 5, '"UserRegKey"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25747, 9763, 4, '"UserData"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25748, 9763, 2, '"UserData"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25749, 9763, 3, '"UserData"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25750, 9763, 5, '"UserData"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25751, 9764, 4, 'рубль');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25752, 9764, 2, 'рубль');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25753, 9764, 3, 'рубль');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25754, 9764, 5, 'рубль');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25755, 9765, 4, 'рубля');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25756, 9765, 2, 'рубля');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25757, 9765, 3, 'рубля');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25758, 9765, 5, 'рубля');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25759, 9766, 4, 'рублей');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25760, 9766, 2, 'рублей');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25761, 9766, 3, 'рублей');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25762, 9766, 5, 'рублей');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25763, 9767, 4, 'копейка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25764, 9767, 2, 'копейка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25765, 9767, 3, 'копейка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25766, 9767, 5, 'копейка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25767, 9768, 4, 'копейки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25768, 9768, 2, 'копейки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25769, 9768, 3, 'копейки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25770, 9768, 5, 'копейки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25771, 9769, 4, 'копеек');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25772, 9769, 2, 'копеек');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25773, 9769, 3, 'копеек');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25774, 9769, 5, 'копеек');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25775, 9770, 4, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25776, 9770, 2, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25777, 9770, 3, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25778, 9770, 5, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25779, 9771, 4, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25780, 9771, 2, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25781, 9771, 3, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25782, 9771, 5, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25783, 9772, 4, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25784, 9772, 2, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25785, 9772, 3, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25786, 9772, 5, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25787, 9773, 4, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25788, 9773, 2, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25789, 9773, 3, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25790, 9773, 5, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25791, 9774, 4, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25792, 9774, 2, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25793, 9774, 3, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25794, 9774, 5, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25795, 9775, 4, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25796, 9775, 2, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25797, 9775, 3, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25798, 9775, 5, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25799, 9776, 4, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25800, 9776, 2, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25801, 9776, 3, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25802, 9776, 5, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25803, 9777, 4, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25804, 9777, 2, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25805, 9777, 3, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25806, 9777, 5, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25807, 9778, 4, 'База данных');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25808, 9778, 2, 'База данных');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25809, 9778, 3, 'База данных');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25810, 9778, 5, 'База данных');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25811, 9779, 4, 'tbrDBTree');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25812, 9779, 2, 'tbrDBTree');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25813, 9779, 3, 'tbrDBTree');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25814, 9779, 5, 'tbrDBTree');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25815, 9780, 4, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25816, 9780, 2, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25817, 9780, 3, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25818, 9780, 5, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25819, 9781, 4, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25820, 9781, 2, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25821, 9781, 3, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25822, 9781, 5, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25823, 9782, 4, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25824, 9782, 2, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25825, 9782, 3, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25826, 9782, 5, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25827, 9783, 4, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25828, 9783, 2, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25829, 9783, 3, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25830, 9783, 5, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25831, 9784, 4, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25832, 9784, 2, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25833, 9784, 3, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25834, 9784, 5, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25835, 9785, 4, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25735, 9760, 4, 'Průvodce "Jaya Srila Prabhupada"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25737, 9760, 3, 'Guia De "Jaya Srila Prabhupada"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25738, 9760, 5, 'Guia De "Jaya Srila Prabhupada"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25836, 9785, 2, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25837, 9785, 3, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25838, 9785, 5, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25839, 9786, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25840, 9786, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25841, 9786, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25842, 9786, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25843, 9787, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25844, 9787, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25845, 9787, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25846, 9787, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25847, 9788, 4, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25848, 9788, 2, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25849, 9788, 3, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25850, 9788, 5, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25851, 9789, 4, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25852, 9789, 2, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25853, 9789, 3, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25854, 9789, 5, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25855, 9790, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25856, 9790, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25857, 9790, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25858, 9790, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25859, 9791, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25860, 9791, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25861, 9791, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25862, 9791, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25863, 9792, 4, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25864, 9792, 2, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25865, 9792, 3, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25866, 9792, 5, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25867, 9793, 4, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25868, 9793, 2, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25869, 9793, 3, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25870, 9793, 5, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25871, 9794, 4, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25872, 9794, 2, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25873, 9794, 3, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25874, 9794, 5, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25875, 9795, 4, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25876, 9795, 2, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25877, 9795, 3, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25878, 9795, 5, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25879, 9796, 4, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25880, 9796, 2, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25881, 9796, 3, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25882, 9796, 5, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25883, 9797, 4, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25884, 9797, 2, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25885, 9797, 3, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25886, 9797, 5, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25887, 9798, 4, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25888, 9798, 2, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25889, 9798, 3, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25890, 9798, 5, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25891, 9799, 4, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25892, 9799, 2, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25893, 9799, 3, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25894, 9799, 5, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25895, 9800, 4, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25896, 9800, 2, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25897, 9800, 3, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25898, 9800, 5, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25899, 9801, 4, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25900, 9801, 2, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25901, 9801, 3, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25902, 9801, 5, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25903, 9802, 4, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25904, 9802, 2, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25905, 9802, 3, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25906, 9802, 5, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25907, 9803, 4, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25908, 9803, 2, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25909, 9803, 3, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25910, 9803, 5, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25911, 9804, 4, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25912, 9804, 2, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25913, 9804, 3, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25914, 9804, 5, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25915, 9805, 4, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25916, 9805, 2, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25917, 9805, 3, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25918, 9805, 5, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25919, 9806, 4, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25920, 9806, 2, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25921, 9806, 3, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25922, 9806, 5, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25923, 9807, 4, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25924, 9807, 2, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25925, 9807, 3, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25926, 9807, 5, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25927, 9808, 4, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25928, 9808, 2, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25929, 9808, 3, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25930, 9808, 5, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25931, 9809, 4, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25932, 9809, 2, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25933, 9809, 3, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25934, 9809, 5, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25935, 9810, 4, 'Предыдущая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25936, 9810, 2, 'Предыдущая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25937, 9810, 3, 'Предыдущая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25938, 9810, 5, 'Предыдущая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25939, 9811, 4, 'Предыдущая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25940, 9811, 2, 'Предыдущая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25941, 9811, 3, 'Предыдущая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25942, 9811, 5, 'Предыдущая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25943, 9812, 4, 'Следующая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25944, 9812, 2, 'Следующая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25945, 9812, 3, 'Следующая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25946, 9812, 5, 'Следующая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25947, 9813, 4, 'Следующая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25948, 9813, 2, 'Следующая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25949, 9813, 3, 'Следующая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25950, 9813, 5, 'Следующая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25951, 9814, 4, 'Номер веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25952, 9814, 2, 'Номер веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25953, 9814, 3, 'Номер веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25954, 9814, 5, 'Номер веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25955, 9815, 4, 'Настройка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25956, 9815, 2, 'Настройка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25957, 9815, 3, 'Настройка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25958, 9815, 5, 'Настройка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25959, 9816, 4, 'Настройка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25960, 9816, 2, 'Настройка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25961, 9816, 3, 'Настройка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25962, 9816, 5, 'Настройка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25963, 9817, 4, 'tbrSetup');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25964, 9817, 2, 'tbrSetup');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25965, 9817, 3, 'tbrSetup');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25966, 9817, 5, 'tbrSetup');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25967, 9818, 4, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25968, 9818, 2, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25969, 9818, 3, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25970, 9818, 5, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25971, 9819, 4, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25972, 9819, 2, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25973, 9819, 3, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25974, 9819, 5, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25975, 9820, 4, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25976, 9820, 2, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25977, 9820, 3, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25978, 9820, 5, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25979, 9821, 4, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25980, 9821, 2, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25981, 9821, 3, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25982, 9821, 5, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25983, 9822, 4, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25984, 9822, 2, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25985, 9822, 3, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25986, 9822, 5, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25987, 9823, 4, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25988, 9823, 2, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25989, 9823, 3, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25990, 9823, 5, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25991, 9824, 4, 'Обычный');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25992, 9824, 2, 'Обычный');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25993, 9824, 3, 'Обычный');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25994, 9824, 5, 'Обычный');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25995, 9825, 4, 'Тип Enter');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25996, 9825, 2, 'Тип Enter');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25997, 9825, 3, 'Тип Enter');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25998, 9825, 5, 'Тип Enter');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25999, 9826, 4, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26000, 9826, 2, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26001, 9826, 3, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26002, 9826, 5, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26003, 9827, 4, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26004, 9827, 2, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26005, 9827, 3, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26006, 9827, 5, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26007, 9828, 4, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26008, 9828, 2, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26009, 9828, 3, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26010, 9828, 5, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26011, 9829, 4, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26012, 9829, 2, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26013, 9829, 3, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26014, 9829, 5, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26015, 9830, 4, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26016, 9830, 2, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26017, 9830, 3, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26018, 9830, 5, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26019, 9831, 4, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26020, 9831, 2, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26021, 9831, 3, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26022, 9831, 5, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26023, 9832, 4, 'tbrDB');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26024, 9832, 2, 'tbrDB');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26025, 9832, 3, 'tbrDB');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26026, 9832, 5, 'tbrDB');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26027, 9833, 4, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26028, 9833, 2, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26029, 9833, 3, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26030, 9833, 5, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26031, 9834, 4, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26032, 9834, 2, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26033, 9834, 3, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26034, 9834, 5, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26035, 9835, 4, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26036, 9835, 2, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26037, 9835, 3, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26038, 9835, 5, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26039, 9836, 4, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26040, 9836, 2, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26041, 9836, 3, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26042, 9836, 5, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26043, 9837, 4, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26044, 9837, 2, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26045, 9837, 3, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26046, 9837, 5, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26047, 9838, 4, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26048, 9838, 2, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26049, 9838, 3, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26050, 9838, 5, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26051, 9839, 4, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26052, 9839, 2, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26053, 9839, 3, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26054, 9839, 5, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26055, 9840, 4, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26056, 9840, 2, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26057, 9840, 3, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26058, 9840, 5, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26059, 9841, 4, 'tbrStatus');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26060, 9841, 2, 'tbrStatus');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26061, 9841, 3, 'tbrStatus');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26062, 9841, 5, 'tbrStatus');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26063, 9842, 4, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26064, 9842, 2, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26065, 9842, 3, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26066, 9842, 5, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26067, 9843, 4, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26068, 9843, 2, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26069, 9843, 3, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26070, 9843, 5, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26071, 9844, 4, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26072, 9844, 2, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26073, 9844, 3, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26074, 9844, 5, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26075, 9845, 4, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26076, 9845, 2, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26077, 9845, 3, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26078, 9845, 5, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26079, 9846, 4, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26080, 9846, 2, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26081, 9846, 3, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26082, 9846, 5, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26083, 9847, 4, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26084, 9847, 2, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26085, 9847, 3, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26086, 9847, 5, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26087, 9848, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26088, 9848, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26089, 9848, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26091, 9849, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26092, 9849, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26093, 9849, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26094, 9849, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26095, 9850, 4, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26096, 9850, 2, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26097, 9850, 3, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26098, 9850, 5, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26099, 9851, 4, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26100, 9851, 2, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26101, 9851, 3, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26102, 9851, 5, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26103, 9852, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26104, 9852, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26105, 9852, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26106, 9852, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26107, 9853, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26108, 9853, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26109, 9853, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26110, 9853, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26111, 9854, 4, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26112, 9854, 2, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26113, 9854, 3, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26114, 9854, 5, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26115, 9855, 4, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26116, 9855, 2, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26117, 9855, 3, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26118, 9855, 5, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26119, 9856, 4, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26120, 9856, 2, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26121, 9856, 3, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26122, 9856, 5, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26123, 9857, 4, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26124, 9857, 2, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26125, 9857, 3, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26126, 9857, 5, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26127, 9858, 4, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26128, 9858, 2, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26129, 9858, 3, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26130, 9858, 5, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26131, 9859, 4, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26132, 9859, 2, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26133, 9859, 3, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26134, 9859, 5, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26135, 9860, 4, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26136, 9860, 2, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26137, 9860, 3, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26138, 9860, 5, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26139, 9861, 4, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26140, 9861, 2, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26141, 9861, 3, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26142, 9861, 5, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26143, 9862, 4, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26144, 9862, 2, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26145, 9862, 3, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26146, 9862, 5, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26147, 9863, 4, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26148, 9863, 2, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26149, 9863, 3, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26150, 9863, 5, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26151, 9864, 4, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26152, 9864, 2, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26153, 9864, 3, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26154, 9864, 5, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26155, 9865, 4, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26156, 9865, 2, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26157, 9865, 3, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26158, 9865, 5, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26159, 9866, 4, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26160, 9866, 2, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26161, 9866, 3, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26162, 9866, 5, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26163, 9867, 4, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26164, 9867, 2, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26165, 9867, 3, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26166, 9867, 5, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26167, 9868, 4, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26168, 9868, 2, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26169, 9868, 3, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26170, 9868, 5, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26171, 9869, 4, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26172, 9869, 2, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26173, 9869, 3, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26174, 9869, 5, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26175, 9870, 4, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26176, 9870, 2, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26177, 9870, 3, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26178, 9870, 5, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26179, 9871, 4, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26180, 9871, 2, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26181, 9871, 3, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26182, 9871, 5, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26183, 9872, 4, 'Печать ветки дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26184, 9872, 2, 'Печать ветки дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26185, 9872, 3, 'Печать ветки дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26186, 9872, 5, 'Печать ветки дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26187, 9873, 4, 'Печать ветки дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26188, 9873, 2, 'Печать ветки дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26189, 9873, 3, 'Печать ветки дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26190, 9873, 5, 'Печать ветки дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26191, 9874, 4, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26192, 9874, 2, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26193, 9874, 3, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26194, 9874, 5, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26195, 9875, 4, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26196, 9875, 2, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26197, 9875, 3, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26198, 9875, 5, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26199, 9876, 4, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26200, 9876, 2, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26201, 9876, 3, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26202, 9876, 5, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26203, 9877, 4, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26204, 9877, 2, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26205, 9877, 3, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26206, 9877, 5, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26207, 9878, 4, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26208, 9878, 2, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26209, 9878, 3, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26210, 9878, 5, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26211, 9879, 4, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26212, 9879, 2, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26213, 9879, 3, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26214, 9879, 5, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26215, 9880, 4, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26216, 9880, 2, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26217, 9880, 3, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26218, 9880, 5, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26219, 9881, 4, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26220, 9881, 2, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26221, 9881, 3, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26222, 9881, 5, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26223, 9882, 4, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26224, 9882, 2, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26225, 9882, 3, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26226, 9882, 5, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26227, 9883, 4, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26228, 9883, 2, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26229, 9883, 3, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26230, 9883, 5, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26231, 9884, 4, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26232, 9884, 2, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26233, 9884, 3, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26234, 9884, 5, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26235, 9885, 4, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26236, 9885, 2, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26237, 9885, 3, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26238, 9885, 5, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26239, 9886, 4, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26240, 9886, 2, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26241, 9886, 3, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26242, 9886, 5, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26243, 9887, 4, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26244, 9887, 2, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26245, 9887, 3, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26246, 9887, 5, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26247, 9888, 4, 'Предыдущая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26248, 9888, 2, 'Предыдущая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26249, 9888, 3, 'Предыдущая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26250, 9888, 5, 'Предыдущая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26251, 9889, 4, 'Предыдущая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26252, 9889, 2, 'Предыдущая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26253, 9889, 3, 'Предыдущая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26254, 9889, 5, 'Предыдущая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26255, 9890, 4, 'Следующая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26256, 9890, 2, 'Следующая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26257, 9890, 3, 'Следующая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26258, 9890, 5, 'Следующая веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26259, 9891, 4, 'Следующая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26260, 9891, 2, 'Следующая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26261, 9891, 3, 'Следующая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26262, 9891, 5, 'Следующая
веточка');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26263, 9892, 4, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26264, 9892, 2, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26265, 9892, 3, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26266, 9892, 5, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26267, 9893, 4, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26268, 9893, 2, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26269, 9893, 3, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26270, 9893, 5, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26271, 9894, 4, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26272, 9894, 2, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26273, 9894, 3, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26274, 9894, 5, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26275, 9895, 4, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26276, 9895, 2, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26277, 9895, 3, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26278, 9895, 5, 'Очистить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26279, 9896, 4, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26280, 9896, 2, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26281, 9896, 3, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26282, 9896, 5, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26283, 9897, 4, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26284, 9897, 2, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26285, 9897, 3, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26286, 9897, 5, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26287, 9898, 4, 'База данных');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26288, 9898, 2, 'База данных');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26289, 9898, 3, 'База данных');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26290, 9898, 5, 'База данных');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26291, 9899, 4, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26292, 9899, 2, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26293, 9899, 3, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26294, 9899, 5, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26295, 9900, 4, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26296, 9900, 2, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26297, 9900, 3, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26298, 9900, 5, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26299, 9901, 4, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26300, 9901, 2, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26301, 9901, 3, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26302, 9901, 5, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26303, 9902, 4, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26304, 9902, 2, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26305, 9902, 3, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26306, 9902, 5, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26307, 9903, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26308, 9903, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26309, 9903, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26310, 9903, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26311, 9904, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26312, 9904, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26313, 9904, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26314, 9904, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26315, 9905, 4, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26316, 9905, 2, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26317, 9905, 3, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26318, 9905, 5, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26319, 9906, 4, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26320, 9906, 2, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26321, 9906, 3, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26322, 9906, 5, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26323, 9907, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26324, 9907, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26325, 9907, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26326, 9907, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26327, 9908, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26328, 9908, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26329, 9908, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26330, 9908, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26331, 9909, 4, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26332, 9909, 2, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26333, 9909, 3, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26334, 9909, 5, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26335, 9910, 4, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26336, 9910, 2, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26337, 9910, 3, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26338, 9910, 5, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26339, 9911, 4, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26340, 9911, 2, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26341, 9911, 3, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26342, 9911, 5, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26343, 9912, 4, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26344, 9912, 2, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26345, 9912, 3, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26346, 9912, 5, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26347, 9913, 4, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26348, 9913, 2, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26349, 9913, 3, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26350, 9913, 5, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26351, 9914, 4, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26352, 9914, 2, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26353, 9914, 3, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26354, 9914, 5, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26355, 9915, 4, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26356, 9915, 2, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26357, 9915, 3, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26358, 9915, 5, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26359, 9916, 4, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26360, 9916, 2, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26361, 9916, 3, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26362, 9916, 5, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26363, 9917, 4, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26364, 9917, 2, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26365, 9917, 3, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26366, 9917, 5, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26367, 9918, 4, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26368, 9918, 2, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26369, 9918, 3, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26370, 9918, 5, 'Обновить ветку дерева');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26371, 9919, 4, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26372, 9919, 2, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26373, 9919, 3, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26374, 9919, 5, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26375, 9920, 4, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26376, 9920, 2, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26377, 9920, 3, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26378, 9920, 5, 'Обновить всё дерево');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26379, 9921, 4, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26380, 9921, 2, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26381, 9921, 3, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26382, 9921, 5, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26383, 9922, 4, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26384, 9922, 2, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26385, 9922, 3, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26386, 9922, 5, 'Инвертировать актуальность веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26387, 9923, 4, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26388, 9923, 2, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26389, 9923, 3, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26390, 9923, 5, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26391, 9924, 4, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26392, 9924, 2, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26393, 9924, 3, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26394, 9924, 5, 'Только актуальные веточки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26395, 9925, 4, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26396, 9925, 2, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26397, 9925, 3, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26398, 9925, 5, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26399, 9926, 4, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26400, 9926, 2, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26401, 9926, 3, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26402, 9926, 5, 'Сквозной просмотр');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26403, 9927, 4, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26404, 9927, 2, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26405, 9927, 3, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26406, 9927, 5, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26407, 9928, 4, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26408, 9928, 2, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26409, 9928, 3, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26410, 9928, 5, 'Найти');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26411, 9929, 4, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26412, 9929, 2, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26413, 9929, 3, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26414, 9929, 5, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26415, 9930, 4, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26416, 9930, 2, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26417, 9930, 3, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26418, 9930, 5, 'Найти далее');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26419, 9931, 4, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26420, 9931, 2, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26421, 9931, 3, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26422, 9931, 5, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26423, 9932, 4, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26424, 9932, 2, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26425, 9932, 3, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26426, 9932, 5, 'Прервать поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26427, 9933, 4, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26428, 9933, 2, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26429, 9933, 3, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26430, 9933, 5, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26431, 9934, 4, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26432, 9934, 2, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26433, 9934, 3, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26434, 9934, 5, 'Быстрый поиск');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26435, 9935, 4, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26436, 9935, 2, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26437, 9935, 3, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26438, 9935, 5, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26439, 9936, 4, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26440, 9936, 2, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26441, 9936, 3, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26442, 9936, 5, 'Удалить фильтр поиска');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26443, 9937, 4, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26444, 9937, 2, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26445, 9937, 3, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26446, 9937, 5, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26447, 9938, 4, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26448, 9938, 2, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26449, 9938, 3, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26450, 9938, 5, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26451, 9939, 4, 'Свойства');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26452, 9939, 2, 'Свойства');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26453, 9939, 3, 'Свойства');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26454, 9939, 5, 'Свойства');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26455, 9940, 4, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26456, 9940, 2, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26457, 9940, 3, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26458, 9940, 5, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26459, 9941, 4, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26460, 9941, 2, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26461, 9941, 3, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26462, 9941, 5, 'Горячие клавиши');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26463, 9942, 4, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26464, 9942, 2, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26465, 9942, 3, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26466, 9942, 5, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26467, 9943, 4, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26468, 9943, 2, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26469, 9943, 3, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26470, 9943, 5, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26471, 9944, 4, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26472, 9944, 2, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26473, 9944, 3, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26474, 9944, 5, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26475, 9945, 4, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26476, 9945, 2, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26477, 9945, 3, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26478, 9945, 5, 'Слить главное меню');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26479, 9946, 4, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26480, 9946, 2, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26481, 9946, 3, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26482, 9946, 5, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26483, 9947, 4, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26484, 9947, 2, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26485, 9947, 3, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26486, 9947, 5, 'Аварийное закрытие окна');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26487, 9948, 4, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26488, 9948, 2, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26489, 9948, 3, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26490, 9948, 5, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26491, 9949, 4, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26492, 9949, 2, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26493, 9949, 3, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26494, 9949, 5, 'Пустой выбор');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26495, 9950, 4, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26496, 9950, 2, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26497, 9950, 3, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26498, 9950, 5, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26499, 9951, 4, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26500, 9951, 2, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26501, 9951, 3, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26502, 9951, 5, 'Подготовить язык');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26503, 9952, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26504, 9952, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26505, 9952, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26506, 9952, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26507, 9953, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26508, 9953, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26509, 9953, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26510, 9953, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26511, 9954, 4, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26512, 9954, 2, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26513, 9954, 3, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26514, 9954, 5, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26515, 9955, 4, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26516, 9955, 2, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26517, 9955, 3, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26518, 9955, 5, 'Копировать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26519, 9956, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26520, 9956, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26521, 9956, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26522, 9956, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26523, 9957, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26524, 9957, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26525, 9957, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26526, 9957, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26527, 9958, 4, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26528, 9958, 2, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26529, 9958, 3, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26530, 9958, 5, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26531, 9959, 4, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26532, 9959, 2, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26533, 9959, 3, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26534, 9959, 5, 'Слить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26535, 9960, 4, '-');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26536, 9960, 2, '-');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26537, 9960, 3, '-');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26538, 9960, 5, '-');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26539, 9961, 4, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26540, 9961, 2, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26541, 9961, 3, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26542, 9961, 5, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26543, 9962, 4, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26544, 9962, 2, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26545, 9962, 3, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26546, 9962, 5, 'Авто-редактирование таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26547, 9963, 4, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26548, 9963, 2, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26549, 9963, 3, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26550, 9963, 5, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26551, 9964, 4, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26552, 9964, 2, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26553, 9964, 3, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26554, 9964, 5, 'Кэшировать данные');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26555, 9965, 4, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26556, 9965, 2, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26557, 9965, 3, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26558, 9965, 5, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26559, 9966, 4, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26560, 9966, 2, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26561, 9966, 3, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26562, 9966, 5, 'Запомнить строку');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26563, 9967, 4, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26564, 9967, 2, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26565, 9967, 3, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26566, 9967, 5, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26567, 9968, 4, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26568, 9968, 2, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26569, 9968, 3, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26570, 9968, 5, 'Установить поля строк');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26571, 9969, 4, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26572, 9969, 2, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26573, 9969, 3, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26574, 9969, 5, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26575, 9970, 4, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26576, 9970, 2, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26577, 9970, 3, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26578, 9970, 5, 'Выделить все');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26579, 9971, 4, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26580, 9971, 2, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26581, 9971, 3, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26582, 9971, 5, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26583, 9972, 4, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26584, 9972, 2, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26585, 9972, 3, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26586, 9972, 5, 'Свойства таблицы');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26587, 9973, 4, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26588, 9973, 2, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26589, 9973, 3, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26590, 9973, 5, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26591, 9974, 4, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26592, 9974, 2, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26593, 9974, 3, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26594, 9974, 5, 'Инспектор строки');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26595, 9975, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26596, 9975, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26597, 9975, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26598, 9975, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26599, 9976, 4, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26600, 9976, 2, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26601, 9976, 3, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26602, 9976, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26603, 9977, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26604, 9977, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26605, 9977, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26606, 9977, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26607, 9978, 4, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26608, 9978, 2, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26609, 9978, 3, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26610, 9978, 5, 'Вставить');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26611, 9979, 4, 'Введите число и нажмите Enter!');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26612, 9979, 2, 'Введите число и нажмите Enter!');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26613, 9979, 3, 'Введите число и нажмите Enter!');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26614, 9979, 5, 'Введите число и нажмите Enter!');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26615, 9980, 4, '1234567890');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26616, 9980, 2, '1234567890');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26617, 9980, 3, '1234567890');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26618, 9980, 5, '1234567890');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26619, 9981, 4, 'Товар ИД');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26620, 9981, 2, 'Товар ИД');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26621, 9981, 3, 'Товар ИД');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26622, 9981, 5, 'Товар ИД');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26623, 9982, 4, 'Вид товара ИД');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26624, 9982, 2, 'Вид товара ИД');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26625, 9982, 3, 'Вид товара ИД');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26626, 9982, 5, 'Вид товара ИД');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26627, 9983, 4, 'Товар');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26628, 9983, 2, 'Товар');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26629, 9983, 3, 'Товар');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26630, 9983, 5, 'Товар');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26631, 9984, 4, 'Цена');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26632, 9984, 2, 'Цена');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26633, 9984, 3, 'Цена');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26634, 9984, 5, 'Цена');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26635, 9985, 4, 'EntityID');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26636, 9985, 2, 'EntityID');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26637, 9985, 3, 'EntityID');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26638, 9985, 5, 'EntityID');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26639, 9986, 4, 'KindID');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26640, 9986, 2, 'KindID');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26641, 9986, 3, 'KindID');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26642, 9986, 5, 'KindID');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26643, 9987, 4, 'Entity');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26644, 9987, 2, 'Entity');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26645, 9987, 3, 'Entity');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26646, 9987, 5, 'Entity');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26647, 9988, 4, 'Price');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26648, 9988, 2, 'Price');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26649, 9988, 3, 'Price');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26650, 9988, 5, 'Price');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26651, 9989, 4, 'tbColor');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26652, 9989, 2, 'tbColor');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26653, 9989, 3, 'tbColor');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26654, 9989, 5, 'tbColor');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26655, 9990, 4, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26656, 9990, 2, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26657, 9990, 3, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26658, 9990, 5, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26659, 9991, 4, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26660, 9991, 2, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26661, 9991, 3, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26662, 9991, 5, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26663, 9992, 4, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26995, 9848, 5, 'Вырезать');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26664, 9992, 2, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26665, 9992, 3, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26666, 9992, 5, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26667, 9993, 4, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26668, 9993, 2, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26669, 9993, 3, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26670, 9993, 5, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26671, 9994, 4, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26672, 9994, 2, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26673, 9994, 3, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26674, 9994, 5, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26675, 9995, 4, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26676, 9995, 2, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26677, 9995, 3, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26678, 9995, 5, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26679, 9996, 4, 'Пример');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26680, 9996, 2, 'Пример');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26681, 9996, 3, 'Пример');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26682, 9996, 5, 'Пример');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26683, 9997, 4, 'Цвет фона элементов ввода диапазонов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26684, 9997, 2, 'Цвет фона элементов ввода диапазонов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26685, 9997, 3, 'Цвет фона элементов ввода диапазонов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26686, 9997, 5, 'Цвет фона элементов ввода диапазонов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26687, 9998, 4, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26688, 9998, 2, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26689, 9998, 3, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26690, 9998, 5, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26691, 9999, 4, 'tbrRights');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26692, 9999, 2, 'tbrRights');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26693, 9999, 3, 'tbrRights');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26694, 9999, 5, 'tbrRights');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26695, 10000, 4, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26696, 10000, 2, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26697, 10000, 3, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26698, 10000, 5, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26699, 10001, 4, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26700, 10001, 2, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26701, 10001, 3, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26702, 10001, 5, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26703, 10002, 4, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26704, 10002, 2, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26705, 10002, 3, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26706, 10002, 5, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26707, 10003, 4, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26708, 10003, 2, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26709, 10003, 3, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26710, 10003, 5, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26711, 10004, 4, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26712, 10004, 2, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26713, 10004, 3, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26714, 10004, 5, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26715, 10005, 4, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26716, 10005, 2, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26717, 10005, 3, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26718, 10005, 5, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26719, 10006, 4, 'tbrUsers');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26720, 10006, 2, 'tbrUsers');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26721, 10006, 3, 'tbrUsers');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26722, 10006, 5, 'tbrUsers');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26723, 10007, 4, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26724, 10007, 2, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26725, 10007, 3, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26726, 10007, 5, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26727, 10008, 4, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26728, 10008, 2, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26729, 10008, 3, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26730, 10008, 5, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26731, 10009, 4, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26732, 10009, 2, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (25736, 9760, 2, 'Explorer "Jaya Shrila Prabhupada"');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26733, 10009, 3, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26734, 10009, 5, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26735, 10010, 4, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26736, 10010, 2, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26737, 10010, 3, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26738, 10010, 5, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26739, 10011, 4, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26740, 10011, 2, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26741, 10011, 3, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26742, 10011, 5, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26743, 10012, 4, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26744, 10012, 2, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26745, 10012, 3, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26746, 10012, 5, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26747, 10013, 4, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26748, 10013, 2, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26749, 10013, 3, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26750, 10013, 5, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26751, 10014, 4, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26752, 10014, 2, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26753, 10014, 3, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26754, 10014, 5, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26755, 10015, 4, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26756, 10015, 2, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26757, 10015, 3, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26758, 10015, 5, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26759, 10016, 4, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26760, 10016, 2, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26761, 10016, 3, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26762, 10016, 5, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26763, 10017, 4, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26764, 10017, 2, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26765, 10017, 3, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26766, 10017, 5, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26767, 10018, 4, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26768, 10018, 2, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26769, 10018, 3, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26770, 10018, 5, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26771, 10019, 4, 'Anketa.PassportDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26772, 10019, 2, 'Anketa.PassportDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26773, 10019, 3, 'Anketa.PassportDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26774, 10019, 5, 'Anketa.PassportDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26775, 10020, 4, 'dd.mm.yyyy');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26776, 10020, 2, 'dd.mm.yyyy');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26777, 10020, 3, 'dd.mm.yyyy');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26778, 10020, 5, 'dd.mm.yyyy');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26779, 10021, 4, '!99/99/9999;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26780, 10021, 2, '!99/99/9999;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26781, 10021, 3, '!99/99/9999;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26782, 10021, 5, '!99/99/9999;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26783, 10022, 4, '02.10.2022');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26784, 10022, 2, '02.10.2022');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26785, 10022, 3, '02.10.2022');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26786, 10022, 5, '02.10.2022');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26787, 10023, 4, '02.10.2022');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26788, 10023, 2, '02.10.2022');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26789, 10023, 3, '02.10.2022');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26790, 10023, 5, '02.10.2022');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26791, 10024, 4, 'Note');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26792, 10024, 2, 'Note');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26793, 10024, 3, 'Note');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26794, 10024, 5, 'Note');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26795, 10025, 4, 'BirthDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26796, 10025, 2, 'BirthDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26797, 10025, 3, 'BirthDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26798, 10025, 5, 'BirthDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26799, 10026, 4, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26800, 10026, 2, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26801, 10026, 3, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26802, 10026, 5, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26803, 10027, 4, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26804, 10027, 2, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26805, 10027, 3, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26806, 10027, 5, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26807, 10028, 4, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26808, 10028, 2, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26809, 10028, 3, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26810, 10028, 5, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26811, 10029, 4, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26812, 10029, 2, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26813, 10029, 3, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26814, 10029, 5, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26815, 10030, 4, 'CreateDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26816, 10030, 2, 'CreateDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26817, 10030, 3, 'CreateDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26818, 10030, 5, 'CreateDate');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26819, 10031, 4, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26820, 10031, 2, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26821, 10031, 3, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26822, 10031, 5, 'dd.mm.yyyy hh:nn:ss');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26823, 10032, 4, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26824, 10032, 2, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26825, 10032, 3, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26826, 10032, 5, '!99/99/9999 99:99:99;1;_');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26827, 10033, 4, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26828, 10033, 2, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26829, 10033, 3, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26830, 10033, 5, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26831, 10034, 4, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26832, 10034, 2, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26833, 10034, 3, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26834, 10034, 5, '02.10.2022 11:50:33');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26835, 10035, 4, 'tbrRole');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26836, 10035, 2, 'tbrRole');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26837, 10035, 3, 'tbrRole');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26838, 10035, 5, 'tbrRole');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26839, 10036, 4, 'tbrGolovolomka15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26840, 10036, 2, 'tbrGolovolomka15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26841, 10036, 3, 'tbrGolovolomka15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26842, 10036, 5, 'tbrGolovolomka15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26843, 10037, 4, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26844, 10037, 2, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26845, 10037, 3, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26846, 10037, 5, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26847, 10038, 4, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26848, 10038, 2, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26849, 10038, 3, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26850, 10038, 5, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26851, 10039, 4, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26852, 10039, 2, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26853, 10039, 3, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26854, 10039, 5, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26855, 10040, 4, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26856, 10040, 2, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26857, 10040, 3, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26858, 10040, 5, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26859, 10041, 4, '?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26860, 10041, 2, '?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26861, 10041, 3, '?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26862, 10041, 5, '?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26863, 10042, 4, '25');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26864, 10042, 2, '25');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26865, 10042, 3, '25');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26866, 10042, 5, '25');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26867, 10043, 4, 'Сколько ходов перемешивать?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26868, 10043, 2, 'Сколько ходов перемешивать?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26869, 10043, 3, 'Сколько ходов перемешивать?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26870, 10043, 5, 'Сколько ходов перемешивать?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26871, 10044, 4, '?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26872, 10044, 2, '?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26873, 10044, 3, '?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26874, 10044, 5, '?');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26875, 10045, 4, '300');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26876, 10045, 2, '300');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26877, 10045, 3, '300');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26878, 10045, 5, '300');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26879, 10046, 4, 'Пауза при перемешивании в миллисекундах');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26880, 10046, 2, 'Пауза при перемешивании в миллисекундах');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26881, 10046, 3, 'Пауза при перемешивании в миллисекундах');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26882, 10046, 5, 'Пауза при перемешивании в миллисекундах');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26883, 10047, 4, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26884, 10047, 2, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26885, 10047, 3, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26886, 10047, 5, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26887, 10048, 4, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26888, 10048, 2, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26889, 10048, 3, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26890, 10048, 5, 'Генерация индексов прав');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26891, 10049, 4, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26892, 10049, 2, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26893, 10049, 3, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26894, 10049, 5, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26895, 10050, 4, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26896, 10050, 2, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26897, 10050, 3, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26898, 10050, 5, 'Создать пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26899, 10051, 4, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26900, 10051, 2, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26901, 10051, 3, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26902, 10051, 5, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26903, 10052, 4, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26904, 10052, 2, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26905, 10052, 3, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26906, 10052, 5, 'Задать пароль пользователю');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26907, 10053, 4, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26908, 10053, 2, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26909, 10053, 3, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26910, 10053, 5, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26911, 10054, 4, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26912, 10054, 2, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26913, 10054, 3, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26914, 10054, 5, 'Удалить пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26915, 10055, 4, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26916, 10055, 2, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26917, 10055, 3, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26918, 10055, 5, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26919, 10056, 4, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26920, 10056, 2, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26921, 10056, 3, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26922, 10056, 5, 'Генерация индексов цветов');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26923, 10057, 4, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26924, 10057, 2, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26925, 10057, 3, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26926, 10057, 5, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26927, 10058, 4, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26928, 10058, 2, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26929, 10058, 3, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26930, 10058, 5, 'Создание списка констант цветов для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26931, 10059, 4, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26932, 10059, 2, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26933, 10059, 3, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26934, 10059, 5, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26935, 10060, 4, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26936, 10060, 2, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26937, 10060, 3, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26938, 10060, 5, 'Создание списка констант цветов для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26939, 10061, 4, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26940, 10061, 2, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26941, 10061, 3, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26942, 10061, 5, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26943, 10062, 4, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26944, 10062, 2, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26945, 10062, 3, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26946, 10062, 5, 'Создать супер пользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26947, 10063, 4, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26948, 10063, 2, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26949, 10063, 3, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26950, 10063, 5, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26951, 10064, 4, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26952, 10064, 2, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26953, 10064, 3, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26954, 10064, 5, 'Дать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26955, 10065, 4, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26956, 10065, 2, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26957, 10065, 3, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26958, 10065, 5, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26959, 10066, 4, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26960, 10066, 2, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26961, 10066, 3, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26962, 10066, 5, 'Забрать права суперпользователя');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26963, 10067, 4, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26964, 10067, 2, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26965, 10067, 3, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26966, 10067, 5, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26967, 10068, 4, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26968, 10068, 2, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26969, 10068, 3, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26970, 10068, 5, 'Создание списка констант прав для *.cpp');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26971, 10069, 4, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26972, 10069, 2, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26973, 10069, 3, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26974, 10069, 5, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26975, 10070, 4, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26976, 10070, 2, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26977, 10070, 3, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26978, 10070, 5, 'Создание списка констант прав для *.h');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26979, 10071, 4, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26980, 10071, 2, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26981, 10071, 3, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26982, 10071, 5, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26983, 10072, 4, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26984, 10072, 2, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26985, 10072, 3, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26986, 10072, 5, 'Стартовая позиция');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26987, 10073, 4, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26988, 10073, 2, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26989, 10073, 3, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26990, 10073, 5, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26991, 10074, 4, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26992, 10074, 2, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26993, 10074, 3, 'Головоломка 15');
INSERT INTO public."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (26994, 10074, 5, 'Головоломка 15');


--
-- Data for Name: UserReg; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvLanguage.fmvLanguage.ini', '\x002c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff45000000ba000000f6040000d5030000060000005461686f6d61080000ff080000000100000000ff0000000000002000000047405860436056604d60000000005980558000000000000041c041e0000054400000464072004540466051407a607b60000041600000000000007a40000000000000000001000000001e00000001000074000000000000002026000000000000000100000000000101010000000000060000005461686f6d61080000ff08000000010000000000000000060000005461686f6d61080000ff080000000100000000050000ff01010101000500000008000000456e746974794944ffffffff00000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff010000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000600000041637475616c4c00000002000000010000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000006000000456e746974790d0100000300000001000000003d000000d0a1d182d180d0bed0bad0bed0b2d0bed0b520d0b8d0bcd18f20d0b8d0b7d0bdd0b0d187d0b0d0bbd18cd0bdd0bed0b3d0be20d181d0bbd0bed0b2d0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000080000004f726967696e616c3402000004000000010000000021000000d098d0b7d0bdd0b0d187d0b0d0bbd18cd0bdd0bed0b520d181d0bbd0bed0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010100050000000b0000005472616e736c6174654944ffffffff0000000000000000000b0000005472616e736c6174654944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000a0000004c616e67756167654944ffffffff0100000000000000000a0000004c616e67756167654944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000b0000004c616e6775616765734944ffffffff0200000000000000000b0000004c616e6775616765734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000090000004c616e67756167657380000000030000000100000000090000004c616e677561676573050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000090000005472616e736c617465cb010000040000000100000000090000005472616e736c617465050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000d800000005010000650000007801000000');
INSERT INTO public."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvExplorer.fmvExplorer.ini', '\x032c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff0d00000083000000be040000c4030000060000005461686f6d61080000ff080000000100000000ff0000000000002c000000000047405860436056604d60000000005980558000000000000000000000000041c041e0000054400000464072004540466051407a607b60000041600000000000007a4000000000000000000000000000000000000000000000000001000000001e00000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000101010000000000060000005461686f6d61080000ff08000000010000000000000000060000005461686f6d61080000ff080000000100000000050000ff01010101010b00000009000000497344656c657465643e00000000000000010000000012000000d0a3d0b4d0b0d0bbd191d0bd20d0bbd0b83f050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff080000000100000000060000005573657249445e00000001000000010000000006000000557365724944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000040000004e616d65c400000002000000010000000011000000d09bd0bed0b3d0b8d0bd20d0b8d0bcd18f050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000040000004e6f74658f00000003000000010000000016000000d09ad0bed0bcd0bcd0b5d0bdd182d0b0d180d0b8d0b9050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000a000000416e6b6574612e46494f5c02000004000000010000000026000000d0a4d0b0d0bcd0b8d0bbd0b8d18f20d098d0bcd18f20d09ed182d187d0b5d181d182d0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000a000000416e6b6574612e494e4e640000000500000001000000003a000000d098d0bdd0b4d0b8d0b2d0b8d0b4d183d0b0d0bbd18cd0bdd18bd0b920d0bdd0b0d0bbd0bed0b3d0bed0b2d18bd0b920d0bdd0bed0bcd0b5d180050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000f000000416e6b6574612e50617373706f72744c0000000600000001000000000e000000d09fd0b0d181d0bfd0bed180d182050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000017000000416e6b6574612e50617373706f72744b656d567964616e6400000007000000010000000020000000d09ad0b5d0bc20d0b2d18bd0b4d0b0d0bd20d0bfd0b0d181d0bfd0bed180d182050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000013000000416e6b6574612e50617373706f7274446174657a00000008000000010000000026000000d094d0b0d182d0b020d0b2d18bd0b4d0b0d187d0b820d0bfd0b0d181d0bfd0bed180d182d0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000090000004269727468446174656400000009000000010000000009000000426972746844617465050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000a00000043726561746544617465640000000a00000001000000000a00000043726561746544617465050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101050000000600000041637475616c1e00000000000000010000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff01000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff020000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000456e74697479d60000000300000001000000000a000000d0a2d0bed0b2d0b0d180050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000500000050726963654000000004000000010000000008000000d0a6d0b5d0bdd0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff01010101010a0000000600000041637475616cffffffff00000000000000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff01000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff020000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000456e746974794e01000003000000010000000008000000d0a6d0b2d0b5d182050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000b000000456e756d4c69746572616c5a0000000400000001000000000e000000d09bd0b8d182d0b5d180d0b0d0bb050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000b000000566563746f72496e6465783c0000000500000001000000000c000000d098d0bdd0b4d0b5d0bad181050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000008000000466f6e436f6c6f724000000006000000010000000011000000d0a6d0b2d0b5d18220d184d0bed0bdd0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000009000000466f6e74436f6c6f724900000007000000010000000015000000d0a6d0b2d0b5d18220d188d180d0b8d184d182d0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000c000000466f6e436f6c6f7255736572850000000800000001000000002a000000d0a6d0b2d0b5d18220d184d0bed0bdd0b020d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000d000000466f6e74436f6c6f7255736572930000000900000001000000002e000000d0a6d0b2d0b5d18220d188d180d0b8d184d182d0b020d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff01010101010600000008000000456e746974794944ffffffff00000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff010000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000600000041637475616cffffffff02000000000000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000006000000456e746974792f0100000300000001000000000a000000d09fd180d0b0d0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000070000004c69746572616c570000000400000001000000000e000000d09bd0b8d182d0b5d180d0b0d0bb050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000b000000566563746f72496e6465785e0000000500000001000000000c000000d098d0bdd0b4d0b5d0bad181050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff01010101010400000008000000456e746974794944ffffffff00000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff010000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000600000041637475616c4c00000002000000010000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000006000000456e746974799001000003000000010000000008000000d0a0d0bed0bbd18c050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101040000000c000000526f6c655269676874734944ffffffff0000000000000000000c000000526f6c655269676874734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000526f6c654944ffffffff01000000000000000006000000526f6c654944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff02000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000005269676874bd0100000300000001000000000a000000d09fd180d0b0d0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101050000000c000000557365725269676874734944ffffffff0000000000000000000c000000557365725269676874734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000557365724944ffffffff01000000000000000006000000557365724944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff02000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004973506c75734200000003000000010000000013000000d09fd0bbd18ed1812dd09cd0b8d0bdd183d181050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000500000052696768747f0100000400000001000000000a000000d09fd180d0b0d0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101040000000b00000055736572526f6c65734944ffffffff0000000000000000000b00000055736572526f6c65734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000557365724944ffffffff01000000000000000006000000557365724944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff02000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000004000000526f6c65a801000003000000010000000008000000d0a0d0bed0bbd18c050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101030000000b0000004c616e6775616765734944ffffffff0000000000000000000b0000004c616e6775616765734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000110000004c616e677561676573537472696e674944720000000100000001000000001d000000d0a1d182d180d0bed0bad0bed0b2d0b0d18f20d0bcd0b5d182d0bad0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000090000004c616e677561676573fc00000002000000010000000008000000d0afd0b7d18bd0ba050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000bd0000000a00000031323334353637383930290100005b010000ff01000003');
INSERT INTO public."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvJayaShrilaPrabhupada.fmvJayaShrilaPrabhupada.ini', '\x012c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff0d0000000d000000b402000085000000060000005461686f6d61080000ff080000000100000000ff0000000000000e000000714000007b2000000000000000007a007a407b40786078404c40000000000000030000000000000001');
INSERT INTO public."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TdmvNewNavadvipa.dmvNewNavadvipa.ini', '\x0000000000000000007f00000000000000ffffd20000000000caff950000000000ffff240000000000bcffc500000000008ac9fd000000000048ff480000000000fcfeb800ff000000ffff00008000ff00a4ffd100ffff00000000ff0000000000c0ffc000ff000000ffffff00ff000000ffffff0000000000eeeeee000000ff00ffffff0000000000ffffff0000800000ffffff00ff000000ffff00000000ff00ffff00000000ff0000ff000000000000ffffff00000000001cffc500ff00000062ffff00000000001cffc50000000000ffecff0000000000eaea0000ffffff008080ff00ff00ff00ffff800000000000e6ffff00ff000000ffffff000000ff00ffffff00ff000000ffffff00ff000000b7fea500ff000000ffff0000ff0000001cffc50080404000bbffc100ff000000bbffc1000000ff0062ffff000000ff00ddffff00ff000000ddffff0000000000ffffff000000000080ffff00ff00ff00ffecd900ff000000cbfe010000000000d3f3fe00ff000000dfdfff008000ff0000ffff000000ff00ffffff00ff000000ffffff00ff00ff00ffffff0000000000ffffff00ffff0000ff0000008000000072a0f8000000000084ffff00ffffff00ff00000000000000d9d9ff000000ff00ffffff00ff000000ffffff0000800000ffffff00ff000000ffff00000000ff00d9ffff0000000000ffff00000000ff0000ffff00ff000000ffff000000800000ffff000000000000ffff0000ff000000ffff00000000ff00a3fca0000000000080ff80000000ff00bff5f900ffffff008000ff0000000000e9ffca00ff000000ffff000000800000ffffff00ffffff00ff008000ff000000ffff0000ff000000b7ffb700ff0000009fffff0000808000ffaa5500ffff0000ff0000000000b900ddbbff000000ff00ffeaff000000ff00ffd2ff000000ff00ffb7ff000000ff00ffa4ff00ffffff00ff000000ff000000ffc68c00ff000000ffff000000800000ffff00000000ff00ffff0000ffff0000008000000000ff00ffff0000ffff0000ff0000000000ff0055ff5500ffff0000ff0000000000ff00ffffff00ffff0000ff0000000000ff0059e1f900ff000000ffc68c0000800000ffe1c4000000df009fffff00ff000000ffc68c0000000000c0c0c000ff000000ffc68c00ff000000ffc68c00ff000000ffff0000ffff00000000ff00ff000000ffe8ff000000000093ffff0000000000ddffdd0000000000aeffae00ffff00000000ff000000000079ff79000000000000ff00000000000000d700000000ff0000ffff00ffff00000000ff00ff000000ffff0000ff000000ffc68c0000000000ffffff00ffff0000ff0000000080c00080ff800000800000ffff8000ff000000ffffff00008000009efe9e00ffff0000ff000000ffff0000ff000000ffff0000000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000');
INSERT INTO public."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvChangePassword.fmvChangePassword.ini', '\x002c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff1a0000001a00000096010000ce000000060000005461686f6d61080000ff080000000100000000ff0000000000000400000000000000000000000000000000');


--
-- Data for Name: UserRights; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (4, 1, 153, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (5, 4, 154, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (6, 4, 153, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (7, 9, 154, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (8, 9, 153, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (2, 3, 154, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (3, 3, 153, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (9, 5, 154, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (10, 7, 152, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (11, 7, 153, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (13, 5, 176, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (14, 5, 153, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (15, 5, 174, true);
INSERT INTO public."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (12, 7, 177, true);


--
-- Data for Name: UserRoles; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (3, 9, 155);
INSERT INTO public."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (1, 1, 162);
INSERT INTO public."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (2, 1, 156);
INSERT INTO public."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (4, 3, 162);
INSERT INTO public."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (5, 3, 156);
INSERT INTO public."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (6, 5, 156);
INSERT INTO public."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (15, 7, 187);


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: Navadvipa Chandra das
--

INSERT INTO public."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (7, 'Navadvipa Chandra das', 'Шримад Бхагаватам', false, NULL, '2022-04-11 21:14:10', NULL);
INSERT INTO public."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (4, 'Борис', 'Бхагавад Гита как она есть', true, NULL, '1833-12-30 22:22:22', NULL);
INSERT INTO public."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (1, 'Мыкыта', 'Шри Брихад Бхагаватамрита', true, NULL, NULL, NULL);
INSERT INTO public."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (3, 'Мыкола', 'Шри Ишопанишад', false, NULL, NULL, NULL);
INSERT INTO public."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (9, 'Petro', 'Харибол!', false, '2022-04-19 18:02:33', NULL, NULL);
INSERT INTO public."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (5, 'Петро', 'Харе Кришна!', false, '2019-07-24 21:28:02', NULL, NULL);


--
-- Name: Entity_EntityID_seq; Type: SEQUENCE SET; Schema: public; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('public."Entity_EntityID_seq"', 10074, true);


--
-- Name: Kind_KindID_seq; Type: SEQUENCE SET; Schema: public; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('public."Kind_KindID_seq"', 117, true);


--
-- Name: Languages_LanguagesID_seq; Type: SEQUENCE SET; Schema: public; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('public."Languages_LanguagesID_seq"', 5, true);


--
-- Name: RoleRights_RoleRightsID_seq; Type: SEQUENCE SET; Schema: public; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('public."RoleRights_RoleRightsID_seq"', 27, true);


--
-- Name: Translate_TranslateID_seq; Type: SEQUENCE SET; Schema: public; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('public."Translate_TranslateID_seq"', 26995, true);


--
-- Name: UserRights_UserRightsID_seq; Type: SEQUENCE SET; Schema: public; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('public."UserRights_UserRightsID_seq"', 15, true);


--
-- Name: UserRoles_UserRolesID_seq; Type: SEQUENCE SET; Schema: public; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('public."UserRoles_UserRolesID_seq"', 15, true);


--
-- Name: Users_UserID_seq; Type: SEQUENCE SET; Schema: public; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('public."Users_UserID_seq"', 10, true);


--
-- Name: ColorKind ColorKind_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."ColorKind"
    ADD CONSTRAINT "ColorKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Color Color_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Color"
    ADD CONSTRAINT "Color_pkey" PRIMARY KEY ("EntityID");


--
-- Name: CommodKind CommodKind_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."CommodKind"
    ADD CONSTRAINT "CommodKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Commod Commod_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Commod"
    ADD CONSTRAINT "Commod_pkey" PRIMARY KEY ("EntityID");


--
-- Name: Entity Entity_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Entity"
    ADD CONSTRAINT "Entity_pkey" PRIMARY KEY ("EntityID");


--
-- Name: Color EnumLiteralUN; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Color"
    ADD CONSTRAINT "EnumLiteralUN" UNIQUE ("EnumLiteral");


--
-- Name: Kind Kind_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Kind"
    ADD CONSTRAINT "Kind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Language LanguageKindID_Entity_UN; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Language"
    ADD CONSTRAINT "LanguageKindID_Entity_UN" UNIQUE ("KindID", "Entity");


--
-- Name: LanguageKind LanguageKind_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."LanguageKind"
    ADD CONSTRAINT "LanguageKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Language Language_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Language"
    ADD CONSTRAINT "Language_pkey" PRIMARY KEY ("EntityID");


--
-- Name: Translate LanguagesCK; Type: CHECK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE public."Translate"
    ADD CONSTRAINT "LanguagesCK" CHECK (("LanguagesID" > 1)) NOT VALID;


--
-- Name: Languages Languages_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Languages"
    ADD CONSTRAINT "Languages_pkey" PRIMARY KEY ("LanguagesID");


--
-- Name: Kind ParentKind; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Kind"
    ADD CONSTRAINT "ParentKind" UNIQUE ("ParentID", "Kind");


--
-- Name: RightsKind RightsKind_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RightsKind"
    ADD CONSTRAINT "RightsKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Rights Rights_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Rights"
    ADD CONSTRAINT "Rights_pkey" PRIMARY KEY ("EntityID");


--
-- Name: RoleKind RoleKind_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RoleKind"
    ADD CONSTRAINT "RoleKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: RoleRights RoleRights_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RoleRights"
    ADD CONSTRAINT "RoleRights_pkey" PRIMARY KEY ("RoleRightsID");


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY ("EntityID");


--
-- Name: Translate Translate_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Translate"
    ADD CONSTRAINT "Translate_pkey" PRIMARY KEY ("TranslateID");


--
-- Name: UserReg UserReg_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."UserReg"
    ADD CONSTRAINT "UserReg_pkey" PRIMARY KEY ("UserRegKey");


--
-- Name: UserRights UserRights_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."UserRights"
    ADD CONSTRAINT "UserRights_pkey" PRIMARY KEY ("UserRightsID");


--
-- Name: UserRoles UserRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "UserRoles_pkey" PRIMARY KEY ("UserRolesID");


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY ("UserID");


--
-- Name: ColorKind ColorKindParentFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."ColorKind"
    ADD CONSTRAINT "ColorKindParentFK" FOREIGN KEY ("ParentID") REFERENCES public."ColorKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Commod CommodKindFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Commod"
    ADD CONSTRAINT "CommodKindFK" FOREIGN KEY ("KindID") REFERENCES public."CommodKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: CommodKind CommodKindParentFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."CommodKind"
    ADD CONSTRAINT "CommodKindParentFK" FOREIGN KEY ("ParentID") REFERENCES public."CommodKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Entity KindFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Entity"
    ADD CONSTRAINT "KindFK" FOREIGN KEY ("KindID") REFERENCES public."Kind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Kind KindParent_fk; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Kind"
    ADD CONSTRAINT "KindParent_fk" FOREIGN KEY ("ParentID") REFERENCES public."Kind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Translate LanguageFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Translate"
    ADD CONSTRAINT "LanguageFK" FOREIGN KEY ("LanguageID") REFERENCES public."Language"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Language LanguageKindFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Language"
    ADD CONSTRAINT "LanguageKindFK" FOREIGN KEY ("KindID") REFERENCES public."LanguageKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: LanguageKind LanguageKindParentFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."LanguageKind"
    ADD CONSTRAINT "LanguageKindParentFK" FOREIGN KEY ("ParentID") REFERENCES public."LanguageKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Translate LanguagesFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Translate"
    ADD CONSTRAINT "LanguagesFK" FOREIGN KEY ("LanguagesID") REFERENCES public."Languages"("LanguagesID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Rights RightsKindFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Rights"
    ADD CONSTRAINT "RightsKindFK" FOREIGN KEY ("KindID") REFERENCES public."RightsKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: RightsKind RightsKindParentFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RightsKind"
    ADD CONSTRAINT "RightsKindParentFK" FOREIGN KEY ("ParentID") REFERENCES public."RightsKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Role RoleKindFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "RoleKindFK" FOREIGN KEY ("KindID") REFERENCES public."RoleKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: RoleKind RoleKindParentFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RoleKind"
    ADD CONSTRAINT "RoleKindParentFK" FOREIGN KEY ("ParentID") REFERENCES public."RoleKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: RoleRights RoleRightsRightsFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RoleRights"
    ADD CONSTRAINT "RoleRightsRightsFK" FOREIGN KEY ("EntityID") REFERENCES public."Rights"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: RoleRights RoleRightsRoleFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."RoleRights"
    ADD CONSTRAINT "RoleRightsRoleFK" FOREIGN KEY ("RoleID") REFERENCES public."Role"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: UserRights UserRightsRightsFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."UserRights"
    ADD CONSTRAINT "UserRightsRightsFK" FOREIGN KEY ("EntityID") REFERENCES public."Rights"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: UserRights UserRightsUsersFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."UserRights"
    ADD CONSTRAINT "UserRightsUsersFK" FOREIGN KEY ("UserID") REFERENCES public."Users"("UserID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: UserRoles UserRolesRoleFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "UserRolesRoleFK" FOREIGN KEY ("EntityID") REFERENCES public."Role"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: UserRoles UserRolesUsersFK; Type: FK CONSTRAINT; Schema: public; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "UserRolesUsersFK" FOREIGN KEY ("UserID") REFERENCES public."Users"("UserID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- PostgreSQL database dump complete
--

