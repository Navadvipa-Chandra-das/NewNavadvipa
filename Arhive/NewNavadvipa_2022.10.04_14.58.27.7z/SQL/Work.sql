-- PROCEDURE: public.InsertLanguageRow(bigint, character varying, character varying)

-- DROP PROCEDURE IF EXISTS public."InsertLanguageRow"(bigint, character varying, character varying);

CREATE OR REPLACE PROCEDURE public."InsertLanguageRow"(
	IN "AKindID" bigint,
	IN "ALanguage" character varying,
	IN "ATranslate" character varying)
LANGUAGE 'plpgsql'
AS $BODY$
declare
  pr record;
  "AEntityID" bigint;
  R bigint;

  rk cursor for
  select a."EntityID"
  from
    "Entity" a
  where
      a."KindID" = "AKindID"
  and a."Entity" = "ALanguage";

  dk ( "ALanguagesID" bigint ) cursor for
  select a."TranslateID"
  from
    "Translate" a
  where
      a."LanguageID" = "AEntityID"
  and a."LanguagesID" = "ALanguagesID";
begin
  open rk;
  fetch rk into "AEntityID";
  close rk;
  if ( not found ) then
    insert into "Language" (
      "KindID"
    , "Entity"
    , "Original"
    ) values (
      "AKindID"
    , "ALanguage"
    , "ATranslate"
    ) returning "EntityID" into "AEntityID";
  end if;

  for pr in ( select
                a."LanguagesID"
              from
                "Languages" a
              where
                  a."LanguagesID" > 1
              order by a."Languages" ) loop
    open dk( pr."LanguagesID" );
    fetch dk into R;
    close dk;
    if ( not found ) then
      insert into "Translate" (
        "LanguageID"
      , "LanguagesID"
      , "Translate"
      ) values (
        "AEntityID"
      , pr."LanguagesID"
      , "ATranslate"
      );
    end if;
  end loop;
end;
$BODY$;
ALTER PROCEDURE public."InsertLanguageRow"(bigint, character varying, character varying)
    OWNER TO "Navadvipa Chandra das";

