//---------------------------------------------------------------------------
#include <fmx.h>
#pragma hdrstop
#include "FMX_NNSearchOption.h"
#pragma package(smart_init)
TNNSearchComboParams::TNNSearchComboParams()
  : Tag( 0 )
, MaxLength( 0 )
{
}

TNNSearchComboParams::~TNNSearchComboParams()
{
}

void __fastcall TNNSearchComboParams::Clear()
{
  FieldTag = 0;
  Label = "";
}

namespace NNF {

TSearchOptions::TSearchOptions()
  : CaseSensitive( false )
  , AnyEntry(      true  )
  , NotThis(       false )
  , IsSoft(        false )
  , IsMistake(     false )
{
}

TSearchOptions::TSearchOptions( bool aCaseSensitive
                         , bool aAnyEntry
                         , bool aNotThis
                         , bool aIsSoft
                         , bool aIsMistake )
  : CaseSensitive( aCaseSensitive )
  , AnyEntry(      aAnyEntry )
  , NotThis(       aNotThis )
  , IsSoft(        aIsSoft )
  , IsMistake(     aIsMistake )
{
}

TSearchOptions::TSearchOptions( const TSearchOptions& a )
  : CaseSensitive( a.CaseSensitive )
  , AnyEntry(      a.AnyEntry )
  , NotThis(       a.NotThis )
  , IsSoft(        a.IsSoft )
  , IsMistake(     a.IsMistake )
{
}

void __fastcall TSearchOptions::LoadFromFiler( TNNFTextStream *Filer )
{
  CaseSensitive = Filer->ReadBool();
  AnyEntry      = Filer->ReadBool();
  NotThis       = Filer->ReadBool();
  IsSoft        = Filer->ReadBool();
  IsMistake     = Filer->ReadBool();
}

void __fastcall TSearchOptions::SaveToFiler( TNNFTextStream *Filer )
{
  Filer->WriteBool( CaseSensitive );
  Filer->WriteBool( AnyEntry );
  Filer->WriteBool( NotThis );
  Filer->WriteBool( IsSoft );
  Filer->WriteBool( IsMistake );
}

void __fastcall TSearchDlgOptions::LoadFromFiler( TNNFTextStream *Filer )
{
  SearchOptions.LoadFromFiler( Filer );
  Backward     = Filer->ReadBool();
  StartIsBegin = Filer->ReadBool();
  IsAND        = Filer->ReadBool();
}

TSearchDlgOptions::TSearchDlgOptions()
: Backward( false )
, StartIsBegin( true )
, IsAND( true )
{
}

TSearchDlgOptions::TSearchDlgOptions( const TSearchOptions &aSearchOptions
                                    , bool aBackward
                                    , bool aStartIsBegin
                                    , bool aIsAND )
  : SearchOptions( aSearchOptions )
  , Backward( aBackward )
  , StartIsBegin( aStartIsBegin )
  , IsAND( aIsAND )
{
}

void __fastcall TSearchDlgOptions::SaveToFiler( TNNFTextStream *Filer )
{
  SearchOptions.SaveToFiler( Filer );
  Filer->WriteBool( Backward );
  Filer->WriteBool( StartIsBegin );
  Filer->WriteBool( IsAND );
}

}

