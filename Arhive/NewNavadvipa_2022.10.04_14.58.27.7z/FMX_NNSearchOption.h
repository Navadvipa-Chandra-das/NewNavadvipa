//---------------------------------------------------------------------------
#ifndef FMX_NNSearchOptionH
#define FMX_NNSearchOptionH
//---------------------------------------------------------------------------
#include "FMX_NNStream.h"
#include <Data.DB.hpp>

class PACKAGE TNNSearchComboParams
{
  public:
    TNNSearchComboParams();
    ~TNNSearchComboParams();
    TDataSet *DataSet;
    int Tag;
    String Label;
    int FieldTag;
    int MaxLength;
    void __fastcall Clear();
};

typedef PACKAGE void __fastcall (__closure *TNNGetSComboParams )( System::TObject* Sender, TNNSearchComboParams &ComboParams );
typedef PACKAGE void __fastcall (__closure *TNNCompareResult )( System::TObject* Sender, int FieldTag, String &Result );

namespace NNF {

class PACKAGE TSearchOptions
{
public:
  TSearchOptions();
  TSearchOptions( bool aCaseSensitive
                , bool aAnyEntry
                , bool aNotThis
                , bool aIsSoft
                , bool aIsMistake );
  TSearchOptions( const TSearchOptions& a );
  bool CaseSensitive;
  bool AnyEntry;
  bool NotThis;
  bool IsSoft;
  bool IsMistake;
  void __fastcall LoadFromFiler( TNNFTextStream *Filer );
  void __fastcall SaveToFiler( TNNFTextStream *Filer );
};

class PACKAGE TSearchDlgOptions
{
public:
  TSearchOptions SearchOptions;
  bool Backward;
  bool StartIsBegin;
  bool IsAND;
  TSearchDlgOptions();
  TSearchDlgOptions( const TSearchOptions &aSearchOptions
                   , bool aBackward
                   , bool aStartIsBegin
                   , bool aIsAND );
  void __fastcall LoadFromFiler( TNNFTextStream *Filer );
  void __fastcall SaveToFiler( TNNFTextStream *Filer );
};

}

#endif

