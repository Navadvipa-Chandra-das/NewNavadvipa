﻿//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "FMX_NNFmAboutPrabhupadaSlovar.h"
#include "FMX_NNFmPrabupadaSlovar.h"
#include "FMX_NNConst.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "FMX_NNConfig"
#pragma link "FMX_NNFmRes"
#pragma resource "*.fmx"
TfmfAboutPrabhupadaSlovar *fmfAboutPrabhupadaSlovar;
//---------------------------------------------------------------------------
__fastcall TfmfAboutPrabhupadaSlovar::TfmfAboutPrabhupadaSlovar(TComponent* Owner)
  : inherited( Owner )
{
  tcPrabhupadaAbout->Images = fmfPrabhupadaSlovar->ilPrabhupadaSlovar;
}

//---------------------------------------------------------------------------
void __fastcall TfmfAboutPrabhupadaSlovar::FormClose( TObject *Sender, TCloseAction &Action )
{
  Action = TCloseAction::caFree;
}
//---------------------------------------------------------------------------

void __fastcall TfmfAboutPrabhupadaSlovar::cfgResDefault(TObject *Sender)
{
  Position = TFormPosition::ScreenCenter;
}
//---------------------------------------------------------------------------

void __fastcall TfmfAboutPrabhupadaSlovar::buCloseClick(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------

void __fastcall TfmfAboutPrabhupadaSlovar::FormCreate( TObject *Sender )
{
  inherited::FormCreate( Sender );
  icPrabhupada->LoadFromFile( NNFConst::PrabhupadaFiles + L"Prabhupada.jpg" );
  mePrabhupadaLila->Lines->LoadFromFile( NNFConst::PrabhupadaFiles + L"PrabhupadaLila.txt" );
  meHelp->Lines->LoadFromFile( NNFConst::PrabhupadaFiles + L"Help.txt" );
  meLetter->Lines->LoadFromFile( NNFConst::PrabhupadaFiles + L"Letter.txt" );
}
//---------------------------------------------------------------------------

