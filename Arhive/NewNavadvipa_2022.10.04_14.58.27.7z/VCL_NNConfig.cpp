﻿// ---------------------------------------------------------------------------
// New Navadvipa library - author Navadvipa Chandra das e-mail navadvipa.chandra.das@nizhnyaya-navadvipa.ru
#include <vcl.h>

#pragma hdrstop

#include "VCL_NNConfig.h"
#include "VCL_NNConst.h"
#include <memory>

#pragma resource "*.res"
#pragma package(smart_init)

static inline void ValidCtrCheck(TNNVConfig *)
{
  new TNNVConfig( NULL );
}

TNNVConfig::TNNVConfig( TComponent* Owner )
  : inherited( Owner )
  , fVersion( char() )
  , fTableUserReg( NNVConst::TableUserReg )
  , fFieldUserRegKey( NNVConst::FieldUserRegKey )
  , fFieldUserData( NNVConst::FieldUserData )
{
}

bool __fastcall TNNVConfig::StoredTableUserReg()
{
  return fTableUserReg != NNVConst::TableUserReg;
}

bool __fastcall TNNVConfig::StoredFieldUserRegKey()
{
  return fFieldUserRegKey != NNVConst::FieldUserRegKey;
}

bool __fastcall TNNVConfig::StoredFieldUserData()
{
  return fFieldUserData != NNVConst::FieldUserData;
}

void __fastcall TNNVConfig::Notification( TComponent *AComponent, TOperation Operation )
{
  inherited::Notification( AComponent, Operation );
  if ( ( Operation == opRemove ) && ( AComponent == Connection ) )
    fConnection = nullptr;
}

void __fastcall TNNVConfig::Load()
{
  if ( !Enabled )
    return;

  switch ( StoreKind ) {
  case skFile:
    PrepareFilerFromFile();
    break;
  case skFiler:
    PrepareFilerFromUserEvent();
    break;
  case skDB:
    PrepareFilerFromDB();
  }
}

void __fastcall TNNVConfig::Save()
{
  if ( !Enabled )
    return;

  switch ( StoreKind ) {
  case skFile:
    SaveToFile();
    break;
  case skFiler:
    SaveToFiler();
    break;
  case skDB:
    SaveToDB();
  }
}

void __fastcall TNNVConfig::DoLoad()
{
  DoBeginLoad();
  try {
    if ( FOnLoad )
      FOnLoad(this);
  } __finally {
    DoEndLoad();
  }
}

void __fastcall TNNVConfig::DoDefault()
{
  DoBeginLoad();
  try {
    if ( FOnDefault )
      FOnDefault( this );
  } __finally {
    DoEndLoad();
  }
}

void __fastcall TNNVConfig::DoSave()
{
  DoBeginSave();
  try {
    if ( FOnSave )
      FOnSave( this );
  } __finally {
    DoEndSave();
  }
}

void __fastcall TNNVConfig::LoadFilerFromUserEvent()
{
  bool B = true;
  Filer->Position = 0;
  if ( Version == Filer->ReadChar() ) {
    DoLoad();
    if ( Version != Filer->ReadChar() )
      throw Exception( L"Ошибка чтения потока TNNVConfig" );
    else
      B = false;
  }
  if ( B )
    DoDefault();
}

void __fastcall TNNVConfig::SaveFilerFromUserEvent()
{
  Filer->Position = 0;
  Filer->WriteChar( Version );
  DoSave();
  Filer->WriteChar( Version );
  Filer->Size = Filer->Position;
}

void __fastcall TNNVConfig::PrepareFilerFromFile()
{
  String fn = RegistryKey();
  if ( !FileExists( fn ) ) {
    DoDefault();
    return;
  }

  std::unique_ptr< TFileStream >fs( new TFileStream( fn, fmOpenRead ) );
  fFiler = new TNNVTextStream( fs.get() );
  try {
    LoadFilerFromUserEvent();
  } __finally {
    delete fFiler;
    fFiler = nullptr;
  }
}

void __fastcall TNNVConfig::PrepareFilerFromDB()
{
  fFiler = new TNNVTextStream( nullptr );

  try {
    if ( LoadFromDB() )
      LoadFilerFromUserEvent();
    else
      DoDefault();
  } __finally {
    delete fFiler;
    fFiler = nullptr;
  }
}

void __fastcall TNNVConfig::PrepareFilerFromUserEvent()
{
  if ( Filer )
    throw Exception( L"Не определён fFiler" );

  DoGetFiler();
  if ( Filer && ( Filer->Size != 0 ) )
    LoadFilerFromUserEvent();
  else
    DoDefault();
}

void __fastcall TNNVConfig::SaveToFile()
{
  String fn = RegistryKey();
  if ( !FileExists( fn ) ) {
    NativeUInt H = FileCreate( fn );
    FileClose( H );
  }
  TFileStream* fs = new TFileStream( fn, fmOpenWrite );
  fFiler = new TNNVTextStream( fs );
  try {
    SaveFilerFromUserEvent();
  } __finally {
    delete fFiler;
    fFiler = nullptr;
    if ( fs )
      delete fs;
  }
}

void __fastcall TNNVConfig::SaveToFiler()
{
  fFiler = nullptr;
  DoGetFiler();
  if ( Filer )
    SaveFilerFromUserEvent();
}

void __fastcall TNNVConfig::SetConnection(TFDConnection *value)
{
  if ( Connection != value ) {
    fConnection = value;
    if ( value )
      value->FreeNotification( this );
  }
}

void __fastcall TNNVConfig::PrepareQuerySQL( TFDQuery *quReg, const String &UserRegKey )
{
  quReg->SQL->Text = "select " + FieldUserRegKey + "," + FieldUserData +
                    " from " + TableUserReg +
                    " where " + FieldUserRegKey + " = :UserRegKey_";
  quReg->Params->Items[ 0 ]->DataType = ftString;
  quReg->Params->Items[ 0 ]->AsString = UserRegKey;
  quReg->UpdateOptions->AutoCommitUpdates = true;
  quReg->Open();
}

void __fastcall TNNVConfig::SaveToDB()
{
  if ( !IsConnection() )
    return;

  String RK = RegistryKey();
  fFiler = new TNNVTextStream( nullptr );
  try {
    SaveFilerFromUserEvent();
    std::unique_ptr< TNNVQuery > quReg( new TNNVQuery( this ) );
    std::unique_ptr< TFDTransaction > trReg( new TFDTransaction( this ) );
    quReg->Connection = Connection;
    trReg->Connection = Connection;
    quReg->Transaction = trReg.get();
    PrepareQuerySQL( quReg.get(), RK );
    if ( quReg->RecordCount == 0 ) {
      quReg->Insert();
      quReg->Fields->Fields[ 0 ]->AsString = RK;
    }
    else
      quReg->Edit();
    TBlobField *bf = ( ( TBlobField* )( quReg->Fields->Fields[ 1 ] ) );
    bf->LoadFromStream( Filer );
    quReg->Post();
  } __finally {
    delete fFiler;
    fFiler = nullptr;
  }
}

bool __fastcall TNNVConfig::LoadFromDB()
{
  if ( !IsConnection() )
    return false;

  bool B = false;
  std::unique_ptr< TNNVQuery > quReg( new TNNVQuery( this ) );
  std::unique_ptr< TFDTransaction > trReg( new TFDTransaction( this ) );
  quReg->Connection = Connection;
  trReg->Connection = Connection;
  quReg->Transaction = trReg.get();
  String RK = RegistryKey();
  PrepareQuerySQL( quReg.get(), RK );
  if ( quReg->RecordCount == 1 ) {
    TBlobField *bf = ( ( TBlobField* )( quReg->Fields->Fields[ 1 ] ) );
    bf->SaveToStream( Filer );
    B = true;
  }
  return B;
}

String __fastcall TNNVConfig::RegistryKey()
{
  String S;
  if ( StaticRegistryKey.IsEmpty() )
    S = NNV::ComponentToKey( Owner, UseOwnerNameInRegistryKey );
  else
    S = StaticRegistryKey;

  if ( UseUserNameInRegistryKey ) {
    String AUserName;
    if ( StaticUserName.IsEmpty() ) {
      if ( Connection != nullptr ) {
        AUserName = Connection->Params->UserName;
        if ( !AUserName.IsEmpty() )
          S = AUserName + L"-" + S;
      }
    } else
      S = StaticUserName + L"-" + S;
  }
  return S;
}

bool __fastcall TNNVConfig::IsConnection()
{
  if ( Connection == nullptr )
    return false;
  else
    return Connection->Connected;
}

// ---------------------------------------------------------------------------
namespace Vcl_nnconfig
{
  void __fastcall PACKAGE Register() {
    TComponentClass classes[1] = { __classid( TNNVConfig ) };
    RegisterComponents( L"VCL New Navadvipa", classes, 0 );
  }
}
// ---------------------------------------------------------------------------

