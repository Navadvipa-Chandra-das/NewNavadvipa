//---------------------------------------------------------------------------
#include <fmx.h>

#pragma hdrstop

#include "FMX_NNFmRes.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "FMX_NNConfig"
#pragma resource "*.fmx"
TfmfRes *fmfRes;
//---------------------------------------------------------------------------
__fastcall TfmfRes::TfmfRes(TComponent* Owner)
  : inherited( Owner  )
{
}

//---------------------------------------------------------------------------
void __fastcall TfmfRes::FormCreate(TObject *Sender)
{
  cfgRes->Load();
}
//---------------------------------------------------------------------------

void __fastcall TfmfRes::FormDestroy(TObject *Sender)
{
  cfgRes->Save();
}
//---------------------------------------------------------------------------

void __fastcall TfmfRes::cfgResLoad(TObject *param_0)
{
  Left   = cfgRes->Filer->ReadInt();
  Top    = cfgRes->Filer->ReadInt();
  Width  = cfgRes->Filer->ReadInt();
  Height = cfgRes->Filer->ReadInt();
  Lang   = cfgRes->Filer->ReadString();
}
//---------------------------------------------------------------------------

void __fastcall TfmfRes::cfgResSave(TObject *param_0)
{
  cfgRes->Filer->WriteInt( Left );
  cfgRes->Filer->WriteInt( Top );
  cfgRes->Filer->WriteInt( Width );
  cfgRes->Filer->WriteInt( Height );
  cfgRes->Filer->WriteString( Lang );
}
//---------------------------------------------------------------------------

void __fastcall TfmfRes::SetLang( String Value )
{
  if ( FLang != Value ) {
    FLang = Value;

    LangUpdate();
  }
}
