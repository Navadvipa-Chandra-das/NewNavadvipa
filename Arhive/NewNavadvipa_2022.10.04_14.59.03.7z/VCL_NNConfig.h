// New Navadvipa library - author Navadvipa Chandra das e-mail navadvipa.chandra.das@nizhnyaya-navadvipa.ru
#ifndef VCL_NNConfigH
#define VCL_NNConfigH
// ---------------------------------------------------------------------------
#include <FireDAC.Comp.Client.hpp>
#include "VCL_NNCommon.h"
#include "VCL_NNDBMiracle.h"

PACKAGE enum TNNVStoreKind { skFile, skFiler, skDB };

typedef PACKAGE void __fastcall( __closure *TNNVGetFiler ) ( System::TObject *Sender, TNNVTextStream *&Filer );

// ---------------------------------------------------------------------------
class PACKAGE TNNVConfig : public TComponent {
private:
  typedef TComponent inherited;
  TNotifyEvent FOnLoad;
  TNotifyEvent FOnSave;
  TNotifyEvent FOnDefault;
  TNotifyEvent FOnBeginLoad;
  TNotifyEvent FOnEndLoad;
  TNotifyEvent FOnBeginSave;
  TNotifyEvent FOnEndSave;
  TNNVGetFiler FOnGetFiler;
  char fVersion;
  TNNVStoreKind fStoreKind = skDB;
  TNNVTextStream *fFiler = nullptr;
  TFDConnection *fConnection = nullptr;
  bool fEnabled = true;
  String fTableUserReg;
  String fFieldUserRegKey;
  String fFieldUserData;
  String FStaticRegistryKey;
  String FStaticUserName;
  bool FUseUserNameInRegistryKey = true;
  bool FUseOwnerNameInRegistryKey = true;

  bool __fastcall StoredTableUserReg();
  bool __fastcall StoredFieldUserRegKey();
  bool __fastcall StoredFieldUserData();
  void __fastcall PrepareQuerySQL( TFDQuery *quReg, const String &UserRegKey );
  bool __fastcall LoadFromFiler();
  bool __fastcall LoadFromDB();
  void __fastcall PrepareFilerFromFile();
  void __fastcall PrepareFilerFromUserEvent();
  void __fastcall PrepareFilerFromDB();
  void __fastcall LoadFilerFromUserEvent();
  void __fastcall SaveFilerFromUserEvent();
  void __fastcall LoadFile();
  void __fastcall LoadFiler();
  void __fastcall SaveToFile();
  void __fastcall SaveToFiler();
  void __fastcall SaveToDB();
  void __fastcall SetConnection( TFDConnection *value );
  bool __fastcall IsConnection();

protected:
  virtual void __fastcall Notification( TComponent *AComponent, TOperation Operation );
  virtual void __fastcall DoLoad();
  virtual void __fastcall DoSave();
  virtual void __fastcall DoDefault();

  virtual void __fastcall DoBeginLoad()
  {
    if ( FOnBeginLoad )
      FOnBeginLoad( this );
  };

  virtual void __fastcall DoEndLoad()
  {
    if ( FOnEndLoad )
      FOnEndLoad( this );
  };

  virtual void __fastcall DoBeginSave()
  {
    if ( FOnBeginSave )
      FOnBeginSave( this );
  };

  virtual void __fastcall DoEndSave()
  {
    if ( FOnEndSave )
      FOnEndSave( this );
  };

  virtual void __fastcall DoGetFiler()
  {
    if ( FOnGetFiler )
      FOnGetFiler( this, fFiler );
  };

public:
  __fastcall TNNVConfig( TComponent* Owner );
  __property TNNVTextStream *Filer = { read = fFiler };
  String __fastcall RegistryKey();
  void __fastcall Load();
  void __fastcall Save();

__published:
  __property TNNVStoreKind StoreKind = { read = fStoreKind, write = fStoreKind, default = skDB };
  __property char Version = { read = fVersion, write = fVersion, default = char() };
  __property bool Enabled = { read = fEnabled, write = fEnabled, default = true };
  __property TNotifyEvent OnLoad = { read = FOnLoad, write = FOnLoad };
  __property TNotifyEvent OnSave = { read = FOnSave, write = FOnSave };
  __property TNotifyEvent OnDefault = { read = FOnDefault, write = FOnDefault };
  __property TNotifyEvent OnBeginLoad = { read = FOnBeginLoad, write = FOnBeginLoad };
  __property TNotifyEvent OnEndLoad = { read = FOnEndLoad, write = FOnEndLoad };
  __property TNotifyEvent OnBeginSave = { read = FOnBeginSave, write = FOnBeginSave };
  __property TNotifyEvent OnEndSave = { read = FOnEndSave, write = FOnEndSave };
  __property TNNVGetFiler OnGetFiler = { read = FOnGetFiler, write = FOnGetFiler };
  __property TFDConnection *Connection = { read = fConnection, write = SetConnection };
  __property String TableUserReg = { read = fTableUserReg, write = fTableUserReg, stored = StoredTableUserReg };
  __property String FieldUserRegKey = { read = fFieldUserRegKey, write = fFieldUserRegKey, stored = StoredFieldUserRegKey };
  __property String FieldUserData = { read = fFieldUserData, write = fFieldUserData, stored = StoredFieldUserData };
  __property String StaticRegistryKey = { read = FStaticRegistryKey, write = FStaticRegistryKey };
  __property String StaticUserName = { read = FStaticUserName, write = FStaticUserName };
  __property bool UseUserNameInRegistryKey = { read = FUseUserNameInRegistryKey, write = FUseUserNameInRegistryKey, default = true };
  __property bool UseOwnerNameInRegistryKey = { read = FUseOwnerNameInRegistryKey, write = FUseOwnerNameInRegistryKey, default = true };
};
// ---------------------------------------------------------------------------
#endif
