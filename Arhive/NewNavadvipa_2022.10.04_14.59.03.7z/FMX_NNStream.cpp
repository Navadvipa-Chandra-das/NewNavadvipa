// NizhnyayaNavadvipa library - author Navadvipa Chandra das
// e-mail navadwip@rambler.ru , http://nizhnyaya-navadvipa.ru/
#include <fmx.h>
#pragma hdrstop
#include "FMX_NNStream.h"
#include <memory>

//---------------------------------------------------------------------------
#pragma package(smart_init)

__fastcall TNNFTextStream::TNNFTextStream( TStream *AStream )
  : inherited()
, fIsDeleteStream( false )
{
  fStream = AStream;
}

_fastcall TNNFTextStream::~TNNFTextStream()
{
  if ( fIsDeleteStream )
    delete fStream;
}

bool __fastcall TNNFTextStream::ReadBool()
{
  bool R;
  Read( &R, sizeof( R ) );
  return R;
}

char __fastcall TNNFTextStream::ReadChar()
{
  char R;
  Read( &R, sizeof( R ) );
  return R;
}

unsigned char __fastcall TNNFTextStream::ReadUnsignedChar()
{
  unsigned char R;
  Read( &R, sizeof( R ) );
  return R;
}

int __fastcall TNNFTextStream::ReadInt()
{
  int R;
  Read( &R, sizeof( R ) );
  return R;
}

short int __fastcall TNNFTextStream::ReadShortInt()
{
  short int R;
  Read( &R, sizeof( R ) );
  return R;
}

unsigned short int __fastcall TNNFTextStream::ReadUnsignedShortInt()
{
  short int R;
  Read( &R, sizeof( R ) );
  return R;
}

std::size_t __fastcall TNNFTextStream::ReadSizeType()
{
  std::size_t R;
  Read( &R, sizeof( R ) );
  return R;
}

NativeInt __fastcall TNNFTextStream::ReadNativeInt()
{
  NativeInt R;
  Read( &R, sizeof( R ) );
  return R;
}

unsigned int __fastcall TNNFTextStream::ReadUnsignedInt()
{
  unsigned int R;
  Read( &R, sizeof( R ) );
  return R;
}

TDateTime __fastcall TNNFTextStream::ReadDateTime()
{
  TDateTime R;
  Read( &R, sizeof( R ) );
  return R;
}

short int __fastcall TNNFTextStream::ReadShort()
{
  short int R;
  Read( &R, sizeof( R ) );
  return R;
}

unsigned short int __fastcall TNNFTextStream::ReadUnsignedShort()
{
  unsigned short int R;
  Read( &R, sizeof( R ) );
  return R;
}

long int __fastcall TNNFTextStream::ReadLongInt()
{
  long int R;
  Read( &R, sizeof( R ) );
  return R;
}

long long int __fastcall TNNFTextStream::ReadLongLongInt()
{
  long long int R;
  Read( &R, sizeof( R ) );
  return R;
}

unsigned long int __fastcall TNNFTextStream::ReadUnsignedLongInt()
{
  unsigned long int R;
  Read( &R, sizeof( R ) );
  return R;
}

unsigned long long int __fastcall TNNFTextStream::ReadUnsignedLongLongInt()
{
  unsigned long long int R;
  Read( &R, sizeof( R ) );
  return R;
}

float __fastcall TNNFTextStream::ReadFloat()
{
  float R;
  Read( &R, sizeof( R ) );
  return R;
}

double __fastcall TNNFTextStream::ReadDouble()
{
  double R;
  Read( &R, sizeof( R ) );
  return R;
}

long double __fastcall TNNFTextStream::ReadLongDouble()
{
  long double R;
  Read( &R, sizeof( R ) );
  return R;
}

TAlphaColor __fastcall TNNFTextStream::ReadColor()
{
  TAlphaColor R;
  Read( &R, sizeof( R ) );
  return R;
}

TTextAlign __fastcall TNNFTextStream::ReadTextAlign()
{
  TTextAlign R;
  Read( &R, sizeof( R ) );
  return R;
}

TTextTrimming __fastcall TNNFTextStream::ReadTextTrimming()
{
  TTextTrimming R;
  Read( &R, sizeof( R ) );
  return R;
}

String __fastcall TNNFTextStream::ReadString()
{
  UTF8String S;
  String R;
  int BufSize;
  Read( &BufSize, sizeof( BufSize ) );
  S.SetLength( BufSize );
  Read( S.c_str(), BufSize );
  R = String( S );
  return R;
}

void __fastcall TNNFTextStream::WriteString( const String &value )
{
  UTF8String S( value );
  int R = S.Length();
  Write( &R, sizeof( R ) );
  Write( S.c_str(), R );
}

bool __fastcall TNNFTextStream::ReadStringLine( String &S )
{
  long long int SP = Position;

  UTF8String R;
  NativeInt BufSize = 0, MinusOffset = 0;

  char C;
  while ( !IsEof() ) {
    Read( &C, sizeof( C ) );
    if ( C == '\r' ) {
      ++MinusOffset;
      if ( !IsEof() ) {
        Read( &C, sizeof( C ) );
        if ( C == '\n' ) {
          ++MinusOffset;
          break;
        } else {
          ++BufSize;
          MinusOffset = 0;
        }
      }
    }
    ++BufSize;
  }

  if ( BufSize > 0 ) {
    Seek( SP, soBeginning );
    R.SetLength( BufSize );
    Read( R.c_str(), BufSize );
    Seek( MinusOffset, soCurrent );
    S = String( R );
    return true;
  } else {
    S = L"";
    return false;
  }
}

AnsiString __fastcall TNNFTextStream::ReadAnsiString()
{
  AnsiString R;
  int BufSize;
  Read( &BufSize, sizeof( BufSize ) );
  R.SetLength( BufSize );
  Read( R.c_str(), BufSize );
  return R;
}

void __fastcall TNNFTextStream::WriteAnsiString( const AnsiString &value )
{
  int R = value.Length();
  Write( &R, sizeof( R ) );
  Write( value.c_str(), R );
}

void __fastcall TNNFTextStream::ReadBinaryData( void *Buffer )
{
  int BufSize;
  Read( &BufSize, sizeof( BufSize ) );
  Read( Buffer, BufSize );
}

void __fastcall TNNFTextStream::ReadFiler( TNNFTextStream *filer )
{
  ((TMemoryStream*)filer->Stream)->SetSize( ReadInt() );
  Read( ((TMemoryStream*)filer->Stream)->Memory, filer->Stream->Size );
}

void __fastcall TNNFTextStream::WriteFiler( TNNFTextStream *filer )
{
  WriteInt( filer->Stream->Size );
  filer->Position = 0;
  Write( ((TMemoryStream*)filer->Stream)->Memory, filer->Stream->Size );
}

void __fastcall TNNFTextStream::ReadFont( TFont* AFont )
{
  std::unique_ptr< TFont > f( new TFont() );
  f->Family = ReadString();
  f->Size = ReadInt();
  TFontStyles RS;
  Read( &RS, sizeof( RS ) );
  f->Style = RS;
  TFontStyleExt RSE;
  Read( &RSE, sizeof( RSE ) );
  f->StyleExt = RSE;
  AFont->Assign( f.get() );
}

void __fastcall TNNFTextStream::WriteFont( TFont* AFont )
{
  WriteString( AFont->Family );
  WriteInt( AFont->Size );
  TFontStyles RS = AFont->Style;
  Write( &RS, sizeof( RS ) );
  TFontStyleExt RSE = AFont->StyleExt;
  Write( &RSE, sizeof( RSE ) );
}

void __fastcall TNNFTextStream::ReadFontColorForState( TFontColorForState* AFontColorForState )
{
  std::unique_ptr< TFontColorForState > fcfs( new TFontColorForState( AFontColorForState->Owner ) );
  fcfs->Active  = ReadColor();
  fcfs->Focused = ReadColor();
  fcfs->Hot     = ReadColor();
  fcfs->Normal  = ReadColor();
  fcfs->Pressed = ReadColor();
  AFontColorForState->Assign( fcfs.get() );
}

void __fastcall TNNFTextStream::WriteFontColorForState( TFontColorForState* AFontColorForState )
{
  WriteColor( AFontColorForState->Active  );
  WriteColor( AFontColorForState->Focused );
  WriteColor( AFontColorForState->Hot     );
  WriteColor( AFontColorForState->Normal  );
  WriteColor( AFontColorForState->Pressed );
}

void __fastcall TNNFTextStream::ReadTextSettings( TTextSettings* ATextSettings )
{
  std::unique_ptr< TTextSettings > ts( new TTextSettings( ATextSettings->Owner ) );
  ReadFont( ts->Font );
  ts->FontColor = ReadColor();
  ReadFontColorForState( ts->FontColorForState );
  ts->HorzAlign = ReadTextAlign();
  ts->VertAlign = ReadTextAlign();
  ts->Trimming  = ReadTextTrimming();
  ts->WordWrap  = ReadBool();
  ATextSettings->Assign( ts.get() );
}

void __fastcall TNNFTextStream::WriteTextSettings( TTextSettings* ATextSettings )
{
  WriteFont(              ATextSettings->Font              );
  WriteColor(             ATextSettings->FontColor         );
  WriteFontColorForState( ATextSettings->FontColorForState );
  WriteTextAlign(         ATextSettings->HorzAlign         );
  WriteTextAlign(         ATextSettings->VertAlign         );
  WriteTextTrimming(      ATextSettings->Trimming          );
  WriteBool(              ATextSettings->WordWrap          );
}

TShortCut __fastcall TNNFTextStream::ReadShortCut()
{
  TShortCut R;
  Read( &R, sizeof( R ) );
  return R;
}

void __fastcall TNNFTextStream::ResetVersion()
{
  if ( Size == 0 ) return;
  long long int P = Position;
  unsigned char R;
  Read( &R, sizeof( R ) );
  Position = 0;
  ++R;
  Write( &R, sizeof( R ) );
  Position = P;
}

Variant __fastcall TNNFTextStream::ReadDoubleVariant()
{
  bool IsNull;
  Variant V;
  Read( &IsNull, sizeof( IsNull ) );
  if ( IsNull )
    V.Clear();
  else {
    double R;
    Read( &R, sizeof( R ) );
    V = R;
  }
  return V;
}

void __fastcall TNNFTextStream::WriteDoubleVariant( const Variant &R )
{
  bool IsNull = R.IsNull();
  WriteBool( IsNull );
  if ( !IsNull ) {
    double D = R;
    WriteDouble( D );
  }
}

Variant __fastcall TNNFTextStream::ReadDateTimeVariant()
{
  bool IsNull;
  Variant V;
  Read( &IsNull, sizeof( IsNull ) );
  if ( IsNull )
    V.Clear();
  else {
    TDateTime R;
    Read( &R, sizeof( R ) );
    V = R;
  }
  return V;
}

void __fastcall TNNFTextStream::WriteDateTimeVariant( const Variant &R )
{
  bool IsNull = R.IsNull();
  WriteBool( IsNull );
  if ( !IsNull ) {
    TDateTime D = R;
    WriteDateTime( D );
  }
}

Variant __fastcall TNNFTextStream::ReadStringVariant()
{
  bool IsNull;
  Variant V;
  Read( &IsNull, sizeof( IsNull ) );
  if ( IsNull )
    V.Clear();
  else {
    String S = ReadString();
    V = S;
  }
  return V;
}

void __fastcall TNNFTextStream::WriteStringVariant( const Variant &R )
{
  bool IsNull = R.IsNull();
  WriteBool( IsNull );
  if ( !IsNull ) {
    String S = R;
    WriteString( S );
  }
}

