//---------------------------------------------------------------------------

#ifndef FMX_NNFmResH
#define FMX_NNFmResH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include "FMX_NNConfig.h"
#include <FMX.Types.hpp>
//---------------------------------------------------------------------------
class TfmfRes : public TForm
{
__published:	// IDE-managed Components
  TNNFConfig *cfgRes;
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormDestroy(TObject *Sender);
  void __fastcall cfgResLoad(TObject *param_0);
  void __fastcall cfgResSave(TObject *param_0);
private:	// User declarations
  typedef TForm inherited;
  String FLang;
  void __fastcall SetLang( String Value );
protected:
  virtual void __fastcall LangUpdate() {};
public:		// User declarations
  __fastcall TfmfRes( TComponent* Owner );
  __property String Lang = { read = FLang, write = SetLang };
};
//---------------------------------------------------------------------------
extern PACKAGE TfmfRes *fmfRes;
//---------------------------------------------------------------------------
#endif
