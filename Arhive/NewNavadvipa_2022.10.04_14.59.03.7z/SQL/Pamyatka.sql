S325L
SNixk_ExcynhiL
Sfcfi_ygixihigL
C:\PostgreSQL\psqlODBC\bin\libpq.dll
C:\PostgreSQL\14\bin\libpq.dll
C:\INSTALL\SQLiteStudio\sqlite3.dll 

ALTER TABLE IF EXISTS public."Entity"
    ADD CONSTRAINT "KindFK" FOREIGN KEY ("KindID")
    REFERENCES public."Entity" ("KindID") MATCH SIMPLE
    ON UPDATE CASCADE
    ON DELETE CASCADE
    NOT VALID;

C:/C\NewNavadvipa/SQL/NewNavadvipaGlobals.sql 

CREATE SEQUENCE public."Users_UserID_seq2"
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;

CycleColor0 = 0
CycleColor3 = 1
CycleColor4 = 2
Service = 3
CommodAss = 4
CommodAssOwner = 5
CommodAssDetail = 6
CommodLack = 7
CommodOld = 8
CommodWithNote = 9
CommentInPrim = 10
 = 11
ErrorSubconto = 12
GrayLine = 13
CommentSummaFirst = 14
SummaFirst = 15
SummaSecond = 16
InDialogQuantity = 17
InDialogPriceBig = 18
CycleColor21 = 19
SerialWithGuaranty = 20
SerialWaitWithGuaranty = 21
SerialSupplierWithoutGuaranty = 22
CycleColor10 = 23
CycleColor11 = 24
CycleColor12 = 25
CycleColor13 = 26
CycleColor22 = 27
CycleColor23 = 28
CycleColor24 = 29
CycleColor26 = 30
SerialWithoutGuaranty = 31
SerialSaleWithGuaranty = 32
SerialSaleWithoutGuaranty = 33
SerialWaitWithoutGuaranty = 34
SerialTemporaryWithGuaranty = 35
SerialTemporaryWithoutGuaranty = 36
SerialSupplierWithGuaranty = 37
SerialXWithGuaranty = 38
SerialXWithoutGuaranty = 39
SerialPayAndStore = 40
CycleColor5 = 41
CycleColor6 = 42
CycleColor7 = 43
CycleColor8 = 44
CycleColor9 = 45
SerialNotPayAndStore = 46
SerialChangeSupplierWithGuaranty = 47
SerialChangeSupplierWithoutGuaranty = 48
CommentPartSumma3 = 49
PartSumma3 = 50
NotActualOper = 51
PrimWithComment = 52
ActualComment = 53
PriceCommodPayBig = 54
PartPay = 55
HotKey = 56
HotKeyWithoutShift = 57
EmptyHotKey = 58
ChessMinusSumma = 59
ChessNeutralConstr = 60
ChessAccount = 61
ChessItog = 62
KalaYantra = 63
InDialogPriceSmall = 64
InDialogCommodNullQuantity = 65
InDialogCommodMinusQuantity = 66
CycleColor14 = 67
CycleColor15 = 68
CycleColor16 = 69
CycleColor17 = 70
CycleColor18 = 71
CycleColor19 = 72
CycleColor20 = 73
CycleColor25 = 74
SummaSmallOpt = 75
SummaDiler = 76
SummaOpt = 77
SummaEntry = 78
SummaSmallThanEntry = 79
SummaMoreThanRetail = 80
CommodMarkdown1 = 81
CommodMarkdown2 = 82
CommodMarkdown3 = 83
CommodMarkdown4 = 84
SlyUserEnter = 85
SlyUserDelete = 86
SlyUserCreate = 87
StorehousOperAndPrimDifferent = 88
KaemkaIndicatorNormal = 89
FieldIndicatorNormal = 90
KaemkaIndicatorSignal = 91
FieldIndicatorSignal = 92
PrimPayAndNotShipment = 93
PrimShipmentAndNotPay = 94
TabelVyhodovNotAny = 95
TabelVyhodovProgul = 96
PriceLastCommod = 97
SerialPay = 98
SerialPayByNotSrok = 99
OperComokNotPayDebetPrim = 100
OperComokNotPayCreditPrim = 101
CommodVeryOld = 102
CommentColorWinow = 103
SchetCreditPayBeznalAndNotDocuments = 104
SchetCreditAcceptlAndNotPayAndNotOtgr = 105
SerialStoreButNotPayProvider = 106
CycleColor2 = 107
CycleColor1 = 108
ServiceClient1_7 = 109
ServiceClient8_14 = 110
SerialDifferentCommod = 111
ServiceClient15_21 = 112
ServiceClient22_28 = 113
ServiceClientMore29 = 114
TabelVyhodovOtpusk = 115
TabelVyhodovBolnichnyi = 116
TabelVyhodovNotStandartTime = 117
TabelVyhodovPolovinaStavka = 118
SummaRetail = 119
SerialPayButNotPayProvider = 120
ExitFromProgram = 121
PrintPrim = 122
ProgramTryVzlom = 123
CommodPay = 124
BuhgalterCommod = 125
DoctorZayavkaNotExecute = 126
