// Nizhnyaya Navadvipa library - author Navadvipa Chandra das e-mail navadvipa.chandra.das@nizhnyaya-navadvipa.ru
#ifndef FMX_NNCommonH
#define FMX_NNCommonH
#include <Data.DB.hpp>
#include <FMX.ComboEdit.hpp>
#include "FMX_NNStream.h"
#include <vector>
#include <map>

namespace NNF {

extern PACKAGE const int RussianIndex;

extern PACKAGE String __fastcall RemoveDiacritics( const String& S );
extern PACKAGE bool __fastcall PrabhupadaComareLess( const String& A, const String& B );
extern PACKAGE bool __fastcall PrabhupadaComareMore( const String& A, const String& B );

class PACKAGE TFilterSlovar
{
private:
  String FSanskrit;
  String FPerevod;
  String FSanskritWithoutDiakritik;
  String FPerevodWithoutDiakritik;
  bool FIsEmpty = true;
  bool FIsReset = true;
  void __fastcall SetSanskrit( const String &Value );
  void __fastcall SetPerevod( const String &Value );
public:
  TFilterSlovar();
  TFilterSlovar( const TFilterSlovar &A );
  TFilterSlovar( const String &ASanskrit
               , const String &APerevod );
  ~TFilterSlovar();
  TFilterSlovar& operator = ( const TFilterSlovar & a );

  void __fastcall LoadFromFiler( TNNFTextStream *Filer );
  void __fastcall SaveToFiler( TNNFTextStream *Filer );

  __property String Sanskrit = { read = FSanskrit, write = SetSanskrit };
  __property String Perevod = { read = FPerevod, write = SetPerevod };
  __property String SanskritWithoutDiakritik = { read = FSanskritWithoutDiakritik, write = FSanskritWithoutDiakritik };
  __property String PerevodWithoutDiakritik = { read = FPerevodWithoutDiakritik, write = FPerevodWithoutDiakritik };
  __property bool IsEmpty = { read = FIsEmpty, write = FIsEmpty };
  __property bool IsReset = { read = FIsReset, write = FIsReset };

  bool operator == ( const TFilterSlovar& F )
  {
    return ( Sanskrit == F.Sanskrit ) && ( Perevod == F.Perevod );
  }
  bool operator != ( const TFilterSlovar& F )
  {
    return ( ( Sanskrit != F.Sanskrit ) || ( Perevod != F.Perevod ) );
  }
  bool GetIsEmpty() const
  {
    return Sanskrit.IsEmpty() && Perevod.IsEmpty();
  }
  void Clear()
  {
    Sanskrit = L"";
    Perevod  = L"";
  }
};

class PACKAGE TPrabhupadaBukva
{
private:
  WideChar FBukva;
  int FVes;
public:
  TPrabhupadaBukva();
  ~TPrabhupadaBukva();
  __property WideChar Bukva = { read = FBukva, write = FBukva };
  __property int Ves = { read = FVes, write = FVes };
};

class PACKAGE TPrabhupadaBukvary : public std::map< WideChar, TPrabhupadaBukva >
{
private:
  typedef std::map< WideChar, TPrabhupadaBukva > inherited;
public:
  TPrabhupadaBukvary();
  ~TPrabhupadaBukvary();
};

PACKAGE enum class TOrderBy : int
{
  SanskritVozrastanie
, SanskritUbyvanie
, PerevodVozrastanie
, PerevodUbyvanie
};

class PACKAGE TSanskritPerevod
{
private:
  int FID;
  String FSanskrit;
  String FPerevod;
  String FSanskritWithoutDiakritik;
  String FPerevodWithoutDiakritik;
  int FSearchIndex;
public:
  // ��������� ��� ������������ ����������� � ��������� ������������!
  // ��� �� ��������, ������� ��������
  TSanskritPerevod();
  ~TSanskritPerevod();

  __property String Sanskrit = { read = FSanskrit, write = FSanskrit };
  __property String Perevod = { read = FPerevod, write = FPerevod };
  __property String SanskritWithoutDiakritik = { read = FSanskritWithoutDiakritik, write = FSanskritWithoutDiakritik };
  __property String PerevodWithoutDiakritik = { read = FPerevodWithoutDiakritik, write = FPerevodWithoutDiakritik };
  __property int ID = { read = FID, write = FID };
  __property int SearchIndex = { read = FSearchIndex, write = FSearchIndex };
};

class PACKAGE TPrabhupadaSlovarVector : public std::vector< TSanskritPerevod* >
{
private:
  typedef std::vector< TSanskritPerevod* > inherited;
  int FSearchCount = 0;
public:
  TPrabhupadaSlovarVector();
  ~TPrabhupadaSlovarVector();
  __property int SearchCount = { read = FSearchCount, write = FSearchCount };
};

class PACKAGE TPrabhupadaZakladka
{
private:
  int FRowNum;
  TFilterSlovar FFilterSlovar;
public:
  TPrabhupadaZakladka();
  TPrabhupadaZakladka( int ARowNum
                     , TFilterSlovar AFilterSlovar );
  ~TPrabhupadaZakladka();

  void __fastcall LoadFromFiler( TNNFTextStream *Filer );
  void __fastcall SaveToFiler( TNNFTextStream *Filer );

  __property int RowNum = { read = FRowNum, write = FRowNum };
  __property TFilterSlovar FilterSlovar = { read = FFilterSlovar };
};

class PACKAGE TPrabhupadaZakladkaMap : public std::map< unsigned short, TPrabhupadaZakladka >
{
private:
  typedef std::map< unsigned short, TPrabhupadaZakladka > inherited;
public:
  TPrabhupadaZakladkaMap();
  ~TPrabhupadaZakladkaMap();
  void __fastcall LoadFromFiler( TNNFTextStream *Filer );
  void __fastcall SaveToFiler( TNNFTextStream *Filer );
};

class PACKAGE TYazykInfo
{
private:
  int FID;
  String FYazyk;
  String FYazykSlovo;
  String FLang;
  int FCurrentRow = 0;
  TFilterSlovar FFilterSlovar;
  TPrabhupadaZakladkaMap FPrabhupadaZakladkaMap;
public:
  TYazykInfo();
  TYazykInfo( const TYazykInfo &A );
  ~TYazykInfo();
  __property int ID = { read = FID, write = FID };
  __property String Yazyk = { read = FYazyk, write = FYazyk };
  __property String YazykSlovo = { read = FYazykSlovo, write = FYazykSlovo };
  __property String Lang = { read = FLang, write = FLang };
  __property TFilterSlovar FilterSlovar = { read = FFilterSlovar, write = FFilterSlovar };
  __property int CurrentRow = { read = FCurrentRow, write = FCurrentRow };
  __property TPrabhupadaZakladkaMap PrabhupadaZakladkaMap = { read = FPrabhupadaZakladkaMap };
};

class PACKAGE TYazykVector : public std::vector< TYazykInfo >
{
private:
  typedef std::vector< TYazykInfo > inherited;
public:
  TYazykVector();
  ~TYazykVector();
  int __fastcall FindYazyk( const String &S );
  int __fastcall FindLang( const String &S );
  void __fastcall LoadFromFiler( TNNFTextStream *Filer );
  void __fastcall SaveToFiler( TNNFTextStream *Filer );
};

PACKAGE enum TNDSKind
{ nkWO_NDS    = 0
, nkWITH_NDS  = 1
, nkONLY_NDS  = 2
};

PACKAGE enum TSkilfulBool
{ sbYes = 0
, sbNo  = 1
, sbAny = 2
};

extern PACKAGE bool __fastcall FormExists( TMetaClass* InstanceClass, void *Reference );
extern PACKAGE bool __fastcall FormExists( TCommonCustomForm *fm );
extern PACKAGE void __fastcall FormCreate( TMetaClass* InstanceClass, void *Reference );
extern PACKAGE bool __fastcall DMExists( TMetaClass* InstanceClass, void *Reference );
extern PACKAGE bool __fastcall DMExists( TDataModule *fm );
extern PACKAGE void __fastcall DMCreate( TMetaClass* InstanceClass, void *Reference );
extern PACKAGE String __fastcall ComponentToKey( TComponent *AComponent
                                               , bool UseOwnerName );
extern PACKAGE String __fastcall UpdateStatusToStr( TUpdateStatus Value );
extern PACKAGE String __fastcall DataSetStateToStr( TDataSetState Value );
extern PACKAGE TDataModule* __fastcall StrToDataModule( const String AName );
extern PACKAGE TDataSet* __fastcall StrToDataSet( String &AText, TComponent *AOwner, bool RaiseExcept );
extern PACKAGE TRect __fastcall CalcRect( TRect ARect, TRect RC );
extern PACKAGE bool __fastcall IsLeapYear( int AYear );
extern PACKAGE TDateTime __fastcall PriorMonth( TDateTime D );
extern PACKAGE TDateTime __fastcall NextMonth( TDateTime D );
extern PACKAGE TDateTime __fastcall PriorYear( TDateTime D );
extern PACKAGE TDateTime __fastcall NextYear( TDateTime D );
// Precision :
//1�� - �� �����
//10� - �� �������
//100 - �� �����
//...
extern PACKAGE double __fastcall RoundEx( double X, int Precision );
extern PACKAGE double __fastcall AltRound( double X, int Precision );
extern PACKAGE TDateTime __fastcall TruncDate( const TDateTime &Value );
extern PACKAGE double __fastcall WizardNDS( double Summa_
                                          , bool IsNDS_
                                          , double Percent_
                                          , TNDSKind NeedNDS_
                                          , double PercentComok_ = 0
                                          , bool ForComok_ = false  );
extern PACKAGE void __fastcall FormShow( TCommonCustomForm *Form );
extern PACKAGE long double __fastcall Factorial( long double R );
extern PACKAGE void __fastcall OtherUserException();
extern PACKAGE void __fastcall SaveComboBox( TComboBox *cb, int Limit_ );
extern PACKAGE void __fastcall SetFieldValue( TField *Field, const Variant &Value );
extern PACKAGE bool __fastcall CompareVariant( const Variant &V1, const Variant &V2 );
extern PACKAGE bool __fastcall IsEditModes( TDataSetState State_ );
extern PACKAGE void __fastcall SetFieldField( TField *FSource, TField *FTarget );
extern PACKAGE String VariantToStr( const Variant &Value );
extern PACKAGE String CriptPassword( String Password );
extern PACKAGE TControl* __fastcall ControlAtPos( TControl *Win, TPoint p );
class PACKAGE TCurrentOwner : public TObject
{
public:
  __fastcall TCurrentOwner() : PK( -1 ), Level( 0 ) {};
  double PK;
  double Level;
};
PACKAGE enum TTriggerMode { AfterDelete, AfterUpdate, AfterInsert, AfterAnother };
class PACKAGE TPeriod : public TObject
{
public:
  __fastcall TPeriod() :
    IsAll( true )
  , IsExist( true )
  {};
  __fastcall TPeriod( TDateTime BeginDate_
                    , TDateTime EndDate_
                    , bool IsAll_
                    , bool IsExist_ );
  TDateTime BeginDate;
  TDateTime EndDate;
  bool IsAll;
  bool IsExist;
  bool operator!=( const TPeriod &p ) const
    {
      return
         BeginDate != p.BeginDate
      || EndDate   != p.EndDate
      || IsAll     != p.IsAll
      || IsExist   != p.IsExist;
    };
};
class PACKAGE TNumberDiapazon : public TObject
{
public:
  __fastcall TNumberDiapazon()
  : IsAll( false )
  , BeginNumber( 0 )
  , EndNumber( 0 )
  {};
  __fastcall TNumberDiapazon( double BeginNumber_
                            , double EndNumber_
                            , bool IsAll_ );
  double BeginNumber;
  double EndNumber;
  bool IsAll;
  bool operator!=( const TNumberDiapazon &p ) const
    {
      return
         BeginNumber != p.BeginNumber
      || EndNumber   != p.EndNumber
      || IsAll       != p.IsAll;
    };
};
extern PACKAGE int	pow2(int p);
typedef PACKAGE std::pair< String, String > TStringPair;
extern PACKAGE int __fastcall BoolToInt( bool Value );
//extern PACKAGE void __fastcall SetColumnStory( TColumn *cl
//                                             , const String &S
//                                             , TCustomComboEdit *cc = NULL );
extern void __fastcall SetComboStory( const String &S
                                    , TCustomComboEdit *cc );
extern PACKAGE double __fastcall ConvertPrice( double Price
                                             , double FromCurs
                                             , double FromCoef
                                             , double ToCurs
                                             , double ToCoef );
extern PACKAGE void __fastcall PreparePrabhupadaBukvary();

class PACKAGE TCursorMagic : public TObject
{
public:
  TCursor OldCursor;
  __fastcall TCursorMagic( TCursor NewCursor_ );
  __fastcall ~TCursorMagic();
};

extern PACKAGE TPrabhupadaBukvary PrabhupadaBukvary;

}
#endif

