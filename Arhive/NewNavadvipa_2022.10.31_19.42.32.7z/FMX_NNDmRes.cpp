﻿//---------------------------------------------------------------------------


#pragma hdrstop

#include "FMX_NNDmRes.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma classgroup "FMX.Controls.TControl"
#pragma link "FMX_NNConfig"
#pragma link "FMX_NNLanguageManager"
#pragma link "FMX_NNRightsManager"
#pragma resource "*.dfm"
TdmfRes *dmfRes;
//---------------------------------------------------------------------------
__fastcall TdmfRes::TdmfRes(TComponent* Owner)
  : TDataModule(Owner)
{
}
//---------------------------------------------------------------------------
