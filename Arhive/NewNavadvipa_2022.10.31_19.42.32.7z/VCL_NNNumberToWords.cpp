// ---------------------------------------------------------------------------

#include <vcl.h>

#pragma hdrstop

#include "VCL_NNNumberToWords.h"
#pragma resource "*.res"
#pragma package(smart_init)

const char* CW_DEFAULT_RUBL1 = "�����";
const char* CW_DEFAULT_RUBL24 = "�����";
const char* CW_DEFAULT_RUBL5 = "������";
const char* CW_DEFAULT_COPYICA1 = "�������";
const char* CW_DEFAULT_COPYICA24 = "�������";
const char* CW_DEFAULT_COPYICA5 = "������";

// ---------------------------------------------------------------------------
// ValidCtrCheck is used to assure that the components created do not have
// any pure virtual functions.
//

static inline void ValidCtrCheck(TNNVNumberToWords *) {
  new TNNVNumberToWords(NULL);
}

// ---------------------------------------------------------------------------
__fastcall TNNVNumberToWords::TNNVNumberToWords(TComponent* Owner)
    : inherited(Owner) {
  fRubl1 = CW_DEFAULT_RUBL1;
  fRubl24 = CW_DEFAULT_RUBL24;
  fRubl5 = CW_DEFAULT_RUBL5;
  fCopyica1 = CW_DEFAULT_COPYICA1;
  fCopyica24 = CW_DEFAULT_COPYICA24;
  fCopyica5 = CW_DEFAULT_COPYICA5;
  fRublGender = NNV::wgMale;
  fCopyicaGender = NNV::wgFemale;
  fLenCopyica = 2;
  fNeedCopyica = True;
  fCopyicaKind = ckNumber;
}

bool __fastcall TNNVNumberToWords::IsDRubl1() {
  return Rubl1 != CW_DEFAULT_RUBL1;
}

bool __fastcall TNNVNumberToWords::IsDRubl24() {
  return Rubl24 != CW_DEFAULT_RUBL24;
}

bool __fastcall TNNVNumberToWords::IsDRubl5() {
  return Rubl5 != CW_DEFAULT_RUBL5;
}

bool __fastcall TNNVNumberToWords::IsDCopyica1() {
  return Copyica1 != CW_DEFAULT_COPYICA1;
}

bool __fastcall TNNVNumberToWords::IsDCopyica24() {
  return Copyica24 != CW_DEFAULT_COPYICA24;
}

bool __fastcall TNNVNumberToWords::IsDCopyica5() {
  return Copyica5 != CW_DEFAULT_COPYICA5;
}

void __fastcall TNNVNumberToWords::SetValue(String Value) {
  if (Value != fValue) {
    fValue = NNV::RemoveChar(Value, FormatSettings.ThousandSeparator);
    fValue = NNV::RoundString(fValue, LenCopyica);
    GenText();
  }
}

void __fastcall TNNVNumberToWords::GenText() {
  int N;
  String SN, S;
  bool B;
  NNV::TNumWordDiapazon D;
  String T[3];
  SN = Value;
  N = 1;
  T[0] = Rubl1;
  T[1] = Rubl24;
  T[2] = Rubl5;
  fText = NNV::SToStr(NNV::GetToken(SN, N, FormatSettings.DecimalSeparator),
      RublGender, T, true);
  if ((NeedCopyica) || (N < SN.Length() + 1)) {
    S = NNV::GetToken(SN, N, FormatSettings.DecimalSeparator);
    S = S + String::StringOfChar('0', LenCopyica - S.Length());
    T[0] = Copyica1;
    T[1] = Copyica24;
    T[2] = Copyica5;
    switch (CopyicaKind) {
    case ckWord:
      fText = fText + ' ' + NNV::SToStr(S, CopyicaGender, T, false);
      break;
    default:
      N = S.Length();
      if (N > 1)
        B = (S[N - 1] == '1');
      else
        B = false;
      D = NNV::NumDiapazon(S[N], B);
      fText = fText + ' ' + S;
      switch (D) {
      case NNV::wdOne:
        S = Copyica1;
        break;
      case NNV::wdTwoFourth:
        S = Copyica24;
        break;
      default:
        S = Copyica5;
      }
      fText = fText + ' ' + S;
    }
  }
  Change();
}

void __fastcall TNNVNumberToWords::SetRubl1(String value) {
  if (Rubl1 != value) {
    fRubl1 = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetRubl24(String value) {
  if (Rubl24 != value) {
    fRubl24 = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetRubl5(String value) {
  if (Rubl5 != value) {
    fRubl5 = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetCopyica1(String value) {
  if (Copyica1 != value) {
    fCopyica1 = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetCopyica24(String value) {
  if (Copyica24 != value) {
    fCopyica24 = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetCopyica5(String value) {
  if (Copyica5 != value) {
    fCopyica5 = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetRublGender(NNV::TGender value) {
  if (RublGender != value) {
    fRublGender = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetCopyicaGender(NNV::TGender value) {
  if (CopyicaGender != value) {
    fCopyicaGender = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetLenCopyica(int value) {
  if (LenCopyica != value) {
    fLenCopyica = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetNeedCopyica(bool value) {
  if (NeedCopyica != value) {
    fNeedCopyica = value;
    RefreshText();
  }
}

void __fastcall TNNVNumberToWords::SetCopyicaKind(TCopyicaKind value) {
  if (CopyicaKind != value) {
    fCopyicaKind = value;
    RefreshText();
  }
}

// ---------------------------------------------------------------------------
namespace Vcl_nnnumbertowords {
  void __fastcall PACKAGE Register() {
    TComponentClass classes[1] = {__classid(TNNVNumberToWords)};
    RegisterComponents(L"VCL New Navadvipa", classes, 0);
  }
}
// ---------------------------------------------------------------------------
