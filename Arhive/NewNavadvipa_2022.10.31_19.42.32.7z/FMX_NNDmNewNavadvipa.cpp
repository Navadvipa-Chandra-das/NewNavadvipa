﻿//---------------------------------------------------------------------------


#pragma hdrstop

#include "FMX_NNDmNewNavadvipa.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma classgroup "FMX.Controls.TControl"
#pragma link "FMX_NNDmRes"
#pragma link "FMX_NNConfig"
#pragma link "FMX_NNLanguageManager"
#pragma link "FMX_NNRightsManager"
#pragma resource "*.dfm"
TdmfNewNavadvipa *dmfNewNavadvipa;
//---------------------------------------------------------------------------
__fastcall TdmfNewNavadvipa::TdmfNewNavadvipa( TComponent* Owner )
  : inherited( Owner )
{
}
//---------------------------------------------------------------------------
