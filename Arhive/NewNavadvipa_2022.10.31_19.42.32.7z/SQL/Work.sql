&PRABHUPADA_SCHEMA.
"NavadvipaSchema"
qu->PrepareStandartMacro();

-- PROCEDURE: public.InsertLanguageRow(bigint, character varying, character varying)

-- DROP PROCEDURE IF EXISTS public."InsertLanguageRow"(bigint, character varying, character varying);

CREATE OR REPLACE PROCEDURE public."InsertLanguageRow"(
	IN "AKindID" bigint,
	IN "ALanguage" character varying,
	IN "ATranslate" character varying)
LANGUAGE 'plpgsql'
AS $BODY$
declare
  pr record;
  "AEntityID" bigint;
  "AOldOriginal" character varying;
  "AOriginalChanged" Boolean := False;
  "ATranslateID" bigint;
  "AOldTranslate" character varying;

  rk cursor for
  select
    a."EntityID"
  , a."Original"
  from
    "Language" a
  where
      a."KindID" = "AKindID"
  and a."Entity" = "ALanguage";

  dk cursor ( "ALanguagesID" bigint ) for
  select
    a."TranslateID"
  , a."Translate"
  from
    "Translate" a
  where
      a."LanguageID" = "AEntityID"
  and a."LanguagesID" = "ALanguagesID";
begin
  open rk;
  fetch rk into "AEntityID", "AOldOriginal";
  close rk;
  if ( found ) then
    "AOriginalChanged" := "AOldOriginal" <> "ATranslate";
  else
    insert into "Language" (
      "KindID"
    , "Entity"
    , "Original"
    ) values (
      "AKindID"
    , "ALanguage"
    , "ATranslate"
    ) returning "EntityID" into "AEntityID";
  end if;

  if ( "AOriginalChanged" ) then
    update "Language" set "Original" = "ATranslate" where "EntityID" = "AEntityID";
  end if;

  for pr in ( select
                a."LanguagesID"
              from
                "Languages" a
              where
                  a."LanguagesID" > 1
              order by a."Languages" ) loop
    open dk( pr."LanguagesID" );
    fetch dk into "ATranslateID", "AOldTranslate";
    close dk;
    if ( found ) then
      if ( "AOriginalChanged" and "AOldTranslate" = "AOldOriginal") then
        update "Translate" set "Translate" = "ATranslate" where "TranslateID" = "ATranslateID";
      end if;
    else
      insert into "Translate" (
        "LanguageID"
      , "LanguagesID"
      , "Translate"
      ) values (
        "AEntityID"
      , pr."LanguagesID"
      , "ATranslate"
      );
    end if;
  end loop;
end;
$BODY$;
ALTER PROCEDURE public."InsertLanguageRow"(bigint, character varying, character varying)
    OWNER TO "Navadvipa Chandra das";

