--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."UserRoles" DROP CONSTRAINT IF EXISTS "UserRolesUsersFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."UserRoles" DROP CONSTRAINT IF EXISTS "UserRolesRoleFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."UserRights" DROP CONSTRAINT IF EXISTS "UserRightsUsersFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."UserRights" DROP CONSTRAINT IF EXISTS "UserRightsRightsFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."RoleRights" DROP CONSTRAINT IF EXISTS "RoleRightsRoleFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."RoleRights" DROP CONSTRAINT IF EXISTS "RoleRightsRightsFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."RoleKind" DROP CONSTRAINT IF EXISTS "RoleKindParentFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Role" DROP CONSTRAINT IF EXISTS "RoleKindFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."RightsKind" DROP CONSTRAINT IF EXISTS "RightsKindParentFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Rights" DROP CONSTRAINT IF EXISTS "RightsKindFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Translate" DROP CONSTRAINT IF EXISTS "LanguagesFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."LanguageKind" DROP CONSTRAINT IF EXISTS "LanguageKindParentFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Language" DROP CONSTRAINT IF EXISTS "LanguageKindFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Translate" DROP CONSTRAINT IF EXISTS "LanguageFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Kind" DROP CONSTRAINT IF EXISTS "KindParent_fk";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Entity" DROP CONSTRAINT IF EXISTS "KindFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."CommodKind" DROP CONSTRAINT IF EXISTS "CommodKindParentFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Commod" DROP CONSTRAINT IF EXISTS "CommodKindFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."ColorKind" DROP CONSTRAINT IF EXISTS "ColorKindParentFK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Users" DROP CONSTRAINT IF EXISTS "Users_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."UserRoles" DROP CONSTRAINT IF EXISTS "UserRoles_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."UserRights" DROP CONSTRAINT IF EXISTS "UserRights_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."UserReg" DROP CONSTRAINT IF EXISTS "UserReg_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Translate" DROP CONSTRAINT IF EXISTS "Translate_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Role" DROP CONSTRAINT IF EXISTS "Role_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."RoleRights" DROP CONSTRAINT IF EXISTS "RoleRights_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."RoleKind" DROP CONSTRAINT IF EXISTS "RoleKind_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Rights" DROP CONSTRAINT IF EXISTS "Rights_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."RightsKind" DROP CONSTRAINT IF EXISTS "RightsKind_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Kind" DROP CONSTRAINT IF EXISTS "ParentKind";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Languages" DROP CONSTRAINT IF EXISTS "Languages_pkey";
ALTER TABLE IF EXISTS "NewNavadvipa"."Translate" DROP CONSTRAINT IF EXISTS "LanguagesCK";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Language" DROP CONSTRAINT IF EXISTS "Language_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."LanguageKind" DROP CONSTRAINT IF EXISTS "LanguageKind_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Language" DROP CONSTRAINT IF EXISTS "LanguageKindID_Entity_UN";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Kind" DROP CONSTRAINT IF EXISTS "Kind_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Color" DROP CONSTRAINT IF EXISTS "EnumLiteralUN";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Entity" DROP CONSTRAINT IF EXISTS "Entity_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Commod" DROP CONSTRAINT IF EXISTS "Commod_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."CommodKind" DROP CONSTRAINT IF EXISTS "CommodKind_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."Color" DROP CONSTRAINT IF EXISTS "Color_pkey";
ALTER TABLE IF EXISTS ONLY "NewNavadvipa"."ColorKind" DROP CONSTRAINT IF EXISTS "ColorKind_pkey";
ALTER TABLE IF EXISTS "NewNavadvipa"."Translate" ALTER COLUMN "TranslateID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."RoleKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."RoleKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Role" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Role" ALTER COLUMN "EntityID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."RightsKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."RightsKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Rights" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Rights" ALTER COLUMN "EntityID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Languages" ALTER COLUMN "LanguagesID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."LanguageKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."LanguageKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Language" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Language" ALTER COLUMN "EntityID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."CommodKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."CommodKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Commod" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Commod" ALTER COLUMN "EntityID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."ColorKind" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."ColorKind" ALTER COLUMN "KindID" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Color" ALTER COLUMN "Actual" DROP DEFAULT;
ALTER TABLE IF EXISTS "NewNavadvipa"."Color" ALTER COLUMN "EntityID" DROP DEFAULT;
DROP TABLE IF EXISTS "NewNavadvipa"."Users";
DROP SEQUENCE IF EXISTS "NewNavadvipa"."Users_UserID_seq";
DROP TABLE IF EXISTS "NewNavadvipa"."UserRoles";
DROP SEQUENCE IF EXISTS "NewNavadvipa"."UserRoles_UserRolesID_seq";
DROP TABLE IF EXISTS "NewNavadvipa"."UserRights";
DROP SEQUENCE IF EXISTS "NewNavadvipa"."UserRights_UserRightsID_seq";
DROP TABLE IF EXISTS "NewNavadvipa"."UserReg";
DROP SEQUENCE IF EXISTS "NewNavadvipa"."Translate_TranslateID_seq";
DROP TABLE IF EXISTS "NewNavadvipa"."Translate";
DROP TABLE IF EXISTS "NewNavadvipa"."RoleRights";
DROP SEQUENCE IF EXISTS "NewNavadvipa"."RoleRights_RoleRightsID_seq";
DROP TABLE IF EXISTS "NewNavadvipa"."RoleKind";
DROP TABLE IF EXISTS "NewNavadvipa"."Role";
DROP TABLE IF EXISTS "NewNavadvipa"."RightsKind";
DROP TABLE IF EXISTS "NewNavadvipa"."Rights";
DROP SEQUENCE IF EXISTS "NewNavadvipa"."Languages_LanguagesID_seq";
DROP TABLE IF EXISTS "NewNavadvipa"."Languages";
DROP TABLE IF EXISTS "NewNavadvipa"."LanguageKind";
DROP TABLE IF EXISTS "NewNavadvipa"."Language";
DROP TABLE IF EXISTS "NewNavadvipa"."CommodKind";
DROP TABLE IF EXISTS "NewNavadvipa"."Commod";
DROP TABLE IF EXISTS "NewNavadvipa"."ColorKind";
DROP TABLE IF EXISTS "NewNavadvipa"."Kind";
DROP SEQUENCE IF EXISTS "NewNavadvipa"."Kind_KindID_seq";
DROP TABLE IF EXISTS "NewNavadvipa"."Color";
DROP TABLE IF EXISTS "NewNavadvipa"."Entity";
DROP SEQUENCE IF EXISTS "NewNavadvipa"."Entity_EntityID_seq";
DROP PROCEDURE IF EXISTS "NewNavadvipa"."SetUserRole"(IN "AUser" character varying, IN "ARole" character varying, IN "IsGrant" boolean);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."SetNewUserPassword"(IN "AUser" character varying, IN "APassword" character varying);
DROP FUNCTION IF EXISTS "NewNavadvipa"."RoleKindDelete"();
DROP FUNCTION IF EXISTS "NewNavadvipa"."RoleIDToName"("ARoleID" bigint);
DROP FUNCTION IF EXISTS "NewNavadvipa"."RoleIDToKindID"("ARoleID" bigint);
DROP FUNCTION IF EXISTS "NewNavadvipa"."RoleDelete"();
DROP FUNCTION IF EXISTS "NewNavadvipa"."RightsKindDelete"();
DROP PROCEDURE IF EXISTS "NewNavadvipa"."RightsIndexGenerate"();
DROP FUNCTION IF EXISTS "NewNavadvipa"."RightsDelete"();
DROP FUNCTION IF EXISTS "NewNavadvipa"."RightIndexToName"("ARightIndex" bigint);
DROP FUNCTION IF EXISTS "NewNavadvipa"."RightIDToName"("ARightID" bigint);
DROP FUNCTION IF EXISTS "NewNavadvipa"."RightIDToKindID"("ARightID" bigint);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."ResetConfig"(IN "AUser" character varying);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."PasteUserRoles"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."PasteUserRights"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."PasteTranslate"(IN "ANewLanguageID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."PasteRoleRights"(IN "ANewRoleID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."PasteEntity"(IN "ANewKindID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."LoadRightsUser"(IN "AUserID" bigint);
DROP FUNCTION IF EXISTS "NewNavadvipa"."LanguagesIDToName"("ALanguagesID" bigint);
DROP FUNCTION IF EXISTS "NewNavadvipa"."IsRight"("ARightIndex" bigint, "ANeedException" boolean);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."InsertLanguageRow"(IN "AKindID" bigint, IN "ALanguage" character varying, IN "ATranslate" character varying);
DROP FUNCTION IF EXISTS "NewNavadvipa"."GetUserID"("AName" character varying);
DROP FUNCTION IF EXISTS "NewNavadvipa"."GetUserID"();
DROP FUNCTION IF EXISTS "NewNavadvipa"."EntityIDToKindID"("AEntityID" bigint);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."DeleteUser"(IN "AUser" character varying);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."CreateUser"(IN "AUser" character varying, IN "APassword" character varying, IN "ARole" character varying, IN "IsSuperUser" boolean);
DROP PROCEDURE IF EXISTS "NewNavadvipa"."CreateRightsUser"();
DROP FUNCTION IF EXISTS "NewNavadvipa"."CommodKindDelete"();
DROP FUNCTION IF EXISTS "NewNavadvipa"."ColorKindDelete"();
DROP PROCEDURE IF EXISTS "NewNavadvipa"."ColorIndexGenerate"();
DROP PROCEDURE IF EXISTS "NewNavadvipa"."AfterLogon"(IN "AUserID" bigint);
DROP TYPE IF EXISTS "NewNavadvipa"."TBufferIntBox";
DROP TYPE IF EXISTS "NewNavadvipa"."TAnketa";
DROP SCHEMA IF EXISTS "NewNavadvipa";
--
-- Name: NewNavadvipa; Type: SCHEMA; Schema: -; Owner: Navadvipa Chandra das
--

CREATE SCHEMA "NewNavadvipa";


ALTER SCHEMA "NewNavadvipa" OWNER TO "Navadvipa Chandra das";

--
-- Name: SCHEMA "NewNavadvipa"; Type: COMMENT; Schema: -; Owner: Navadvipa Chandra das
--

COMMENT ON SCHEMA "NewNavadvipa" IS 'Схема Новой Навадвипы!';


--
-- Name: TAnketa; Type: TYPE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TYPE "NewNavadvipa"."TAnketa" AS (
	"FIO" character varying(100),
	"INN" character varying(12),
	"Passport" character varying(12),
	"PassportKemVydan" character varying(50),
	"PassportDate" date
);


ALTER TYPE "NewNavadvipa"."TAnketa" OWNER TO "Navadvipa Chandra das";

--
-- Name: TYPE "TAnketa"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TYPE "NewNavadvipa"."TAnketa" IS 'Анкетные данные пользователей';


--
-- Name: TBufferIntBox; Type: TYPE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TYPE "NewNavadvipa"."TBufferIntBox" AS (
	"IsCut" boolean,
	"Label" character varying(50),
	"VectorID" bigint[]
);


ALTER TYPE "NewNavadvipa"."TBufferIntBox" OWNER TO "Navadvipa Chandra das";

--
-- Name: TYPE "TBufferIntBox"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TYPE "NewNavadvipa"."TBufferIntBox" IS 'Тип, для работы с буфером обмена!';


--
-- Name: AfterLogon(bigint); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."AfterLogon"(IN "AUserID" bigint)
    LANGUAGE plpgsql
    AS $$begin
  call "NewNavadvipa"."CreateRightsUser"();
  call "NewNavadvipa"."LoadRightsUser"( "AUserID" );
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."AfterLogon"(IN "AUserID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: PROCEDURE "AfterLogon"(IN "AUserID" bigint); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON PROCEDURE "NewNavadvipa"."AfterLogon"(IN "AUserID" bigint) IS 'Выполняется сразу после входа в базу данных NewNavadvipa';


--
-- Name: ColorIndexGenerate(); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."ColorIndexGenerate"()
    LANGUAGE plpgsql
    AS $$
declare
  I bigint := 0;
  pr record;
begin
  for pr in ( select
                a."EntityID"
              , a."KindID"
              , a."Entity"
              from
                "NewNavadvipa"."Color" a
              order by a."KindID", a."Entity" ) loop
    update "NewNavadvipa"."Color"
    set
      "VectorIndex" = I
    where
      "EntityID" = pr."EntityID";
    I := I + 1;
  end loop;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."ColorIndexGenerate"() OWNER TO "Navadvipa Chandra das";

--
-- Name: PROCEDURE "ColorIndexGenerate"(); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON PROCEDURE "NewNavadvipa"."ColorIndexGenerate"() IS 'Создание индексов для цветов, начиная от нуля и прибавляя единичку для всех записей таблицы "Color"!';


--
-- Name: ColorKindDelete(); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."ColorKindDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from "NewNavadvipa"."Color" where "KindID" = OLD."KindID";
  return NULL;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."ColorKindDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: CommodKindDelete(); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."CommodKindDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from "NewNavadvipa"."Commod" where "KindID" = OLD."KindID";
  return NULL;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."CommodKindDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: CreateRightsUser(); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."CreateRightsUser"()
    LANGUAGE plpgsql
    AS $$
declare
  "Command" varchar;
begin
  "Command" := 'CREATE TEMP TABLE IF NOT EXISTS "RightsUser"(
    "RightIndex" bigint NOT NULL,
    "Value" Boolean NOT NULL )
     ON COMMIT PRESERVE ROWS TABLESPACE pg_default;';

  EXECUTE "Command";
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."CreateRightsUser"() OWNER TO "Navadvipa Chandra das";

--
-- Name: CreateUser(character varying, character varying, character varying, boolean); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."CreateUser"(IN "AUser" character varying, IN "APassword" character varying, IN "ARole" character varying, IN "IsSuperUser" boolean)
    LANGUAGE plpgsql
    AS $$

declare
  "Command" character varying;
  SU character varying(12);
begin
  if "IsSuperUser" then
    SU := 'SUPERUSER ';
  else
    SU := 'NOSUPERUSER ';
  end if;
  "Command" := 'CREATE ROLE ' || '"' || "AUser" || '"' || ' WITH ' || SU ||
  ' LOGIN 
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION ' ||
   'IN ROLE "' || "ARole" || '"' ||
  ' PASSWORD ' || '''' || "APassword" || '''';
  
  EXECUTE "Command";
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."CreateUser"(IN "AUser" character varying, IN "APassword" character varying, IN "ARole" character varying, IN "IsSuperUser" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: DeleteUser(character varying); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."DeleteUser"(IN "AUser" character varying)
    LANGUAGE plpgsql
    AS $$
declare
  "DeleteUserCommand" varchar;
begin
  "DeleteUserCommand" := 'DROP ROLE ' || '"' || "AUser" || '"';
  
  EXECUTE "DeleteUserCommand";
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."DeleteUser"(IN "AUser" character varying) OWNER TO "Navadvipa Chandra das";

--
-- Name: EntityIDToKindID(bigint); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."EntityIDToKindID"("AEntityID" bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor for
  select a."KindID" from "NewNavadvipa"."Entity" a where a."EntityID" = "AEntityID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."EntityIDToKindID"("AEntityID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "EntityIDToKindID"("AEntityID" bigint); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION "NewNavadvipa"."EntityIDToKindID"("AEntityID" bigint) IS 'Разыменование идентификатора Entity (сущности) в идентификатор её типа (KindID)!';


--
-- Name: GetUserID(); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."GetUserID"() RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor( "AName" character varying ) for
  select a."UserID" from "NewNavadvipa"."Users" a where a."Name" = "AName";
  "СurrentUser" character varying(32);
begin
  select current_user into "СurrentUser";
  open rk( "CurrentUser" );
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."GetUserID"() OWNER TO "Navadvipa Chandra das";

--
-- Name: GetUserID(character varying); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."GetUserID"("AName" character varying) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor( "AName" character varying ) for
  select a."UserID" from "NewNavadvipa"."Users" a where a."Name" = "AName";
begin
  open rk( "AName" );
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."GetUserID"("AName" character varying) OWNER TO "Navadvipa Chandra das";

--
-- Name: InsertLanguageRow(bigint, character varying, character varying); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."InsertLanguageRow"(IN "AKindID" bigint, IN "ALanguage" character varying, IN "ATranslate" character varying)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
  "AEntityID" bigint;
  "AOldOriginal" character varying;
  "AOriginalChanged" Boolean := False;
  "ATranslateID" bigint;
  "AOldTranslate" character varying;

  rk cursor for
  select
    a."EntityID"
  , a."Original"
  from
    "NewNavadvipa"."Language" a
  where
      a."KindID" = "AKindID"
  and a."Entity" = "ALanguage";

  dk cursor ( "ALanguagesID" bigint ) for
  select
    a."TranslateID"
  , a."Translate"
  from
    "NewNavadvipa"."Translate" a
  where
      a."LanguageID" = "AEntityID"
  and a."LanguagesID" = "ALanguagesID";
begin
  open rk;
  fetch rk into "AEntityID", "AOldOriginal";
  close rk;
  if ( found ) then
    "AOriginalChanged" := "AOldOriginal" <> "ATranslate";
  else
    insert into "NewNavadvipa"."Language" (
      "KindID"
    , "Entity"
    , "Original"
    ) values (
      "AKindID"
    , "ALanguage"
    , "ATranslate"
    ) returning "EntityID" into "AEntityID";
  end if;

  if ( "AOriginalChanged" ) then
    update "NewNavadvipa"."Language" set "Original" = "ATranslate" where "EntityID" = "AEntityID";
  end if;

  for pr in ( select
                a."LanguagesID"
              from
                "NewNavadvipa"."Languages" a
              where
                  a."LanguagesID" > 1
              order by a."Languages" ) loop
    open dk( pr."LanguagesID" );
    fetch dk into "ATranslateID", "AOldTranslate";
    close dk;
    if ( found ) then
      if ( "AOriginalChanged" and "AOldTranslate" = "AOldOriginal") then
        update "NewNavadvipa"."Translate" set "Translate" = "ATranslate" where "TranslateID" = "ATranslateID";
      end if;
    else
      insert into "NewNavadvipa"."Translate" (
        "LanguageID"
      , "LanguagesID"
      , "Translate"
      ) values (
        "AEntityID"
      , pr."LanguagesID"
      , "ATranslate"
      );
    end if;
  end loop;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."InsertLanguageRow"(IN "AKindID" bigint, IN "ALanguage" character varying, IN "ATranslate" character varying) OWNER TO "Navadvipa Chandra das";

--
-- Name: IsRight(bigint, boolean); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."IsRight"("ARightIndex" bigint, "ANeedException" boolean DEFAULT false) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
  R Boolean;
  S character varying( 200 );
  rk cursor for
  select a."Value" from "RightsUser" a where a."RightIndex" = "ARightIndex";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := false;
  end if;
  close rk;

  S := "RightIndexToName"( "ARightIndex" );
  if ( not R and "ANeedException" ) then
    raise exception 'Извините, пожалуйста, но у вас нет права % ', S;
  end if;

  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."IsRight"("ARightIndex" bigint, "ANeedException" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "IsRight"("ARightIndex" bigint, "ANeedException" boolean); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION "NewNavadvipa"."IsRight"("ARightIndex" bigint, "ANeedException" boolean) IS 'Есть ли право?';


--
-- Name: LanguagesIDToName(bigint); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."LanguagesIDToName"("ALanguagesID" bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
  R character varying(32);
  rk cursor for
  select a."Languages" from "NewNavadvipa"."Languages" a where a."LanguagesID" = "ALanguagesID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 'Error ' || "ALanguagesID";
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."LanguagesIDToName"("ALanguagesID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: LoadRightsUser(bigint); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."LoadRightsUser"(IN "AUserID" bigint)
    LANGUAGE plpgsql
    AS $$
declare
  I bigint;
  L bigint;
  RI bigint;
  pr record;
  dr record;
  rk cursor( "ARightID" bigint ) for select a."VectorIndex" from "NewNavadvipa"."Rights" a where a."EntityID" = "ARightID";
begin
  delete from "RightsUser";
  select max( a."VectorIndex" ) from "NewNavadvipa"."Rights" a into L;
  for I in 0 .. L loop
    insert into "RightsUser" ( "RightIndex", "Value" ) values ( I, false );
  end loop;

  for pr in ( select
                a."EntityID" as "RoleID"
              from
                "NewNavadvipa"."UserRoles" a
              where
                  a."UserID" = "AUserID" ) loop
    for dr in ( select
                  a."EntityID" as "RightID"
                from
                  "NewNavadvipa"."RoleRights" a
                where
                    a."RoleID" = pr."RoleID" ) loop
      open rk( dr."RightID" );
      fetch rk into RI;
      if ( not found ) then
        raise exception 'Не найдено право RightID == % !', dr."RightID";
      end if;
      close rk;

      update "RightsUser" set "Value" = true where "RightIndex" = RI;
    end loop;
  end loop;

  for pr in ( select
                a."EntityID" as "RightID"
              , a."IsPlus"
              from
                "NewNavadvipa"."UserRights" a
              where
                  a."UserID" = "AUserID" ) loop
    open rk( pr."RightID" );
    fetch rk into RI;
    if ( not found ) then
      raise exception 'Не найдено право RightID == % !', dr."RightID";
    end if;
    close rk;

    update "RightsUser" set "Value" = pr."IsPlus" where "RightIndex" = RI;
  end loop;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."LoadRightsUser"(IN "AUserID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: PROCEDURE "LoadRightsUser"(IN "AUserID" bigint); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON PROCEDURE "NewNavadvipa"."LoadRightsUser"(IN "AUserID" bigint) IS 'Заполнение правами пользователя такблицы "RightsUser"!';


--
-- Name: PasteEntity(bigint, bigint, boolean); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."PasteEntity"(IN "ANewKindID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  --for i in 1 .. "AVectorID".COUNT loop
    update "NewNavadvipa"."Entity" set "KindID" = "ANewKindID"
    where "EntityID" = "AVectorID";
  --end loop;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."PasteEntity"(IN "ANewKindID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: PasteRoleRights(bigint, bigint, boolean); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."PasteRoleRights"(IN "ANewRoleID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  if ( "IsCut" ) then
  --for i in 1 .. "AVectorID".COUNT loop
    update "NewNavadvipa"."RoleRights" set "RoleID" = "ANewRoleID"
    where "RoleRightsID" = "AVectorID";
  --end loop;
  else
    for pr in ( select
                  a."EntityID"
                from
                  "NewNavadvipa"."RoleRights" a
                where "RoleRightsID" = "AVectorID" ) loop
      insert into "NewNavadvipa"."RoleRights" ( "RoleID", "EntityID" ) values ( "ANewRoleID", pr."EntityID" );
    end loop;
  end if;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."PasteRoleRights"(IN "ANewRoleID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: PasteTranslate(bigint, bigint, boolean); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."PasteTranslate"(IN "ANewLanguageID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  if ( "IsCut" ) then
  --for i in 1 .. "AVectorID".COUNT loop
    update "NewNavadvipa"."Translate" set "LanguageID" = "ANewLanguageID"
    where "TranslateID" = "AVectorID";
  --end loop;
  else
    for pr in ( select
		  a."LanguagesID"
                , a."Translate"
                from
                  "NewNavadvipa"."Translate" a
                where a."TranslateID" = "AVectorID" ) loop
      insert into "NewNavadvipa"."Translate" (
    	      "LanguageID"
	    , "LanguagesID"
	    , "Translate"
      ) values (
          "ANewLanguageID"
        , pr."LanguagesID"
        , pr."Translate"
      );
    end loop;
  end if;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."PasteTranslate"(IN "ANewLanguageID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: PasteUserRights(bigint, bigint, boolean); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."PasteUserRights"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  if ( "IsCut" ) then
  --for i in 1 .. "AVectorID".COUNT loop
    update "NewNavadvipa"."UserRights" set "UserID" = "ANewUserID"
    where "UserRightsID" = "AVectorID";
  --end loop;
  else
    for pr in ( select
                  a."EntityID"
                , a."IsPlus"
                from
                  "NewNavadvipa"."UserRights" a
                where "UserRightsID" = "AVectorID" ) loop
      insert into "NewNavadvipa"."UserRights" ( "UserID", "EntityID", "IsPlus" ) values ( "ANewUserID", pr."EntityID", pr."IsPlus" );
    end loop;
  end if;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."PasteUserRights"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: PasteUserRoles(bigint, bigint, boolean); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."PasteUserRoles"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  pr record;
begin
  if ( "IsCut" ) then
  --for i in 1 .. "AVectorID".COUNT loop
    update "NewNavadvipa"."UserRoles" set "UserID" = "ANewUserID"
    where "UserRolesID" = "AVectorID";
  --end loop;
  else
    for pr in ( select
                  a."EntityID"
                from
                  "NewNavadvipa"."UserRoles" a
                where "UserRolesID" = "AVectorID" ) loop
      insert into "NewNavadvipa"."UserRoles" ( "UserID", "EntityID" ) values ( "ANewUserID", pr."EntityID" );
    end loop;
  end if;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."PasteUserRoles"(IN "ANewUserID" bigint, IN "AVectorID" bigint, IN "IsCut" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: ResetConfig(character varying); Type: PROCEDURE; Schema: NewNavadvipa; Owner: postgres
--

CREATE PROCEDURE "NewNavadvipa"."ResetConfig"(IN "AUser" character varying)
    LANGUAGE plpgsql
    AS $$begin
  delete from "NewNavadvipa"."UserReg" a where a."UserRegKey" like "AUser" || '-%';
end;$$;


ALTER PROCEDURE "NewNavadvipa"."ResetConfig"(IN "AUser" character varying) OWNER TO postgres;

--
-- Name: PROCEDURE "ResetConfig"(IN "AUser" character varying); Type: COMMENT; Schema: NewNavadvipa; Owner: postgres
--

COMMENT ON PROCEDURE "NewNavadvipa"."ResetConfig"(IN "AUser" character varying) IS 'Сброс настроек пользователя';


--
-- Name: RightIDToKindID(bigint); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RightIDToKindID"("ARightID" bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor for
  select a."KindID" from "NewNavadvipa"."Rights" a where a."EntityID" = "ARightID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."RightIDToKindID"("ARightID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RightIDToKindID"("ARightID" bigint); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION "NewNavadvipa"."RightIDToKindID"("ARightID" bigint) IS 'Получение из идентификатора права идентификатор его вида ("KindID")!';


--
-- Name: RightIDToName(bigint); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RightIDToName"("ARightID" bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
  R character varying(200);
  rk cursor for
  select a."Entity" from "NewNavadvipa"."Rights" a where a."EntityID" = "ARightID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 'Error ' || "ARightID";
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."RightIDToName"("ARightID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RightIDToName"("ARightID" bigint); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION "NewNavadvipa"."RightIDToName"("ARightID" bigint) IS 'Разыменовать идентификатор права в его имя!';


--
-- Name: RightIndexToName(bigint); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RightIndexToName"("ARightIndex" bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
  R character varying(200);
  rk cursor for
  select a."Entity" from "NewNavadvipa"."Rights" a where a."VectorIndex" = "ARightIndex";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 'Error "RightIndex" == ' || "ARightIndex";
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."RightIndexToName"("ARightIndex" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RightIndexToName"("ARightIndex" bigint); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION "NewNavadvipa"."RightIndexToName"("ARightIndex" bigint) IS 'Разыменовать индекс права в его имя!';


--
-- Name: RightsDelete(); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RightsDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$begin
  delete from "NewNavadvipa"."RoleRights" where "EntityID" = OLD."EntityID";
  return NULL;
end;$$;


ALTER FUNCTION "NewNavadvipa"."RightsDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: RightsIndexGenerate(); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."RightsIndexGenerate"()
    LANGUAGE plpgsql
    AS $$
declare
  I bigint := 0;
  pr record;
begin
  for pr in ( select
                a."EntityID"
              , a."KindID"
              , a."Entity"
              from
                "NewNavadvipa"."Rights" a
              order by a."KindID", a."Entity" ) loop

    update "NewNavadvipa"."Rights" set "VectorIndex" = I where "EntityID" = pr."EntityID";

    I := I + 1;
  end loop;
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."RightsIndexGenerate"() OWNER TO "Navadvipa Chandra das";

--
-- Name: PROCEDURE "RightsIndexGenerate"(); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON PROCEDURE "NewNavadvipa"."RightsIndexGenerate"() IS 'Создание индексов для прав, начиная от нуля и прибавляя единичку для всех записей таблицы "Rights"!';


--
-- Name: RightsKindDelete(); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RightsKindDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from "NewNavadvipa"."Rights" where "KindID" = OLD."KindID";
  return NULL;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."RightsKindDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: RoleDelete(); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RoleDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$begin
  delete from "NewNavadvipa"."RoleRights" where "RoleID" = OLD."EntityID";
  return NULL;
end;$$;


ALTER FUNCTION "NewNavadvipa"."RoleDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RoleDelete"(); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION "NewNavadvipa"."RoleDelete"() IS 'Удаление роли';


--
-- Name: RoleIDToKindID(bigint); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RoleIDToKindID"("ARoleID" bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
  R bigint;
  rk cursor for
  select a."KindID" from "NewNavadvipa"."Role" a where a."EntityID" = "ARoleID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 0;
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."RoleIDToKindID"("ARoleID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RoleIDToKindID"("ARoleID" bigint); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION "NewNavadvipa"."RoleIDToKindID"("ARoleID" bigint) IS 'Получение из идентификатора роли идентификатор её вида ("KindID")!';


--
-- Name: RoleIDToName(bigint); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RoleIDToName"("ARoleID" bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
  R character varying(200);
  rk cursor for
  select a."Entity" from "NewNavadvipa"."Role" a where a."EntityID" = "ARoleID";
begin
  open rk;
  fetch rk into R;
  if ( not found ) then
    R := 'Error ' || "ARoleID";
  end if;
  close rk;
  return R;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."RoleIDToName"("ARoleID" bigint) OWNER TO "Navadvipa Chandra das";

--
-- Name: FUNCTION "RoleIDToName"("ARoleID" bigint); Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON FUNCTION "NewNavadvipa"."RoleIDToName"("ARoleID" bigint) IS 'Разыменовать идентификатор роли в её имя!';


--
-- Name: RoleKindDelete(); Type: FUNCTION; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE FUNCTION "NewNavadvipa"."RoleKindDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from "NewNavadvipa"."Role" where "KindID" = OLD."KindID";
  return NULL;
end;
$$;


ALTER FUNCTION "NewNavadvipa"."RoleKindDelete"() OWNER TO "Navadvipa Chandra das";

--
-- Name: SetNewUserPassword(character varying, character varying); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."SetNewUserPassword"(IN "AUser" character varying, IN "APassword" character varying)
    LANGUAGE plpgsql
    AS $$
declare
  "SetNewUserPasswordCommand" varchar;
begin
  "SetNewUserPasswordCommand" := 'ALTER ROLE ' || '"' || "AUser" || '"' ||
  'PASSWORD ' || '''' || "APassword" || '''';
  
  EXECUTE "SetNewUserPasswordCommand";
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."SetNewUserPassword"(IN "AUser" character varying, IN "APassword" character varying) OWNER TO "Navadvipa Chandra das";

--
-- Name: SetUserRole(character varying, character varying, boolean); Type: PROCEDURE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE PROCEDURE "NewNavadvipa"."SetUserRole"(IN "AUser" character varying, IN "ARole" character varying, IN "IsGrant" boolean)
    LANGUAGE plpgsql
    AS $$
declare
  "Command" varchar;
  S character varying(10);
  D character varying(10);
begin
  if ( "IsGrant" ) then
    S := 'GRANT';
    D := 'TO';
  else
    S := 'REVOKE';
    D := 'FROM';
  end if;
  "Command" := S || ' "' || "ARole" || '" ' || D || ' "' || "AUser" || '";'; 
  EXECUTE "Command";
end;
$$;


ALTER PROCEDURE "NewNavadvipa"."SetUserRole"(IN "AUser" character varying, IN "ARole" character varying, IN "IsGrant" boolean) OWNER TO "Navadvipa Chandra das";

--
-- Name: Entity_EntityID_seq; Type: SEQUENCE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE "NewNavadvipa"."Entity_EntityID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "NewNavadvipa"."Entity_EntityID_seq" OWNER TO "Navadvipa Chandra das";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Entity; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Entity" (
    "EntityID" bigint DEFAULT nextval('"NewNavadvipa"."Entity_EntityID_seq"'::regclass) NOT NULL,
    "KindID" bigint NOT NULL,
    "Entity" character varying(200) NOT NULL,
    "Actual" boolean DEFAULT true NOT NULL
);


ALTER TABLE "NewNavadvipa"."Entity" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Entity"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."Entity" IS 'Таблиа сущностей, связана с таблицей Kind как master-detail. Kind отображается деревом с помощью компонета TNNVDBTreeView, а Entity отображается в виде листиков веточек этогго дерева или его плодами с помощью компонета TNNVDBGrid. Это обычная практика.';


--
-- Name: Color; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Color" (
    "FonColor" integer NOT NULL,
    "FontColor" integer NOT NULL,
    "VectorIndex" bigint NOT NULL,
    "EnumLiteral" character varying(64)
)
INHERITS ("NewNavadvipa"."Entity");


ALTER TABLE "NewNavadvipa"."Color" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Color"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."Color" IS 'Цвета';


--
-- Name: Kind_KindID_seq; Type: SEQUENCE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE "NewNavadvipa"."Kind_KindID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "NewNavadvipa"."Kind_KindID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: Kind; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Kind" (
    "KindID" bigint DEFAULT nextval('"NewNavadvipa"."Kind_KindID_seq"'::regclass) NOT NULL,
    "ParentID" bigint,
    "Kind" character varying(100) NOT NULL,
    "Actual" boolean DEFAULT true NOT NULL
);


ALTER TABLE "NewNavadvipa"."Kind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Kind"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."Kind" IS 'Таблица древовидная для видов чего-нибудь!';


--
-- Name: ColorKind; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."ColorKind" (
)
INHERITS ("NewNavadvipa"."Kind");


ALTER TABLE "NewNavadvipa"."ColorKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "ColorKind"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."ColorKind" IS 'Виды цветов';


--
-- Name: Commod; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Commod" (
    "Price" double precision DEFAULT 0 NOT NULL
)
INHERITS ("NewNavadvipa"."Entity");


ALTER TABLE "NewNavadvipa"."Commod" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Commod"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."Commod" IS 'Товары и услуги';


--
-- Name: CommodKind; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."CommodKind" (
    "InPrice" boolean
)
INHERITS ("NewNavadvipa"."Kind");


ALTER TABLE "NewNavadvipa"."CommodKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: COLUMN "CommodKind"."InPrice"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN "NewNavadvipa"."CommodKind"."InPrice" IS 'Включать ли в прайс';


--
-- Name: Language; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Language" (
    "Original" text
)
INHERITS ("NewNavadvipa"."Entity");


ALTER TABLE "NewNavadvipa"."Language" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Language"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."Language" IS 'Слова для перевода!';


--
-- Name: LanguageKind; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."LanguageKind" (
)
INHERITS ("NewNavadvipa"."Kind");


ALTER TABLE "NewNavadvipa"."LanguageKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "LanguageKind"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."LanguageKind" IS 'Виды слов для перевода';


--
-- Name: Languages; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Languages" (
    "LanguagesID" bigint NOT NULL,
    "LanguagesStringID" character varying(5) NOT NULL,
    "Languages" character varying(32) NOT NULL
);


ALTER TABLE "NewNavadvipa"."Languages" OWNER TO "Navadvipa Chandra das";

--
-- Name: Languages_LanguagesID_seq; Type: SEQUENCE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE "NewNavadvipa"."Languages_LanguagesID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "NewNavadvipa"."Languages_LanguagesID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: Languages_LanguagesID_seq; Type: SEQUENCE OWNED BY; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER SEQUENCE "NewNavadvipa"."Languages_LanguagesID_seq" OWNED BY "NewNavadvipa"."Languages"."LanguagesID";


--
-- Name: Rights; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Rights" (
    "Literal" character varying(64),
    "VectorIndex" bigint
)
INHERITS ("NewNavadvipa"."Entity");


ALTER TABLE "NewNavadvipa"."Rights" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Rights"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."Rights" IS 'Полномочия пользователей!';


--
-- Name: RightsKind; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."RightsKind" (
)
INHERITS ("NewNavadvipa"."Kind");


ALTER TABLE "NewNavadvipa"."RightsKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "RightsKind"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."RightsKind" IS 'Виды полномочий';


--
-- Name: Role; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Role" (
)
INHERITS ("NewNavadvipa"."Entity");


ALTER TABLE "NewNavadvipa"."Role" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Role"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."Role" IS 'Роли пользователей!';


--
-- Name: RoleKind; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."RoleKind" (
)
INHERITS ("NewNavadvipa"."Kind");


ALTER TABLE "NewNavadvipa"."RoleKind" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "RoleKind"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."RoleKind" IS 'Виды ролей пользователей';


--
-- Name: RoleRights_RoleRightsID_seq; Type: SEQUENCE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE "NewNavadvipa"."RoleRights_RoleRightsID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "NewNavadvipa"."RoleRights_RoleRightsID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: RoleRights; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."RoleRights" (
    "RoleRightsID" bigint DEFAULT nextval('"NewNavadvipa"."RoleRights_RoleRightsID_seq"'::regclass) NOT NULL,
    "RoleID" bigint NOT NULL,
    "EntityID" bigint NOT NULL
);


ALTER TABLE "NewNavadvipa"."RoleRights" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "RoleRights"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."RoleRights" IS 'Права ролей пользователей!';


--
-- Name: Translate; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Translate" (
    "TranslateID" bigint NOT NULL,
    "LanguageID" bigint NOT NULL,
    "LanguagesID" bigint NOT NULL,
    "Translate" text
);


ALTER TABLE "NewNavadvipa"."Translate" OWNER TO "Navadvipa Chandra das";

--
-- Name: Translate_TranslateID_seq; Type: SEQUENCE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE "NewNavadvipa"."Translate_TranslateID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "NewNavadvipa"."Translate_TranslateID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: Translate_TranslateID_seq; Type: SEQUENCE OWNED BY; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER SEQUENCE "NewNavadvipa"."Translate_TranslateID_seq" OWNED BY "NewNavadvipa"."Translate"."TranslateID";


--
-- Name: UserReg; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."UserReg" (
    "UserRegKey" character varying(720) NOT NULL,
    "UserData" bytea
);


ALTER TABLE "NewNavadvipa"."UserReg" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "UserReg"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."UserReg" IS 'Таблица, содержащая настройки пользователей в бинарном виде!';


--
-- Name: COLUMN "UserReg"."UserRegKey"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN "NewNavadvipa"."UserReg"."UserRegKey" IS 'Поле - первичный ключ для настройки!';


--
-- Name: COLUMN "UserReg"."UserData"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN "NewNavadvipa"."UserReg"."UserData" IS 'Поле - натройки пользователей в бинарном виде!';


--
-- Name: UserRights_UserRightsID_seq; Type: SEQUENCE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE "NewNavadvipa"."UserRights_UserRightsID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "NewNavadvipa"."UserRights_UserRightsID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: UserRights; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."UserRights" (
    "UserRightsID" bigint DEFAULT nextval('"NewNavadvipa"."UserRights_UserRightsID_seq"'::regclass) NOT NULL,
    "UserID" bigint NOT NULL,
    "EntityID" bigint NOT NULL,
    "IsPlus" boolean DEFAULT true NOT NULL
);


ALTER TABLE "NewNavadvipa"."UserRights" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "UserRights"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."UserRights" IS 'Права пользователей!';


--
-- Name: UserRoles_UserRolesID_seq; Type: SEQUENCE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE "NewNavadvipa"."UserRoles_UserRolesID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "NewNavadvipa"."UserRoles_UserRolesID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: UserRoles; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."UserRoles" (
    "UserRolesID" bigint DEFAULT nextval('"NewNavadvipa"."UserRoles_UserRolesID_seq"'::regclass) NOT NULL,
    "UserID" bigint NOT NULL,
    "EntityID" bigint NOT NULL
);


ALTER TABLE "NewNavadvipa"."UserRoles" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "UserRoles"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."UserRoles" IS 'Роль пользователей!';


--
-- Name: Users_UserID_seq; Type: SEQUENCE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE SEQUENCE "NewNavadvipa"."Users_UserID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "NewNavadvipa"."Users_UserID_seq" OWNER TO "Navadvipa Chandra das";

--
-- Name: Users; Type: TABLE; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

CREATE TABLE "NewNavadvipa"."Users" (
    "UserID" bigint DEFAULT nextval('"NewNavadvipa"."Users_UserID_seq"'::regclass) NOT NULL,
    "Name" character varying(32) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" boolean DEFAULT false NOT NULL,
    "BirthDate" timestamp without time zone,
    "CreateDate" timestamp without time zone,
    "Anketa" "NewNavadvipa"."TAnketa"
);


ALTER TABLE "NewNavadvipa"."Users" OWNER TO "Navadvipa Chandra das";

--
-- Name: TABLE "Users"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON TABLE "NewNavadvipa"."Users" IS 'Таблица пользователей';


--
-- Name: COLUMN "Users"."UserID"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN "NewNavadvipa"."Users"."UserID" IS 'Первичный ключ пользователя';


--
-- Name: COLUMN "Users"."Name"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN "NewNavadvipa"."Users"."Name" IS 'Логин имя для базы данных';


--
-- Name: COLUMN "Users"."Note"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN "NewNavadvipa"."Users"."Note" IS 'Комментарий';


--
-- Name: COLUMN "Users"."IsDeleted"; Type: COMMENT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

COMMENT ON COLUMN "NewNavadvipa"."Users"."IsDeleted" IS 'Удалён ли пользователь?';


--
-- Name: Color EntityID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Color" ALTER COLUMN "EntityID" SET DEFAULT nextval('"NewNavadvipa"."Entity_EntityID_seq"'::regclass);


--
-- Name: Color Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Color" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: ColorKind KindID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."ColorKind" ALTER COLUMN "KindID" SET DEFAULT nextval('"NewNavadvipa"."Kind_KindID_seq"'::regclass);


--
-- Name: ColorKind Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."ColorKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Commod EntityID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Commod" ALTER COLUMN "EntityID" SET DEFAULT nextval('"NewNavadvipa"."Entity_EntityID_seq"'::regclass);


--
-- Name: Commod Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Commod" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: CommodKind KindID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."CommodKind" ALTER COLUMN "KindID" SET DEFAULT nextval('"NewNavadvipa"."Kind_KindID_seq"'::regclass);


--
-- Name: CommodKind Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."CommodKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Language EntityID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Language" ALTER COLUMN "EntityID" SET DEFAULT nextval('"NewNavadvipa"."Entity_EntityID_seq"'::regclass);


--
-- Name: Language Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Language" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: LanguageKind KindID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."LanguageKind" ALTER COLUMN "KindID" SET DEFAULT nextval('"NewNavadvipa"."Kind_KindID_seq"'::regclass);


--
-- Name: LanguageKind Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."LanguageKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Languages LanguagesID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Languages" ALTER COLUMN "LanguagesID" SET DEFAULT nextval('"NewNavadvipa"."Languages_LanguagesID_seq"'::regclass);


--
-- Name: Rights EntityID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Rights" ALTER COLUMN "EntityID" SET DEFAULT nextval('"NewNavadvipa"."Entity_EntityID_seq"'::regclass);


--
-- Name: Rights Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Rights" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: RightsKind KindID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RightsKind" ALTER COLUMN "KindID" SET DEFAULT nextval('"NewNavadvipa"."Kind_KindID_seq"'::regclass);


--
-- Name: RightsKind Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RightsKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Role EntityID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Role" ALTER COLUMN "EntityID" SET DEFAULT nextval('"NewNavadvipa"."Entity_EntityID_seq"'::regclass);


--
-- Name: Role Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Role" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: RoleKind KindID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RoleKind" ALTER COLUMN "KindID" SET DEFAULT nextval('"NewNavadvipa"."Kind_KindID_seq"'::regclass);


--
-- Name: RoleKind Actual; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RoleKind" ALTER COLUMN "Actual" SET DEFAULT true;


--
-- Name: Translate TranslateID; Type: DEFAULT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Translate" ALTER COLUMN "TranslateID" SET DEFAULT nextval('"NewNavadvipa"."Translate_TranslateID_seq"'::regclass);


--
-- Data for Name: Color; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (38, 83, 'Циклический цвет 00', true, 13828095, 0, 0, 'CycleColor0');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (41, 83, 'Циклический цвет 03', true, 9830346, 0, 1, 'CycleColor3');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (42, 83, 'Циклический цвет 04', true, 2424831, 0, 2, 'CycleColor4');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (20, 78, 'Услуга', true, 12976060, 0, 3, 'Service');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (22, 78, 'Комплект', true, 16632202, 0, 4, 'CommodAss');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (23, 78, ' Редактирование комплекта', true, 4783944, 0, 5, 'CommodAssOwner');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (25, 90, 'Детали комплекта', true, 12123900, 0, 6, 'CommodAssDetail');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (26, 90, 'Отсутствующий на складе товар', true, 65535, 255, 7, 'CommodLack');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (27, 90, 'Залежалый на складе товар', true, 13762468, 16711808, 8, 'CommodOld');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (28, 90, 'Товар с описанием', true, 16711680, 65535, 9, 'CommodWithNote');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (29, 90, 'Комментарий в документе', true, 12648384, 0, 10, 'CommentInPrim');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (114, 86, 'Табель выходов: отпуск', true, 16776960, 16711680, 115, 'TabelVyhodovOtpusk');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (52, 83, 'Циклический цвет 14', true, 10550435, 16711680, 67, 'CycleColor14');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (53, 83, 'Циклический цвет 15', true, 8454016, 0, 68, 'CycleColor15');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (115, 86, 'Табель выходов: больничный', true, 16711680, 65535, 116, 'TabelVyhodovBolnichnyi');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (116, 86, 'Табель выходов: не стандартное время', true, 65535, 255, 117, 'TabelVyhodovNotStandartTime');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (117, 86, 'Табель выходов: половина ставки', true, 9225983, 255, 118, 'TabelVyhodovPolovinaStavka');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (136, 85, 'Сервис клиент не возвращен 08 - 14 дней', true, 11468718, 0, 110, 'ServiceClient8_14');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (138, 85, 'Сервис клиент не возвращен 22 - 28 дней', true, 65280, 0, 113, 'ServiceClient22_28');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (128, 89, 'Коварный пользователь создан', true, 65535, 255, 87, 'SlyUserCreate');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (137, 85, 'Сервис клиент не возвращен 15 - 21 дней', true, 7995257, 0, 112, 'ServiceClient15_21');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (126, 89, 'Коварный пользователь вошел в "Троянду"', true, 255, 16777215, 85, 'SlyUserEnter');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (40, 83, 'Циклический цвет 02', true, 16771327, 255, 107, 'CycleColor2');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (39, 83, 'Циклический цвет 01', true, 16777107, 0, 108, 'CycleColor1');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (97, 84, 'Серийный номер не совпадает с товаром', true, 16711680, 65535, 111, 'SerialDifferentCommod');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (82, 90, 'В документе товар имеет отрицательный остаток', true, 65535, 255, 66, 'InDialogCommodMinusQuantity');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (98, 90, 'Склад в операции отличается от склада в документе!', true, 65535, 32768, 88, 'StorehousOperAndPrimDifferent');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (99, 90, 'Каёмочка индикатора в нормальном положении', true, 65535, 16711680, 89, 'KaemkaIndicatorNormal');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (100, 90, 'Поле индикатора в нормальном положении', true, 32768, 65535, 90, 'FieldIndicatorNormal');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (101, 90, 'Каёмочка индикатора в сигнальном положении', true, 65535, 16711680, 91, 'KaemkaIndicatorSignal');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (102, 90, 'Поле индикатора в сигнальном положении', true, 255, 65535, 92, 'FieldIndicatorSignal');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (110, 90, 'Документ оплачен, но не отгружен', true, 5635925, 16711680, 93, 'PrimPayAndNotShipment');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (111, 90, 'Документ отгружен, но не оплачен', true, 255, 65535, 94, 'PrimShipmentAndNotPay');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (112, 90, 'Табель выходов: неизвестно', true, 16777215, 16711680, 95, 'TabelVyhodovNotAny');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (113, 90, 'Табель выходов: прогул', true, 255, 65535, 96, 'TabelVyhodovProgul');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (118, 90, 'Цена последней закупки товара', true, 16376153, 16711680, 97, 'PriceLastCommod');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (119, 90, 'Серийника продался', true, 9225983, 255, 98, 'SerialPay');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (120, 90, 'Серийника продался, но не прошёл нужный срок ещё', true, 12902911, 32768, 99, 'SerialPayByNotSrok');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (121, 90, 'Опер-Комок - нет оплаты в приходном счете', true, 16777119, 14614528, 100, 'OperComokNotPayDebetPrim');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (122, 90, 'Опер-Комок - нет оплаты в расходном счете', true, 9225983, 255, 101, 'OperComokNotPayCreditPrim');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (124, 90, 'Товар устарел', true, 12632256, 0, 102, 'CommodVeryOld');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (125, 90, 'Комментарий - цвет окна', true, 9225983, 255, 103, 'CommentColorWinow');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (129, 90, 'Расходный счет оплачен по безналу и нет документов', true, 9225983, 255, 104, 'SchetCreditPayBeznalAndNotDocuments');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (130, 90, 'Расходный счет проведён и не оплачен и не отгружен', true, 65535, 255, 105, 'SchetCreditAcceptlAndNotPayAndNotOtgr');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (131, 90, 'Товар (серийник) взят на реализацию и не оплачен поставщику', true, 16711680, 65535, 106, 'SerialStoreButNotPayProvider');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (133, 90, 'Товар (серийник) куплен и не оплачен поставщику', true, 255, 65535, 120, 'SerialPayButNotPayProvider');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (140, 90, 'Выход из программы', true, 8454016, 12615680, 121, 'ExitFromProgram');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (141, 90, 'Печать документов', true, 8454143, 32768, 122, 'PrintPrim');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (142, 90, 'Попытка взлома "Троянды"', true, 16777215, 255, 123, 'ProgramTryVzlom');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (147, 90, 'Товар выкуплен', true, 10419870, 32768, 124, 'CommodPay');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (148, 90, 'Бухгалтерский товар', true, 255, 65535, 125, 'BuhgalterCommod');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (149, 90, 'В окне "Доктор" заявка не выполнена', true, 255, 65535, 126, 'DoctorZayavkaNotExecute');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (135, 85, 'Сервис клиент не возвращен 01 - 07 дней', true, 14548957, 0, 109, 'ServiceClient1_7');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (139, 85, 'Сервис клиент не возвращен более 29 дней', true, 55040, 0, 114, 'ServiceClientMore29');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (34, 90, 'Комментарий ко второй части суммы документа', true, 16777215, 255, 11, 'CommentSummaSecond');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (30, 90, 'Ошибочное субконто', true, 16777215, 255, 12, 'ErrorSubconto');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (31, 90, 'Серая строка при печати', true, 15658734, 0, 13, 'GrayLine');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (70, 90, 'Горячая клавиша', true, 16777215, 16711680, 56, 'HotKey');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (127, 89, 'Коварный пользователь удален', true, 9225983, 255, 86, 'SlyUserDelete');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (54, 83, 'Циклический цвет 16', true, 16381375, 16711680, 69, 'CycleColor16');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (55, 83, 'Циклический цвет 17', true, 16711808, 16777215, 70, 'CycleColor17');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (56, 83, 'Циклический цвет 18', true, 13303785, 0, 71, 'CycleColor18');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (143, 88, 'Произведена одна уценка товара', true, 16771839, 16711680, 81, 'CommodMarkdown1');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (144, 88, 'Произведено две уценки товара', true, 16765695, 16711680, 82, 'CommodMarkdown2');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (145, 88, 'Произведены три уценки товара', true, 16758783, 16711680, 83, 'CommodMarkdown3');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (146, 88, 'Произведены четыре и более уценки товара', true, 16753919, 16711680, 84, 'CommodMarkdown4');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (104, 87, 'Сумма мелкого опта', true, 65535, 255, 75, 'SummaSmallOpt');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (105, 87, 'Сумма дилерская', true, 12058551, 255, 76, 'SummaDiler');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (106, 87, 'Сумма оптовая', true, 16777119, 255, 77, 'SummaOpt');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (107, 87, 'Сумма входная', true, 5614335, 8421376, 78, 'SummaEntry');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (108, 87, 'Сумма ниже входной', true, 255, 65535, 79, 'SummaSmallThanEntry');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (109, 87, 'Сумма выше розничной', true, 16759773, 12124160, 80, 'SummaMoreThanRetail');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (57, 83, 'Циклический цвет 19', true, 65535, 255, 72, 'CycleColor19');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (58, 83, 'Циклический цвет 20', true, 16777215, 32768, 73, 'CycleColor20');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (63, 83, 'Циклический цвет 25', true, 8388863, 16777215, 74, 'CycleColor25');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (96, 84, 'Серийные номера замененные поставщиком, просрочена гарантия', true, 16777215, 255, 48, 'SerialChangeSupplierWithoutGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (78, 90, 'В диалоге выбранное количество', true, 65535, 255, 17, 'InDialogQuantity');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (79, 90, 'В диалоге цена больше обычной', true, 65535, 16711680, 18, 'InDialogPriceBig');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (132, 90, 'Товар (серийник) куплен и оплачен поставщику', true, 16777215, 0, 40, 'SerialPayAndStore');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (123, 90, 'Товар (серийник) принят на реализацию и оплачен поставщику', true, 16776960, 16711808, 46, 'SerialNotPayAndStore');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (36, 90, 'Комментарий к третьей части суммы документа', true, 16777215, 16711935, 49, 'CommentPartSumma3');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (37, 90, 'Третяя часть суммы документа', true, 16777215, 0, 50, 'PartSumma3');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (65, 90, 'Неактуальная операция', true, 255, 65535, 51, 'NotActualOper');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (66, 90, 'Документы с комментариями', true, 16294002, 128, 52, 'PrimWithComment');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (67, 90, 'Актуальный комментарий', true, 16777092, 0, 53, 'ActualComment');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (68, 90, 'Закупочная цена товара больше входной', true, 255, 16777215, 54, 'PriceCommodPayBig');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (69, 90, 'Частичная оплата', true, 16767449, 0, 55, 'PartPay');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (32, 90, 'Комментарий к первой части суммы документа', true, 16777215, 16711680, 14, 'CommentSummaFirst');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (33, 90, 'Первая часть суммы документа', true, 16777215, 0, 15, 'SummaFirst');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (35, 90, 'Вторая часть суммы документа', true, 16777215, 32768, 16, 'SummaSecond');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (59, 83, 'Циклический цвет 21', true, 65280, 16711680, 19, 'CycleColor21');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (83, 84, 'Серийные номера на складе с гарантией', true, 16777215, 0, 20, 'SerialWithGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (87, 84, 'Серийные номера ожидаются с гарантийного ремонта', true, 12975900, 0, 21, 'SerialWaitWithGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (92, 84, 'Серийные номера на ремонте у поставщика, просрочена гарантия', true, 16777058, 255, 22, 'SerialSupplierWithoutGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (48, 83, 'Циклический цвет 10', true, 12975900, 0, 23, 'CycleColor10');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (49, 83, 'Циклический цвет 11', true, 16772351, 0, 24, 'CycleColor11');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (50, 83, 'Циклический цвет 12', true, 60138, 0, 25, 'CycleColor12');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (51, 83, 'Циклический цвет 13', true, 16744576, 16777215, 26, 'CycleColor13');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (60, 83, 'Циклический цвет 22', true, 8454143, 16711935, 27, 'CycleColor22');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (61, 83, 'Циклический цвет 23', true, 16777190, 0, 28, 'CycleColor23');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (62, 83, 'Циклический цвет 24', true, 16777215, 255, 29, 'CycleColor24');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (64, 83, 'Циклический цвет 26', true, 16777215, 16711680, 30, 'CycleColor26');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (84, 84, 'Серийные номера на складе гарантия просрочена', true, 16777215, 255, 31, 'SerialWithoutGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (85, 84, 'Серийные номера проданные с гарантией', true, 10878647, 255, 32, 'SerialSaleWithGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (86, 84, 'Серийные номера проданные гарантия просрочена', true, 65535, 255, 33, 'SerialSaleWithoutGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (88, 84, 'Серийные номера ожидаются с гарантийного ремонта, просрочена гарантия', true, 12975900, 255, 34, 'SerialWaitWithoutGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (89, 84, 'Серийные номера на временной замене', true, 12713915, 4210816, 35, 'SerialTemporaryWithGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (90, 84, 'Серийные номера на временной замене, просрочена гарантия', true, 12713915, 255, 36, 'SerialTemporaryWithoutGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (91, 84, 'Серийные номера на ремонте у поставщика происхождения', true, 16777058, 16711680, 37, 'SerialSupplierWithGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (93, 84, 'Серийные номера неизвестного происхождения', true, 16777181, 16711680, 38, 'SerialXWithGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (94, 84, 'Серийные номера неизвестного происхождения, просрочена гарантия', true, 16777181, 255, 39, 'SerialXWithoutGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (43, 83, 'Циклический цвет 05', true, 16777088, 0, 41, 'CycleColor5');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (44, 83, 'Циклический цвет 06', true, 14281983, 16711935, 42, 'CycleColor6');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (45, 83, 'Циклический цвет 07', true, 130763, 255, 43, 'CycleColor7');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (46, 83, 'Циклический цвет 08', true, 16708563, 0, 44, 'CycleColor8');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (47, 83, 'Циклический цвет 09', true, 16768991, 255, 45, 'CycleColor9');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (95, 84, 'Серийные номера замененные поставщиком', true, 16777215, 16711680, 47, 'SerialChangeSupplierWithGuaranty');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (71, 90, 'Горячая клавиша без клавиш сдвига', true, 16777215, 255, 57, 'HotKeyWithoutShift');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (72, 90, 'Пустая горячая клавиша', true, 16777215, 32768, 58, 'EmptyHotKey');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (73, 90, 'Шахматка: отрицательная сумма', true, 65535, 255, 59, 'ChessMinusSumma');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (74, 90, 'Шахматка: нейтральные проводки', true, 16777177, 16711680, 60, 'ChessNeutralConstr');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (75, 90, 'Шахматка: имена счетов', true, 65535, 0, 61, 'ChessAccount');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (76, 90, 'Шахматка: итоги', true, 16776960, 16711680, 62, 'ChessItog');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (77, 90, 'Машина времени / проводки / измененный счет', true, 65535, 255, 63, 'KalaYantra');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (80, 90, 'В диалоге цена меньше обычной', true, 65535, 32768, 64, 'InDialogPriceSmall');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (81, 90, 'В документе товар имеет нулевой остаток', true, 65535, 0, 65, 'InDialogCommodNullQuantity');
INSERT INTO "NewNavadvipa"."Color" ("EntityID", "KindID", "Entity", "Actual", "FonColor", "FontColor", "VectorIndex", "EnumLiteral") VALUES (103, 87, 'Сумма розничная и выше', true, 16777215, 0, 119, 'SummaRetail');


--
-- Data for Name: ColorKind; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (78, 72, 'Товар', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (83, 72, 'Циклический цвет', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (84, 72, 'Серийники', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (85, 72, 'Сервис-клиент', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (86, 72, 'Табель выходов', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (87, 72, 'Сумма', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (88, 72, 'Уценка товара', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (89, 72, 'Коварный пользователь', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (90, 72, 'Сборная солянка', true);
INSERT INTO "NewNavadvipa"."ColorKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (72, 0, 'Цвета', true);


--
-- Data for Name: Commod; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (3, 2, 'ffdefdfd', true, 8);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (1, 1, 'Мячик', true, 2);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (2, 1, 'Гантеля', false, 44);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (6, 4, 'eweew', true, 2);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (7, 4, 'eeee', false, 2);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (11, 4, '555', true, 55);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (12, 60, 'Гиря', true, 2);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (13, 60, 'Биллиард', true, 3);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (10, 8, 'fggffg', true, 4);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (4, 3, 'Крыша', true, 6);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (9, 8, 'gffg333', true, 45);
INSERT INTO "NewNavadvipa"."Commod" ("EntityID", "KindID", "Entity", "Actual", "Price") VALUES (10389, 8, 'wwewewe', true, 3);


--
-- Data for Name: CommodKind; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (10, 2, 'Трикотах', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (28, 26, 'Сигары', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (29, 26, 'Шары', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (14, 3, 'Материнские платы', false, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (15, 3, 'SSD Накопители', false, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (26, 1, 'Дирижабли', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (5, 2, 'Пальто', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (9, 2, 'Трусы', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (12, 3, 'Корпуса', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (13, 3, 'Блоки питания', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (16, 3, 'HDD Накопители', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (17, 3, 'Принтеры', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (8, 2, 'Брюки2', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (23, 7, 'Сари', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (7, 2, 'Платья', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (6, 2, 'Рубашки', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (30, 12, 'Rere', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (31, 12, '232323232323', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (32, 31, 'eeee', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (33, 31, 'rereerrere', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (18, 3, 'Сетевое оборудование', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (22, 7, 'Повседневные', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (35, 34, 'Иволга', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (36, 34, 'уцууц', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (39, 38, 'rtrtrtrt', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (21, 7, 'Бальные', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (2, 1, 'Одежда', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (41, 38, 'rttrtrrrtrt', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (42, 41, 'ReRE', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (43, 41, '443ererer', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (46, 45, 'dfdfddfdfdfdffddf', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (48, 47, 'dddsdsdsdseterretrt', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (49, 28, 'Ангары', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (50, 49, 'Корпуса', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (51, 50, 'Кактуса', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (52, 51, 'Кучки', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (53, 52, 'Колючки', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (54, 53, 'Веревочки', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (55, 54, 'Маковочки', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (56, 37, '37', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (58, 29, 'Водяные', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (59, 58, 'Курукшетра', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (63, 62, 'dddsd', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (64, 63, 'asassa', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (66, 61, 'Джива итаттва', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (68, 67, 'dddsds', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (69, 68, 'fggfgffgfggf', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (4, 1, 'Мебель!', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (71, 70, 'ddddddsdsds!!', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (60, 29, 'Краска', false, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (3, 1, 'Компьютеры', false, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (95, 2, 'Панчо', true, NULL);
INSERT INTO "NewNavadvipa"."CommodKind" ("KindID", "ParentID", "Kind", "Actual", "InPrice") VALUES (1, 0, 'Товар', true, NULL);


--
-- Data for Name: Entity; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--



--
-- Data for Name: Kind; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Kind" ("KindID", "ParentID", "Kind", "Actual") VALUES (0, 0, 'Виды', true);


--
-- Data for Name: Language; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10080, 116, 'TfmvExplorer.fmvExplorer.Caption', true, 'Проводник "Джая Шрила Прабхупада"');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10084, 116, 'TfmvExplorer.nwExamples.Rubl1', true, 'рубль');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10085, 116, 'TfmvExplorer.nwExamples.Rubl24', true, 'рубля');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10086, 116, 'TfmvExplorer.nwExamples.Rubl5', true, 'рублей');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10087, 116, 'TfmvExplorer.nwExamples.Copyica1', true, 'копейка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10088, 116, 'TfmvExplorer.nwExamples.Copyica24', true, 'копейки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10089, 116, 'TfmvExplorer.nwExamples.Copyica5', true, 'копеек');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10090, 116, 'TfmvExplorer.aActionListSetup.Caption', true, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10091, 116, 'TfmvExplorer.aActionListSetup.Hint', true, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10092, 116, 'TfmvExplorer.aRelease.Caption', true, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10093, 116, 'TfmvExplorer.aRelease.Hint', true, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10094, 116, 'TfmvExplorer.aClearCase.Caption', true, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10095, 116, 'TfmvExplorer.aClearCase.Hint', true, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10096, 116, 'TfmvExplorer.aPrepareLanguage.Caption', true, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10097, 116, 'TfmvExplorer.aPrepareLanguage.Hint', true, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10098, 116, 'TfmvExplorer.tsDB.Caption', true, 'База данных');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10100, 116, 'TfmvExplorer.tbDBAutoEdit.Caption', true, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10101, 116, 'TfmvExplorer.tbDBAutoEdit.Hint', true, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10102, 116, 'TfmvExplorer.tbRowInspector.Caption', true, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10103, 116, 'TfmvExplorer.tbRowInspector.Hint', true, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10104, 116, 'TfmvExplorer.tbDBSelectAll.Caption', true, 'Выделить все');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10105, 116, 'TfmvExplorer.tbDBSelectAll.Hint', true, 'Выделить все');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10106, 116, 'TfmvExplorer.tbDBCut.Caption', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10107, 116, 'TfmvExplorer.tbDBCut.Hint', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10108, 116, 'TfmvExplorer.tbDBCopy.Caption', true, 'Копировать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10109, 116, 'TfmvExplorer.tbDBCopy.Hint', true, 'Копировать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10110, 116, 'TfmvExplorer.tbDBPaste.Caption', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10111, 116, 'TfmvExplorer.tbDBPaste.Hint', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10112, 116, 'TfmvExplorer.tbDBMerge.Caption', true, 'Слить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10113, 116, 'TfmvExplorer.tbDBMerge.Hint', true, 'Слить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10114, 116, 'TfmvExplorer.tbDBCachedUpdates.Caption', true, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10115, 116, 'TfmvExplorer.tbDBCachedUpdates.Hint', true, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10116, 116, 'TfmvExplorer.tbRemeberRow.Caption', true, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10117, 116, 'TfmvExplorer.tbRemeberRow.Hint', true, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10118, 116, 'TfmvExplorer.tbStoreData.Caption', true, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10119, 116, 'TfmvExplorer.tbStoreData.Hint', true, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10120, 116, 'TfmvExplorer.tbTVNodeAdminReload.Caption', true, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10121, 116, 'TfmvExplorer.tbTVNodeAdminReload.Hint', true, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10122, 116, 'TfmvExplorer.tbDBTreeViewReload.Caption', true, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10123, 116, 'TfmvExplorer.tbDBTreeViewReload.Hint', true, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10124, 116, 'TfmvExplorer.tbDBTreeNodeActualInvert.Caption', true, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10125, 116, 'TfmvExplorer.tbDBTreeNodeActualInvert.Hint', true, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10126, 116, 'TfmvExplorer.tbDBTreeViewActualOnly.Caption', true, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10127, 116, 'TfmvExplorer.tbDBTreeViewActualOnly.Hint', true, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10128, 116, 'TfmvExplorer.tbDBTreeViewEndToEndViewing.Caption', true, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10129, 116, 'TfmvExplorer.tbDBTreeViewEndToEndViewing.Hint', true, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10130, 116, 'TfmvExplorer.tbDBTreeNodePrev.Caption', true, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10131, 116, 'TfmvExplorer.tbDBTreeNodePrev.Hint', true, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10132, 116, 'TfmvExplorer.tbDBTreeNodeNext.Caption', true, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10133, 116, 'TfmvExplorer.tbDBTreeNodeNext.Hint', true, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10134, 116, 'TfmvExplorer.deKindID.Hint', true, 'Номер веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10135, 116, 'TfmvExplorer.tsSetup.Caption', true, 'Настройка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10136, 116, 'TfmvExplorer.tsSetup.Hint', true, 'Настройка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10138, 116, 'TfmvExplorer.tbActionListSetup.Caption', true, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10139, 116, 'TfmvExplorer.tbActionListSetup.Hint', true, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10140, 116, 'TfmvExplorer.tbDBGridProperty.Caption', true, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10141, 116, 'TfmvExplorer.tbDBGridProperty.Hint', true, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10142, 116, 'TfmvExplorer.tbAutoMergeMainMenu.Caption', true, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10143, 116, 'TfmvExplorer.tbAutoMergeMainMenu.Hint', true, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10144, 116, 'TfmvExplorer.cbEnterKind.Text', true, 'Обычный');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10145, 116, 'TfmvExplorer.cbEnterKind.Hint', true, 'Тип Enter');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10146, 116, 'TfmvExplorer.tbRelease.Caption', true, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10147, 116, 'TfmvExplorer.tbRelease.Hint', true, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10148, 116, 'TfmvExplorer.tbClearCase.Caption', true, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10149, 116, 'TfmvExplorer.tbClearCase.Hint', true, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10150, 116, 'TfmvExplorer.tbPrepareLanguage.Caption', true, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10151, 116, 'TfmvExplorer.tbPrepareLanguage.Hint', true, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10153, 116, 'TfmvExplorer.tbDBSearch.Caption', true, 'Найти');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10154, 116, 'TfmvExplorer.tbDBSearch.Hint', true, 'Найти');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10155, 116, 'TfmvExplorer.tbDBQuickSearch.Caption', true, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10156, 116, 'TfmvExplorer.tbDBQuickSearch.Hint', true, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10157, 116, 'TfmvExplorer.tbDBSearchNext.Caption', true, 'Найти далее');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10158, 116, 'TfmvExplorer.tbDBSearchNext.Hint', true, 'Найти далее');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10159, 116, 'TfmvExplorer.tbDBSearchReset.Caption', true, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10160, 116, 'TfmvExplorer.tbDBSearchReset.Hint', true, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10162, 116, 'TfmvExplorer.tbEraseFilterSearch.Caption', true, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10163, 116, 'TfmvExplorer.tbEraseFilterSearch.Hint', true, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10164, 116, 'TfmvExplorer.tbDBSearchVectorClear.Caption', true, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10165, 116, 'TfmvExplorer.tbDBSearchVectorClear.Hint', true, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10166, 116, 'TfmvExplorer.aDBGridProperty.Caption', true, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10167, 116, 'TfmvExplorer.aDBGridProperty.Hint', true, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10168, 116, 'TfmvExplorer.aDBCut.Caption', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10169, 116, 'TfmvExplorer.aDBCut.Hint', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10170, 116, 'TfmvExplorer.aDBCopy.Caption', true, 'Копировать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10171, 116, 'TfmvExplorer.aDBCopy.Hint', true, 'Копировать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10172, 116, 'TfmvExplorer.aDBPaste.Caption', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10173, 116, 'TfmvExplorer.aDBPaste.Hint', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10174, 116, 'TfmvExplorer.aDBMerge.Caption', true, 'Слить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10175, 116, 'TfmvExplorer.aDBMerge.Hint', true, 'Слить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10176, 116, 'TfmvExplorer.aDBCachedUpdates.Caption', true, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10177, 116, 'TfmvExplorer.aDBCachedUpdates.Hint', true, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10178, 116, 'TfmvExplorer.aDBAutoEdit.Caption', true, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10179, 116, 'TfmvExplorer.aDBAutoEdit.Hint', true, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10180, 116, 'TfmvExplorer.aRemeberRow.Caption', true, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10181, 116, 'TfmvExplorer.aRemeberRow.Hint', true, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10182, 116, 'TfmvExplorer.aStoreData.Caption', true, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10183, 116, 'TfmvExplorer.aStoreData.Hint', true, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10184, 116, 'TfmvExplorer.aTVNodeAdminReload.Caption', true, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10185, 116, 'TfmvExplorer.aTVNodeAdminReload.Hint', true, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10186, 116, 'TfmvExplorer.aDBTreeViewReload.Caption', true, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10187, 116, 'TfmvExplorer.aDBTreeViewReload.Hint', true, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10188, 116, 'TfmvExplorer.aDBTreeViewNodeActualInvert.Caption', true, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10189, 116, 'TfmvExplorer.aDBTreeViewNodeActualInvert.Hint', true, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10190, 116, 'TfmvExplorer.aDBTreeViewActualOnly.Caption', true, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10191, 116, 'TfmvExplorer.aDBTreeViewActualOnly.Hint', true, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10192, 116, 'TfmvExplorer.aTVNodeAdminPrint.Caption', true, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10193, 116, 'TfmvExplorer.aTVNodeAdminPrint.Hint', true, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10194, 116, 'TfmvExplorer.aDBTreeViewEndToEndViewing.Caption', true, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10195, 116, 'TfmvExplorer.aDBTreeViewEndToEndViewing.Hint', true, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10196, 116, 'TfmvExplorer.aAutoMergeMainMenu.Caption', true, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10197, 116, 'TfmvExplorer.aAutoMergeMainMenu.Hint', true, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10198, 116, 'TfmvExplorer.aDBSearch.Caption', true, 'Найти');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10199, 116, 'TfmvExplorer.aDBSearch.Hint', true, 'Найти');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10200, 116, 'TfmvExplorer.aDBSearchNext.Caption', true, 'Найти далее');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10201, 116, 'TfmvExplorer.aDBSearchNext.Hint', true, 'Найти далее');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10202, 116, 'TfmvExplorer.aDBQuickSearch.Caption', true, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10203, 116, 'TfmvExplorer.aDBQuickSearch.Hint', true, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10204, 116, 'TfmvExplorer.aDBSearchReset.Caption', true, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10205, 116, 'TfmvExplorer.aDBSearchReset.Hint', true, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10206, 116, 'TfmvExplorer.aEraseFilterSearch.Caption', true, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10207, 116, 'TfmvExplorer.aEraseFilterSearch.Hint', true, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10208, 116, 'TfmvExplorer.aDBTreeNodePrev.Caption', true, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10209, 116, 'TfmvExplorer.aDBTreeNodePrev.Hint', true, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10210, 116, 'TfmvExplorer.aDBTreeNodeNext.Caption', true, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10211, 116, 'TfmvExplorer.aDBTreeNodeNext.Hint', true, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10212, 116, 'TfmvExplorer.aDBSelectAll.Caption', true, 'Выделить все');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10213, 116, 'TfmvExplorer.aDBSelectAll.Hint', true, 'Выделить все');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10214, 116, 'TfmvExplorer.aDBSearchVectorClear.Caption', true, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10215, 116, 'TfmvExplorer.aDBSearchVectorClear.Hint', true, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10216, 116, 'TfmvExplorer.aRowInspector.Caption', true, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10217, 116, 'TfmvExplorer.aRowInspector.Hint', true, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10218, 116, 'TfmvExplorer.miDB.Caption', true, 'База данных');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10219, 116, 'TfmvExplorer.miDBAutoEdit.Caption', true, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10220, 116, 'TfmvExplorer.miDBAutoEdit.Hint', true, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10221, 116, 'TfmvExplorer.miDBSelectAll.Caption', true, 'Выделить все');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10222, 116, 'TfmvExplorer.miDBSelectAll.Hint', true, 'Выделить все');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10223, 116, 'TfmvExplorer.miDBCut.Caption', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10224, 116, 'TfmvExplorer.miDBCut.Hint', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10225, 116, 'TfmvExplorer.miDBCopy.Caption', true, 'Копировать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10226, 116, 'TfmvExplorer.miDBCopy.Hint', true, 'Копировать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10227, 116, 'TfmvExplorer.miDBPaste.Caption', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10228, 116, 'TfmvExplorer.miDBPaste.Hint', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10229, 116, 'TfmvExplorer.miDBMerge.Caption', true, 'Слить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10230, 116, 'TfmvExplorer.miDBMerge.Hint', true, 'Слить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10231, 116, 'TfmvExplorer.miDBCachedUpdates.Caption', true, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10232, 116, 'TfmvExplorer.miDBCachedUpdates.Hint', true, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10233, 116, 'TfmvExplorer.miRemeberRow.Caption', true, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10234, 116, 'TfmvExplorer.miRemeberRow.Hint', true, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10235, 116, 'TfmvExplorer.miStoreData.Caption', true, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10236, 116, 'TfmvExplorer.miStoreData.Hint', true, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10237, 116, 'TfmvExplorer.miTVNodeAdminReload.Caption', true, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10238, 116, 'TfmvExplorer.miTVNodeAdminReload.Hint', true, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10239, 116, 'TfmvExplorer.miDBTreeViewReload.Caption', true, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10240, 116, 'TfmvExplorer.miDBTreeViewReload.Hint', true, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10241, 116, 'TfmvExplorer.miDBTreeViewNodeActualInvert.Caption', true, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10242, 116, 'TfmvExplorer.miDBTreeViewNodeActualInvert.Hint', true, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10243, 116, 'TfmvExplorer.miDBTreeViewActualOnly.Caption', true, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10244, 116, 'TfmvExplorer.miDBTreeViewActualOnly.Hint', true, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10245, 116, 'TfmvExplorer.miDBTreeViewEndToEndViewing.Caption', true, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10246, 116, 'TfmvExplorer.miDBTreeViewEndToEndViewing.Hint', true, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10247, 116, 'TfmvExplorer.miDBSearch.Caption', true, 'Найти');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10248, 116, 'TfmvExplorer.miDBSearch.Hint', true, 'Найти');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10249, 116, 'TfmvExplorer.miDBSearchNext.Caption', true, 'Найти далее');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10250, 116, 'TfmvExplorer.miDBSearchNext.Hint', true, 'Найти далее');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10251, 116, 'TfmvExplorer.miDBSearchReset.Caption', true, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10252, 116, 'TfmvExplorer.miDBSearchReset.Hint', true, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10253, 116, 'TfmvExplorer.miSearchEdit.Caption', true, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10254, 116, 'TfmvExplorer.miSearchEdit.Hint', true, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10255, 116, 'TfmvExplorer.miEraseFilterSearch.Caption', true, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10256, 116, 'TfmvExplorer.miEraseFilterSearch.Hint', true, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10257, 116, 'TfmvExplorer.miRowInspector.Caption', true, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10258, 116, 'TfmvExplorer.miRowInspector.Hint', true, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10259, 116, 'TfmvExplorer.miDBProperty.Caption', true, 'Свойства');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10260, 116, 'TfmvExplorer.miActionListSetup.Caption', true, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10261, 116, 'TfmvExplorer.miActionListSetup.Hint', true, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10262, 116, 'TfmvExplorer.miDBGridProperty.Caption', true, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10263, 116, 'TfmvExplorer.miDBGridProperty.Hint', true, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10264, 116, 'TfmvExplorer.miAutoMergeMainMenu.Caption', true, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10265, 116, 'TfmvExplorer.miAutoMergeMainMenu.Hint', true, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10266, 116, 'TfmvExplorer.miRelease.Caption', true, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10267, 116, 'TfmvExplorer.miRelease.Hint', true, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10268, 116, 'TfmvExplorer.miClearCase.Caption', true, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10269, 116, 'TfmvExplorer.miClearCase.Hint', true, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10270, 116, 'TfmvExplorer.miPrepareLanguage.Caption', true, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10271, 116, 'TfmvExplorer.miPrepareLanguage.Hint', true, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10272, 116, 'TfmvExplorer.mipDBCut.Caption', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10273, 116, 'TfmvExplorer.mipDBCut.Hint', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10274, 116, 'TfmvExplorer.mipDBCopy.Caption', true, 'Копировать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10275, 116, 'TfmvExplorer.mipDBCopy.Hint', true, 'Копировать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10276, 116, 'TfmvExplorer.mipDBPaste.Caption', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10277, 116, 'TfmvExplorer.mipDBPaste.Hint', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10278, 116, 'TfmvExplorer.mipDBMerge.Caption', true, 'Слить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10279, 116, 'TfmvExplorer.mipDBMerge.Hint', true, 'Слить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10281, 116, 'TfmvExplorer.mipDBAutoEdit.Caption', true, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10282, 116, 'TfmvExplorer.mipDBAutoEdit.Hint', true, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10283, 116, 'TfmvExplorer.mipDBCachedUpdates.Caption', true, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10284, 116, 'TfmvExplorer.mipDBCachedUpdates.Hint', true, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10285, 116, 'TfmvExplorer.mipRemeberRow.Caption', true, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10286, 116, 'TfmvExplorer.mipRemeberRow.Hint', true, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10287, 116, 'TfmvExplorer.mipStoreData.Caption', true, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10288, 116, 'TfmvExplorer.mipStoreData.Hint', true, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10289, 116, 'TfmvExplorer.mipDBSelectAll.Caption', true, 'Выделить все');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10290, 116, 'TfmvExplorer.mipDBSelectAll.Hint', true, 'Выделить все');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10291, 116, 'TfmvExplorer.mipDBGridProperty.Caption', true, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10292, 116, 'TfmvExplorer.mipDBGridProperty.Hint', true, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10293, 116, 'TfmvExplorer.mipRowInspector.Caption', true, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10294, 116, 'TfmvExplorer.mipRowInspector.Hint', true, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10295, 116, 'TfmvExplorer.mitDBCut.Caption', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10296, 116, 'TfmvExplorer.mitDBCut.Hint', true, 'Вырезать');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10297, 116, 'TfmvExplorer.mitDBPaste.Caption', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10298, 116, 'TfmvExplorer.mitDBPaste.Hint', true, 'Вставить');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10299, 116, 'TfmvExplorer.laNumberToWords.Caption', true, 'Введите число и нажмите Enter!');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10301, 116, 'TfmvExplorer.laEntityCommodID.Caption', true, 'Товар ИД');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10302, 116, 'TfmvExplorer.laKindCommodID1q.Caption', true, 'Вид товара ИД');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10303, 116, 'TfmvExplorer.laEntityCommod.Caption', true, 'Товар');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10304, 116, 'TfmvExplorer.laPriceCommod.Caption', true, 'Цена');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10306, 116, 'TfmvExplorer.tbColorIndexGenerate.Caption', true, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10307, 116, 'TfmvExplorer.tbColorIndexGenerate.Hint', true, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10308, 116, 'TfmvExplorer.tbGenerateColorConsts.Caption', true, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10309, 116, 'TfmvExplorer.tbGenerateColorConsts.Hint', true, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10310, 116, 'TfmvExplorer.tbGenerateColorConstsWithoutIndex.Caption', true, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10311, 116, 'TfmvExplorer.tbGenerateColorConstsWithoutIndex.Hint', true, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10312, 116, 'TfmvExplorer.paFonValueChange.Caption', true, 'Пример');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10313, 116, 'TfmvExplorer.paFonValueChange.Hint', true, 'Цвет фона элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10314, 116, 'TfmvExplorer.paFontValueChange.Hint', true, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10316, 116, 'TfmvExplorer.tbRightsIndexGenerate.Caption', true, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10317, 116, 'TfmvExplorer.tbRightsIndexGenerate.Hint', true, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10318, 116, 'TfmvExplorer.tbGenerateRightsConsts.Caption', true, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10319, 116, 'TfmvExplorer.tbGenerateRightsConsts.Hint', true, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10320, 116, 'TfmvExplorer.tbGenerateRightsConstsWithoutIndex.Caption', true, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10321, 116, 'TfmvExplorer.tbGenerateRightsConstsWithoutIndex.Hint', true, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10323, 116, 'TfmvExplorer.tbNewUser.Caption', true, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10324, 116, 'TfmvExplorer.tbNewUser.Hint', true, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10325, 116, 'TfmvExplorer.tbSetUserPassord.Caption', true, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10326, 116, 'TfmvExplorer.tbSetUserPassord.Hint', true, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10327, 116, 'TfmvExplorer.tbDeleteUser.Caption', true, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10328, 116, 'TfmvExplorer.tbDeleteUser.Hint', true, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10329, 116, 'TfmvExplorer.tbNewSuperUser.Caption', true, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10330, 116, 'TfmvExplorer.tbNewSuperUser.Hint', true, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10331, 116, 'TfmvExplorer.tbGrantSuperUser.Caption', true, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10332, 116, 'TfmvExplorer.tbGrantSuperUser.Hint', true, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10333, 116, 'TfmvExplorer.tbRevokeSuperUser.Caption', true, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10334, 116, 'TfmvExplorer.tbRevokeSuperUser.Hint', true, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10339, 116, 'TfmvExplorer.dcbUsersNote.EditText', true, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10340, 116, 'TfmvExplorer.dcbUsersNote.Text', true, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10351, 116, 'TfmvExplorer.tbGolovolomka15StartPosition.Caption', true, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10352, 116, 'TfmvExplorer.tbGolovolomka15StartPosition.Hint', true, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10353, 116, 'TfmvExplorer.tbGolovolomka15Mix.Caption', true, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10354, 116, 'TfmvExplorer.tbGolovolomka15Mix.Hint', true, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10357, 116, 'TfmvExplorer.nbGolovolomka15MixCount.Hint', true, 'Сколько ходов перемешивать?');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10360, 116, 'TfmvExplorer.nbGolovolomka15HodPause.Hint', true, 'Пауза при перемешивании в миллисекундах');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10361, 116, 'TfmvExplorer.aRightsIndexGenerate.Caption', true, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10362, 116, 'TfmvExplorer.aRightsIndexGenerate.Hint', true, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10363, 116, 'TfmvExplorer.aNewUser.Caption', true, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10364, 116, 'TfmvExplorer.aNewUser.Hint', true, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10365, 116, 'TfmvExplorer.aSetUserPassord.Caption', true, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10366, 116, 'TfmvExplorer.aSetUserPassord.Hint', true, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10367, 116, 'TfmvExplorer.aDeleteUser.Caption', true, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10368, 116, 'TfmvExplorer.aDeleteUser.Hint', true, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10369, 116, 'TfmvExplorer.aColorIndexGenerate.Caption', true, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10370, 116, 'TfmvExplorer.aColorIndexGenerate.Hint', true, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10371, 116, 'TfmvExplorer.aGenerateColorConsts.Caption', true, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10372, 116, 'TfmvExplorer.aGenerateColorConsts.Hint', true, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10373, 116, 'TfmvExplorer.aGenerateColorConstsWithoutIndex.Caption', true, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10374, 116, 'TfmvExplorer.aGenerateColorConstsWithoutIndex.Hint', true, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10375, 116, 'TfmvExplorer.aNewSuperUser.Caption', true, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10376, 116, 'TfmvExplorer.aNewSuperUser.Hint', true, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10377, 116, 'TfmvExplorer.aGrantSuperUser.Caption', true, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10378, 116, 'TfmvExplorer.aGrantSuperUser.Hint', true, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10379, 116, 'TfmvExplorer.aRevokeSuperUser.Caption', true, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10380, 116, 'TfmvExplorer.aRevokeSuperUser.Hint', true, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10381, 116, 'TfmvExplorer.aGenerateRightsConsts.Caption', true, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10382, 116, 'TfmvExplorer.aGenerateRightsConsts.Hint', true, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10383, 116, 'TfmvExplorer.aGenerateRightsConstsWithoutIndex.Caption', true, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10384, 116, 'TfmvExplorer.aGenerateRightsConstsWithoutIndex.Hint', true, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10385, 116, 'TfmvExplorer.aGolovolomka15StartPosition.Caption', true, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10386, 116, 'TfmvExplorer.aGolovolomka15StartPosition.Hint', true, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10387, 116, 'TfmvExplorer.aGolovolomka15Mix.Caption', true, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Language" ("EntityID", "KindID", "Entity", "Actual", "Original") VALUES (10388, 116, 'TfmvExplorer.aGolovolomka15Mix.Hint', true, 'Головоломка 15');


--
-- Data for Name: LanguageKind; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."LanguageKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (115, NULL, 'Язык', true);
INSERT INTO "NewNavadvipa"."LanguageKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (117, 115, 'TForm2', true);
INSERT INTO "NewNavadvipa"."LanguageKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (116, 115, 'TfmvExplorer', true);


--
-- Data for Name: Languages; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (2, 'EN-US', 'English');
INSERT INTO "NewNavadvipa"."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (3, 'ES-ES', 'Espanol');
INSERT INTO "NewNavadvipa"."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (4, 'CS-CZ', 'Cesky');
INSERT INTO "NewNavadvipa"."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (5, 'PT-BR', 'Portugues');
INSERT INTO "NewNavadvipa"."Languages" ("LanguagesID", "LanguagesStringID", "Languages") VALUES (1, 'RU-RU', 'Русский');


--
-- Data for Name: Rights; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (152, 91, 'Редактирование пользователей', true, 'UserEdit', 0);
INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (177, 91, 'Редактировать права', true, 'RightsEdit', 1);
INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (154, 91, 'Редактировать товар', true, 'CommodEdit', 2);
INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (176, 91, 'Редактировать цвета', true, 'ColorEdit', 3);
INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (153, 91, 'Ссоздавать роли', true, 'RoleEdit', 4);
INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (174, 96, ' Право счет фактура', true, 'SchetFactura', 5);
INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (186, 96, 'ffddrf', true, NULL, 0);
INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (3405, 91, 'Редактировать языки программы', true, 'LanguagesEdit', 6);
INSERT INTO "NewNavadvipa"."Rights" ("EntityID", "KindID", "Entity", "Actual", "Literal", "VectorIndex") VALUES (3406, 91, 'Редактировать строки для разных языков программы', true, 'LanguageStringEdit', 7);


--
-- Data for Name: RightsKind; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."RightsKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (91, 79, 'Управление', true);
INSERT INTO "NewNavadvipa"."RightsKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (96, 79, 'Торговля', true);
INSERT INTO "NewNavadvipa"."RightsKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (79, 0, 'Права', true);


--
-- Data for Name: Role; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (155, 82, 'Менеджер', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (156, 82, 'Стажер', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (157, 82, 'Кассир', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (160, 92, 'Кассир', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (161, 92, 'Приёмщик', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (162, 82, 'Кладовщик', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (166, 92, 'Мастер', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (169, 93, 'Rere', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (170, 93, 'Куку', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (171, 93, 'Малина', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (172, 94, 'Миша', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (173, 93, 'Калина', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (175, 82, 'Каменщик', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (167, 93, 'Турагент', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (168, 93, 'Турист', true);
INSERT INTO "NewNavadvipa"."Role" ("EntityID", "KindID", "Entity", "Actual") VALUES (187, 80, 'Программист', true);


--
-- Data for Name: RoleKind; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (82, 80, 'Торговля', true);
INSERT INTO "NewNavadvipa"."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (92, 80, 'Сервисный центр', true);
INSERT INTO "NewNavadvipa"."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (94, 93, 'Михаил Светлов', true);
INSERT INTO "NewNavadvipa"."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (93, 80, 'Туризм', true);
INSERT INTO "NewNavadvipa"."RoleKind" ("KindID", "ParentID", "Kind", "Actual") VALUES (80, 0, 'Роли', true);


--
-- Data for Name: RoleRights; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (15, 166, 174);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (18, 160, 174);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (19, 187, 152);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (20, 187, 177);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (21, 187, 154);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (22, 187, 176);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (23, 187, 153);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (24, 187, 174);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (25, 187, 186);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (26, 187, 3405);
INSERT INTO "NewNavadvipa"."RoleRights" ("RoleRightsID", "RoleID", "EntityID") VALUES (27, 187, 3406);


--
-- Data for Name: Translate; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27019, 10080, 3, 'Проводник "Джая Шрила Прабхупада"');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27020, 10080, 5, 'Проводник "Джая Шрила Прабхупада"');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27017, 10080, 4, 'Проводник "Джая Шрила Прабхупада"');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27018, 10080, 2, 'Проводник "Джая Шрила Прабхупада"');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27033, 10084, 4, 'рубль');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27034, 10084, 2, 'рубль');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27035, 10084, 3, 'рубль');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27036, 10084, 5, 'рубль');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27037, 10085, 4, 'рубля');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27038, 10085, 2, 'рубля');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27039, 10085, 3, 'рубля');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27040, 10085, 5, 'рубля');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27041, 10086, 4, 'рублей');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27042, 10086, 2, 'рублей');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27043, 10086, 3, 'рублей');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27044, 10086, 5, 'рублей');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27045, 10087, 4, 'копейка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27046, 10087, 2, 'копейка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27047, 10087, 3, 'копейка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27048, 10087, 5, 'копейка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27049, 10088, 4, 'копейки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27050, 10088, 2, 'копейки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27051, 10088, 3, 'копейки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27052, 10088, 5, 'копейки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27053, 10089, 4, 'копеек');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27054, 10089, 2, 'копеек');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27055, 10089, 3, 'копеек');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27056, 10089, 5, 'копеек');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27057, 10090, 4, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27058, 10090, 2, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27059, 10090, 3, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27060, 10090, 5, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27061, 10091, 4, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27062, 10091, 2, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27063, 10091, 3, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27064, 10091, 5, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27065, 10092, 4, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27066, 10092, 2, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27067, 10092, 3, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27068, 10092, 5, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27069, 10093, 4, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27070, 10093, 2, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27071, 10093, 3, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27072, 10093, 5, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27073, 10094, 4, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27074, 10094, 2, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27075, 10094, 3, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27076, 10094, 5, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27077, 10095, 4, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27078, 10095, 2, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27079, 10095, 3, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27080, 10095, 5, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27081, 10096, 4, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27082, 10096, 2, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27083, 10096, 3, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27084, 10096, 5, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27085, 10097, 4, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27086, 10097, 2, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27087, 10097, 3, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27088, 10097, 5, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27089, 10098, 4, 'База данных');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27090, 10098, 2, 'База данных');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27091, 10098, 3, 'База данных');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27092, 10098, 5, 'База данных');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27097, 10100, 4, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27098, 10100, 2, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27099, 10100, 3, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27100, 10100, 5, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27101, 10101, 4, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27102, 10101, 2, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27103, 10101, 3, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27104, 10101, 5, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27105, 10102, 4, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27106, 10102, 2, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27107, 10102, 3, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27108, 10102, 5, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27109, 10103, 4, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27110, 10103, 2, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27111, 10103, 3, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27112, 10103, 5, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27113, 10104, 4, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27114, 10104, 2, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27115, 10104, 3, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27116, 10104, 5, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27117, 10105, 4, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27118, 10105, 2, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27119, 10105, 3, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27120, 10105, 5, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27121, 10106, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27122, 10106, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27123, 10106, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27124, 10106, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27125, 10107, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27126, 10107, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27127, 10107, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27128, 10107, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27129, 10108, 4, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27130, 10108, 2, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27131, 10108, 3, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27132, 10108, 5, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27133, 10109, 4, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27134, 10109, 2, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27135, 10109, 3, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27136, 10109, 5, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27137, 10110, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27138, 10110, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27139, 10110, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27140, 10110, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27141, 10111, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27142, 10111, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27143, 10111, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27144, 10111, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27145, 10112, 4, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27146, 10112, 2, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27147, 10112, 3, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27148, 10112, 5, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27149, 10113, 4, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27150, 10113, 2, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27151, 10113, 3, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27152, 10113, 5, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27153, 10114, 4, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27154, 10114, 2, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27155, 10114, 3, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27156, 10114, 5, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27157, 10115, 4, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27158, 10115, 2, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27159, 10115, 3, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27160, 10115, 5, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27161, 10116, 4, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27162, 10116, 2, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27163, 10116, 3, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27164, 10116, 5, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27165, 10117, 4, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27166, 10117, 2, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27167, 10117, 3, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27168, 10117, 5, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27169, 10118, 4, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27170, 10118, 2, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27171, 10118, 3, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27172, 10118, 5, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27173, 10119, 4, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27174, 10119, 2, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27175, 10119, 3, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27176, 10119, 5, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27177, 10120, 4, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27178, 10120, 2, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27179, 10120, 3, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27180, 10120, 5, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27181, 10121, 4, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27182, 10121, 2, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27183, 10121, 3, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27184, 10121, 5, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27185, 10122, 4, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27186, 10122, 2, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27187, 10122, 3, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27188, 10122, 5, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27189, 10123, 4, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27190, 10123, 2, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27191, 10123, 3, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27192, 10123, 5, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27193, 10124, 4, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27194, 10124, 2, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27195, 10124, 3, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27196, 10124, 5, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27197, 10125, 4, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27198, 10125, 2, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27199, 10125, 3, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27200, 10125, 5, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27201, 10126, 4, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27202, 10126, 2, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27203, 10126, 3, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27204, 10126, 5, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27205, 10127, 4, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27206, 10127, 2, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27207, 10127, 3, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27208, 10127, 5, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27209, 10128, 4, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27210, 10128, 2, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27211, 10128, 3, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27212, 10128, 5, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27213, 10129, 4, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27214, 10129, 2, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27215, 10129, 3, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27216, 10129, 5, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27217, 10130, 4, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27218, 10130, 2, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27219, 10130, 3, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27220, 10130, 5, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27221, 10131, 4, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27222, 10131, 2, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27223, 10131, 3, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27224, 10131, 5, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27225, 10132, 4, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27226, 10132, 2, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27227, 10132, 3, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27228, 10132, 5, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27229, 10133, 4, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27230, 10133, 2, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27231, 10133, 3, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27232, 10133, 5, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27233, 10134, 4, 'Номер веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27234, 10134, 2, 'Номер веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27235, 10134, 3, 'Номер веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27236, 10134, 5, 'Номер веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27237, 10135, 4, 'Настройка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27238, 10135, 2, 'Настройка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27239, 10135, 3, 'Настройка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27240, 10135, 5, 'Настройка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27241, 10136, 4, 'Настройка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27242, 10136, 2, 'Настройка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27243, 10136, 3, 'Настройка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27244, 10136, 5, 'Настройка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27249, 10138, 4, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27250, 10138, 2, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27251, 10138, 3, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27252, 10138, 5, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27253, 10139, 4, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27254, 10139, 2, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27255, 10139, 3, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27256, 10139, 5, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27257, 10140, 4, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27258, 10140, 2, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27259, 10140, 3, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27260, 10140, 5, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27261, 10141, 4, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27262, 10141, 2, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27263, 10141, 3, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27264, 10141, 5, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27265, 10142, 4, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27266, 10142, 2, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27267, 10142, 3, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27268, 10142, 5, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27269, 10143, 4, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27270, 10143, 2, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27271, 10143, 3, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27272, 10143, 5, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27273, 10144, 4, 'Обычный');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27274, 10144, 2, 'Обычный');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27275, 10144, 3, 'Обычный');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27276, 10144, 5, 'Обычный');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27277, 10145, 4, 'Тип Enter');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27278, 10145, 2, 'Тип Enter');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27279, 10145, 3, 'Тип Enter');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27280, 10145, 5, 'Тип Enter');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27281, 10146, 4, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27282, 10146, 2, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27283, 10146, 3, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27284, 10146, 5, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27285, 10147, 4, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27286, 10147, 2, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27287, 10147, 3, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27288, 10147, 5, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27289, 10148, 4, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27290, 10148, 2, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27291, 10148, 3, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27292, 10148, 5, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27293, 10149, 4, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27294, 10149, 2, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27295, 10149, 3, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27296, 10149, 5, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27297, 10150, 4, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27298, 10150, 2, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27299, 10150, 3, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27300, 10150, 5, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27301, 10151, 4, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27302, 10151, 2, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27303, 10151, 3, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27304, 10151, 5, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27309, 10153, 4, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27310, 10153, 2, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27311, 10153, 3, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27312, 10153, 5, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27313, 10154, 4, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27314, 10154, 2, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27315, 10154, 3, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27316, 10154, 5, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27317, 10155, 4, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27318, 10155, 2, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27319, 10155, 3, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27320, 10155, 5, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27321, 10156, 4, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27322, 10156, 2, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27323, 10156, 3, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27324, 10156, 5, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27325, 10157, 4, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27326, 10157, 2, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27327, 10157, 3, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27328, 10157, 5, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27329, 10158, 4, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27330, 10158, 2, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27331, 10158, 3, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27332, 10158, 5, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27333, 10159, 4, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27334, 10159, 2, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27335, 10159, 3, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27336, 10159, 5, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27337, 10160, 4, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27338, 10160, 2, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27339, 10160, 3, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27340, 10160, 5, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27345, 10162, 4, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27346, 10162, 2, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27347, 10162, 3, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27348, 10162, 5, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27349, 10163, 4, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27350, 10163, 2, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27351, 10163, 3, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27352, 10163, 5, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27353, 10164, 4, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27354, 10164, 2, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27355, 10164, 3, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27356, 10164, 5, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27357, 10165, 4, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27358, 10165, 2, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27359, 10165, 3, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27360, 10165, 5, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27361, 10166, 4, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27362, 10166, 2, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27363, 10166, 3, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27364, 10166, 5, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27365, 10167, 4, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27366, 10167, 2, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27367, 10167, 3, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27368, 10167, 5, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27369, 10168, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27370, 10168, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27371, 10168, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27372, 10168, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27373, 10169, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27374, 10169, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27375, 10169, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27376, 10169, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27377, 10170, 4, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27378, 10170, 2, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27379, 10170, 3, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27380, 10170, 5, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27381, 10171, 4, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27382, 10171, 2, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27383, 10171, 3, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27384, 10171, 5, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27385, 10172, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27386, 10172, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27387, 10172, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27388, 10172, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27389, 10173, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27390, 10173, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27391, 10173, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27392, 10173, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27393, 10174, 4, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27394, 10174, 2, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27395, 10174, 3, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27396, 10174, 5, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27397, 10175, 4, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27398, 10175, 2, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27399, 10175, 3, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27400, 10175, 5, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27401, 10176, 4, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27402, 10176, 2, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27403, 10176, 3, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27404, 10176, 5, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27405, 10177, 4, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27406, 10177, 2, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27407, 10177, 3, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27408, 10177, 5, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27409, 10178, 4, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27410, 10178, 2, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27411, 10178, 3, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27412, 10178, 5, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27413, 10179, 4, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27414, 10179, 2, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27415, 10179, 3, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27416, 10179, 5, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27417, 10180, 4, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27418, 10180, 2, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27419, 10180, 3, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27420, 10180, 5, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27421, 10181, 4, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27422, 10181, 2, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27423, 10181, 3, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27424, 10181, 5, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27425, 10182, 4, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27426, 10182, 2, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27427, 10182, 3, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27428, 10182, 5, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27429, 10183, 4, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27430, 10183, 2, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27431, 10183, 3, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27432, 10183, 5, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27433, 10184, 4, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27434, 10184, 2, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27435, 10184, 3, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27436, 10184, 5, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27437, 10185, 4, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27438, 10185, 2, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27439, 10185, 3, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27440, 10185, 5, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27441, 10186, 4, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27442, 10186, 2, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27443, 10186, 3, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27444, 10186, 5, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27445, 10187, 4, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27446, 10187, 2, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27447, 10187, 3, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27448, 10187, 5, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27449, 10188, 4, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27450, 10188, 2, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27451, 10188, 3, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27452, 10188, 5, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27453, 10189, 4, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27454, 10189, 2, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27455, 10189, 3, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27456, 10189, 5, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27457, 10190, 4, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27458, 10190, 2, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27459, 10190, 3, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27460, 10190, 5, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27461, 10191, 4, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27462, 10191, 2, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27463, 10191, 3, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27464, 10191, 5, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27465, 10192, 4, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27466, 10192, 2, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27467, 10192, 3, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27468, 10192, 5, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27469, 10193, 4, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27470, 10193, 2, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27471, 10193, 3, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27472, 10193, 5, 'Печать ветки дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27473, 10194, 4, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27474, 10194, 2, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27475, 10194, 3, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27476, 10194, 5, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27477, 10195, 4, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27478, 10195, 2, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27479, 10195, 3, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27480, 10195, 5, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27481, 10196, 4, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27482, 10196, 2, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27483, 10196, 3, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27484, 10196, 5, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27485, 10197, 4, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27486, 10197, 2, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27487, 10197, 3, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27488, 10197, 5, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27489, 10198, 4, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27490, 10198, 2, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27491, 10198, 3, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27492, 10198, 5, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27493, 10199, 4, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27494, 10199, 2, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27495, 10199, 3, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27496, 10199, 5, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27497, 10200, 4, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27498, 10200, 2, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27499, 10200, 3, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27500, 10200, 5, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27501, 10201, 4, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27502, 10201, 2, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27503, 10201, 3, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27504, 10201, 5, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27505, 10202, 4, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27506, 10202, 2, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27507, 10202, 3, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27508, 10202, 5, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27509, 10203, 4, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27510, 10203, 2, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27511, 10203, 3, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27512, 10203, 5, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27513, 10204, 4, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27514, 10204, 2, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27515, 10204, 3, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27516, 10204, 5, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27517, 10205, 4, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27518, 10205, 2, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27519, 10205, 3, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27520, 10205, 5, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27521, 10206, 4, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27522, 10206, 2, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27523, 10206, 3, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27524, 10206, 5, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27525, 10207, 4, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27526, 10207, 2, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27527, 10207, 3, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27528, 10207, 5, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27529, 10208, 4, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27530, 10208, 2, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27531, 10208, 3, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27532, 10208, 5, 'Предыдущая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27533, 10209, 4, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27534, 10209, 2, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27535, 10209, 3, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27536, 10209, 5, 'Предыдущая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27537, 10210, 4, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27538, 10210, 2, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27539, 10210, 3, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27540, 10210, 5, 'Следующая веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27541, 10211, 4, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27542, 10211, 2, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27543, 10211, 3, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27544, 10211, 5, 'Следующая
веточка');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27545, 10212, 4, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27546, 10212, 2, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27547, 10212, 3, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27548, 10212, 5, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27549, 10213, 4, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27550, 10213, 2, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27551, 10213, 3, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27552, 10213, 5, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27553, 10214, 4, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27554, 10214, 2, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27555, 10214, 3, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27556, 10214, 5, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27557, 10215, 4, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27558, 10215, 2, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27559, 10215, 3, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27560, 10215, 5, 'Очистить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27561, 10216, 4, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27562, 10216, 2, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27563, 10216, 3, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27564, 10216, 5, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27565, 10217, 4, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27566, 10217, 2, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27567, 10217, 3, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27568, 10217, 5, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27569, 10218, 4, 'База данных');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27570, 10218, 2, 'База данных');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27571, 10218, 3, 'База данных');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27572, 10218, 5, 'База данных');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27573, 10219, 4, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27574, 10219, 2, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27575, 10219, 3, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27576, 10219, 5, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27577, 10220, 4, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27578, 10220, 2, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27579, 10220, 3, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27580, 10220, 5, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27581, 10221, 4, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27582, 10221, 2, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27583, 10221, 3, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27584, 10221, 5, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27585, 10222, 4, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27586, 10222, 2, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27587, 10222, 3, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27588, 10222, 5, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27589, 10223, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27590, 10223, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27591, 10223, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27592, 10223, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27593, 10224, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27594, 10224, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27595, 10224, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27596, 10224, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27597, 10225, 4, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27598, 10225, 2, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27599, 10225, 3, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27600, 10225, 5, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27601, 10226, 4, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27602, 10226, 2, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27603, 10226, 3, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27604, 10226, 5, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27605, 10227, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27606, 10227, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27607, 10227, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27608, 10227, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27609, 10228, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27610, 10228, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27611, 10228, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27612, 10228, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27613, 10229, 4, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27614, 10229, 2, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27615, 10229, 3, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27616, 10229, 5, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27617, 10230, 4, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27618, 10230, 2, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27619, 10230, 3, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27620, 10230, 5, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27621, 10231, 4, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27622, 10231, 2, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27623, 10231, 3, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27624, 10231, 5, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27625, 10232, 4, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27626, 10232, 2, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27627, 10232, 3, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27628, 10232, 5, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27629, 10233, 4, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27630, 10233, 2, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27631, 10233, 3, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27632, 10233, 5, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27633, 10234, 4, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27634, 10234, 2, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27635, 10234, 3, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27636, 10234, 5, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27637, 10235, 4, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27638, 10235, 2, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27639, 10235, 3, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27640, 10235, 5, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27641, 10236, 4, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27642, 10236, 2, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27643, 10236, 3, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27644, 10236, 5, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27645, 10237, 4, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27646, 10237, 2, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27647, 10237, 3, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27648, 10237, 5, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27649, 10238, 4, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27650, 10238, 2, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27651, 10238, 3, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27652, 10238, 5, 'Обновить ветку дерева');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27653, 10239, 4, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27654, 10239, 2, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27655, 10239, 3, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27656, 10239, 5, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27657, 10240, 4, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27658, 10240, 2, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27659, 10240, 3, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27660, 10240, 5, 'Обновить всё дерево');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27661, 10241, 4, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27662, 10241, 2, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27663, 10241, 3, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27664, 10241, 5, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27665, 10242, 4, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27666, 10242, 2, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27667, 10242, 3, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27668, 10242, 5, 'Инвертировать актуальность веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27669, 10243, 4, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27670, 10243, 2, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27671, 10243, 3, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27672, 10243, 5, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27673, 10244, 4, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27674, 10244, 2, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27675, 10244, 3, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27676, 10244, 5, 'Только актуальные веточки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27677, 10245, 4, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27678, 10245, 2, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27679, 10245, 3, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27680, 10245, 5, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27681, 10246, 4, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27682, 10246, 2, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27683, 10246, 3, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27684, 10246, 5, 'Сквозной просмотр');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27685, 10247, 4, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27686, 10247, 2, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27687, 10247, 3, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27688, 10247, 5, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27689, 10248, 4, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27690, 10248, 2, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27691, 10248, 3, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27692, 10248, 5, 'Найти');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27693, 10249, 4, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27694, 10249, 2, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27695, 10249, 3, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27696, 10249, 5, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27697, 10250, 4, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27698, 10250, 2, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27699, 10250, 3, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27700, 10250, 5, 'Найти далее');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27701, 10251, 4, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27702, 10251, 2, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27703, 10251, 3, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27704, 10251, 5, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27705, 10252, 4, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27706, 10252, 2, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27707, 10252, 3, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27708, 10252, 5, 'Прервать поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27709, 10253, 4, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27710, 10253, 2, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27711, 10253, 3, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27712, 10253, 5, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27713, 10254, 4, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27714, 10254, 2, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27715, 10254, 3, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27716, 10254, 5, 'Быстрый поиск');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27717, 10255, 4, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27718, 10255, 2, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27719, 10255, 3, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27720, 10255, 5, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27721, 10256, 4, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27722, 10256, 2, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27723, 10256, 3, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27724, 10256, 5, 'Удалить фильтр поиска');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27725, 10257, 4, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27726, 10257, 2, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27727, 10257, 3, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27728, 10257, 5, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27729, 10258, 4, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27730, 10258, 2, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27731, 10258, 3, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27732, 10258, 5, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27733, 10259, 4, 'Свойства');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27734, 10259, 2, 'Свойства');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27735, 10259, 3, 'Свойства');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27736, 10259, 5, 'Свойства');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27737, 10260, 4, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27738, 10260, 2, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27739, 10260, 3, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27740, 10260, 5, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27741, 10261, 4, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27742, 10261, 2, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27743, 10261, 3, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27744, 10261, 5, 'Горячие клавиши');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27745, 10262, 4, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27746, 10262, 2, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27747, 10262, 3, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27748, 10262, 5, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27749, 10263, 4, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27750, 10263, 2, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27751, 10263, 3, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27752, 10263, 5, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27753, 10264, 4, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27754, 10264, 2, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27755, 10264, 3, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27756, 10264, 5, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27757, 10265, 4, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27758, 10265, 2, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27759, 10265, 3, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27760, 10265, 5, 'Слить главное меню');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27761, 10266, 4, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27762, 10266, 2, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27763, 10266, 3, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27764, 10266, 5, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27765, 10267, 4, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27766, 10267, 2, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27767, 10267, 3, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27768, 10267, 5, 'Аварийное закрытие окна');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27769, 10268, 4, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27770, 10268, 2, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27771, 10268, 3, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27772, 10268, 5, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27773, 10269, 4, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27774, 10269, 2, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27775, 10269, 3, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27776, 10269, 5, 'Пустой выбор');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27777, 10270, 4, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27778, 10270, 2, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27779, 10270, 3, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27780, 10270, 5, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27781, 10271, 4, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27782, 10271, 2, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27783, 10271, 3, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27784, 10271, 5, 'Подготовить язык');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27785, 10272, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27786, 10272, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27787, 10272, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27788, 10272, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27789, 10273, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27790, 10273, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27791, 10273, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27792, 10273, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27793, 10274, 4, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27794, 10274, 2, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27795, 10274, 3, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27796, 10274, 5, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27797, 10275, 4, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27798, 10275, 2, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27799, 10275, 3, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27800, 10275, 5, 'Копировать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27801, 10276, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27802, 10276, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27803, 10276, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27804, 10276, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27805, 10277, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27806, 10277, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27807, 10277, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27808, 10277, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27809, 10278, 4, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27810, 10278, 2, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27811, 10278, 3, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27812, 10278, 5, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27813, 10279, 4, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27814, 10279, 2, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27815, 10279, 3, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27816, 10279, 5, 'Слить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27821, 10281, 4, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27822, 10281, 2, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27823, 10281, 3, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27824, 10281, 5, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27825, 10282, 4, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27826, 10282, 2, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27827, 10282, 3, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27828, 10282, 5, 'Авто-редактирование таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27829, 10283, 4, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27830, 10283, 2, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27831, 10283, 3, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27832, 10283, 5, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27833, 10284, 4, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27834, 10284, 2, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27835, 10284, 3, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27836, 10284, 5, 'Кэшировать данные');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27837, 10285, 4, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27838, 10285, 2, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27839, 10285, 3, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27840, 10285, 5, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27841, 10286, 4, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27842, 10286, 2, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27843, 10286, 3, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27844, 10286, 5, 'Запомнить строку');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27845, 10287, 4, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27846, 10287, 2, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27847, 10287, 3, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27848, 10287, 5, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27849, 10288, 4, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27850, 10288, 2, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27851, 10288, 3, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27852, 10288, 5, 'Установить поля строк');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27853, 10289, 4, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27854, 10289, 2, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27855, 10289, 3, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27856, 10289, 5, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27857, 10290, 4, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27858, 10290, 2, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27859, 10290, 3, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27860, 10290, 5, 'Выделить все');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27861, 10291, 4, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27862, 10291, 2, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27863, 10291, 3, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27864, 10291, 5, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27865, 10292, 4, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27866, 10292, 2, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27867, 10292, 3, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27868, 10292, 5, 'Свойства таблицы');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27869, 10293, 4, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27870, 10293, 2, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27871, 10293, 3, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27872, 10293, 5, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27873, 10294, 4, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27874, 10294, 2, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27875, 10294, 3, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27876, 10294, 5, 'Инспектор строки');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27877, 10295, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27878, 10295, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27879, 10295, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27880, 10295, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27881, 10296, 4, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27882, 10296, 2, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27883, 10296, 3, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27884, 10296, 5, 'Вырезать');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27885, 10297, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27886, 10297, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27887, 10297, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27888, 10297, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27889, 10298, 4, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27890, 10298, 2, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27891, 10298, 3, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27892, 10298, 5, 'Вставить');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27893, 10299, 4, 'Введите число и нажмите Enter!');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27894, 10299, 2, 'Введите число и нажмите Enter!');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27895, 10299, 3, 'Введите число и нажмите Enter!');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27896, 10299, 5, 'Введите число и нажмите Enter!');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27901, 10301, 4, 'Товар ИД');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27902, 10301, 2, 'Товар ИД');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27903, 10301, 3, 'Товар ИД');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27904, 10301, 5, 'Товар ИД');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27905, 10302, 4, 'Вид товара ИД');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27906, 10302, 2, 'Вид товара ИД');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27907, 10302, 3, 'Вид товара ИД');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27908, 10302, 5, 'Вид товара ИД');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27909, 10303, 4, 'Товар');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27910, 10303, 2, 'Товар');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27911, 10303, 3, 'Товар');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27912, 10303, 5, 'Товар');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27913, 10304, 4, 'Цена');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27914, 10304, 2, 'Цена');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27915, 10304, 3, 'Цена');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27916, 10304, 5, 'Цена');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27921, 10306, 4, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27922, 10306, 2, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27923, 10306, 3, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27924, 10306, 5, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27925, 10307, 4, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27926, 10307, 2, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27927, 10307, 3, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27928, 10307, 5, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27929, 10308, 4, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27930, 10308, 2, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27931, 10308, 3, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27932, 10308, 5, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27933, 10309, 4, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27934, 10309, 2, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27935, 10309, 3, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27936, 10309, 5, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27937, 10310, 4, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27938, 10310, 2, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27939, 10310, 3, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27940, 10310, 5, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27941, 10311, 4, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27942, 10311, 2, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27943, 10311, 3, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27944, 10311, 5, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27945, 10312, 4, 'Пример');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27946, 10312, 2, 'Пример');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27947, 10312, 3, 'Пример');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27948, 10312, 5, 'Пример');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27949, 10313, 4, 'Цвет фона элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27950, 10313, 2, 'Цвет фона элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27951, 10313, 3, 'Цвет фона элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27952, 10313, 5, 'Цвет фона элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27953, 10314, 4, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27954, 10314, 2, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27955, 10314, 3, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27956, 10314, 5, 'Цвет шрифта элементов ввода диапазонов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27961, 10316, 4, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27962, 10316, 2, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27963, 10316, 3, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27964, 10316, 5, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27965, 10317, 4, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27966, 10317, 2, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27967, 10317, 3, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27968, 10317, 5, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27969, 10318, 4, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27970, 10318, 2, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27971, 10318, 3, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27972, 10318, 5, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27973, 10319, 4, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27974, 10319, 2, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27975, 10319, 3, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27976, 10319, 5, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27977, 10320, 4, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27978, 10320, 2, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27979, 10320, 3, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27980, 10320, 5, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27981, 10321, 4, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27982, 10321, 2, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27983, 10321, 3, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27984, 10321, 5, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27989, 10323, 4, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27990, 10323, 2, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27991, 10323, 3, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27992, 10323, 5, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27993, 10324, 4, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27994, 10324, 2, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27995, 10324, 3, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27996, 10324, 5, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27997, 10325, 4, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27998, 10325, 2, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (27999, 10325, 3, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28000, 10325, 5, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28001, 10326, 4, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28002, 10326, 2, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28003, 10326, 3, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28004, 10326, 5, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28005, 10327, 4, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28006, 10327, 2, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28007, 10327, 3, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28008, 10327, 5, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28009, 10328, 4, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28010, 10328, 2, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28011, 10328, 3, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28012, 10328, 5, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28013, 10329, 4, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28014, 10329, 2, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28015, 10329, 3, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28016, 10329, 5, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28017, 10330, 4, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28018, 10330, 2, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28019, 10330, 3, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28020, 10330, 5, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28021, 10331, 4, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28022, 10331, 2, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28023, 10331, 3, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28024, 10331, 5, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28025, 10332, 4, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28026, 10332, 2, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28027, 10332, 3, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28028, 10332, 5, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28029, 10333, 4, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28030, 10333, 2, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28031, 10333, 3, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28032, 10333, 5, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28033, 10334, 4, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28034, 10334, 2, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28035, 10334, 3, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28036, 10334, 5, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28053, 10339, 4, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28054, 10339, 2, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28055, 10339, 3, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28056, 10339, 5, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28057, 10340, 4, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28058, 10340, 2, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28059, 10340, 3, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28060, 10340, 5, 'Шримад Бхагаватам');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28101, 10351, 4, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28102, 10351, 2, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28103, 10351, 3, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28104, 10351, 5, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28105, 10352, 4, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28106, 10352, 2, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28107, 10352, 3, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28108, 10352, 5, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28109, 10353, 4, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28110, 10353, 2, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28111, 10353, 3, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28112, 10353, 5, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28113, 10354, 4, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28114, 10354, 2, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28115, 10354, 3, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28116, 10354, 5, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28125, 10357, 4, 'Сколько ходов перемешивать?');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28126, 10357, 2, 'Сколько ходов перемешивать?');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28127, 10357, 3, 'Сколько ходов перемешивать?');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28128, 10357, 5, 'Сколько ходов перемешивать?');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28137, 10360, 4, 'Пауза при перемешивании в миллисекундах');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28138, 10360, 2, 'Пауза при перемешивании в миллисекундах');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28139, 10360, 3, 'Пауза при перемешивании в миллисекундах');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28140, 10360, 5, 'Пауза при перемешивании в миллисекундах');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28141, 10361, 4, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28142, 10361, 2, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28143, 10361, 3, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28144, 10361, 5, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28145, 10362, 4, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28146, 10362, 2, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28147, 10362, 3, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28148, 10362, 5, 'Генерация индексов прав');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28149, 10363, 4, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28150, 10363, 2, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28151, 10363, 3, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28152, 10363, 5, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28153, 10364, 4, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28154, 10364, 2, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28155, 10364, 3, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28156, 10364, 5, 'Создать пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28157, 10365, 4, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28158, 10365, 2, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28159, 10365, 3, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28160, 10365, 5, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28161, 10366, 4, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28162, 10366, 2, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28163, 10366, 3, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28164, 10366, 5, 'Задать пароль пользователю');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28165, 10367, 4, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28166, 10367, 2, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28167, 10367, 3, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28168, 10367, 5, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28169, 10368, 4, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28170, 10368, 2, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28171, 10368, 3, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28172, 10368, 5, 'Удалить пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28173, 10369, 4, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28174, 10369, 2, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28175, 10369, 3, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28176, 10369, 5, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28177, 10370, 4, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28178, 10370, 2, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28179, 10370, 3, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28180, 10370, 5, 'Генерация индексов цветов');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28181, 10371, 4, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28182, 10371, 2, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28183, 10371, 3, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28184, 10371, 5, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28185, 10372, 4, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28186, 10372, 2, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28187, 10372, 3, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28188, 10372, 5, 'Создание списка констант цветов для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28189, 10373, 4, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28190, 10373, 2, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28191, 10373, 3, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28192, 10373, 5, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28193, 10374, 4, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28194, 10374, 2, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28195, 10374, 3, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28196, 10374, 5, 'Создание списка констант цветов для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28197, 10375, 4, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28198, 10375, 2, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28199, 10375, 3, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28200, 10375, 5, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28201, 10376, 4, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28202, 10376, 2, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28203, 10376, 3, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28204, 10376, 5, 'Создать супер пользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28205, 10377, 4, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28206, 10377, 2, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28207, 10377, 3, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28208, 10377, 5, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28209, 10378, 4, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28210, 10378, 2, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28211, 10378, 3, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28212, 10378, 5, 'Дать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28213, 10379, 4, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28214, 10379, 2, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28215, 10379, 3, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28216, 10379, 5, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28217, 10380, 4, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28218, 10380, 2, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28219, 10380, 3, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28220, 10380, 5, 'Забрать права суперпользователя');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28221, 10381, 4, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28222, 10381, 2, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28223, 10381, 3, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28224, 10381, 5, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28225, 10382, 4, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28226, 10382, 2, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28227, 10382, 3, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28228, 10382, 5, 'Создание списка констант прав для *.cpp');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28229, 10383, 4, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28230, 10383, 2, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28231, 10383, 3, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28232, 10383, 5, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28233, 10384, 4, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28234, 10384, 2, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28235, 10384, 3, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28236, 10384, 5, 'Создание списка констант прав для *.h');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28237, 10385, 4, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28238, 10385, 2, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28239, 10385, 3, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28240, 10385, 5, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28241, 10386, 4, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28242, 10386, 2, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28243, 10386, 3, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28244, 10386, 5, 'Стартовая позиция');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28245, 10387, 4, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28246, 10387, 2, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28247, 10387, 3, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28248, 10387, 5, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28249, 10388, 4, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28250, 10388, 2, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28251, 10388, 3, 'Головоломка 15');
INSERT INTO "NewNavadvipa"."Translate" ("TranslateID", "LanguageID", "LanguagesID", "Translate") VALUES (28252, 10388, 5, 'Головоломка 15');


--
-- Data for Name: UserReg; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvChangePassword.fmvChangePassword.ini', '\x002c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff1a0000001a00000096010000ce000000060000005461686f6d61080000ff080000000100000000ff0000000000000400000000000000000000000000000000');
INSERT INTO "NewNavadvipa"."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvDBGrid.fmvDBGrid.ini', '\x002c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff82000000820000000802000004020000060000005461686f6d61080000ff080000000100000000ff0000000000000400000000000000000000000000000000');
INSERT INTO "NewNavadvipa"."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvLanguage.fmvLanguage.ini', '\x002c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff45000000ba000000f6040000d5030000060000005461686f6d61080000ff080000000100000000ff0000000000002000000047405860436056604d60000000005980558000000000000041c041e0000054400000464072004540466051407a607b60000041600000000000007a40000000000000000001000000001e00000001000074000000000000004d28000000000000000100000000000101010000000000060000005461686f6d61080000ff08000000010000000000000000060000005461686f6d61080000ff080000000100000000050000ff01010101000500000008000000456e7469747949445e00000000000000010000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e6449445e000000010000000100000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000600000041637475616c4c00000002000000010000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000006000000456e746974790d0100000300000001000000003d000000d0a1d182d180d0bed0bad0bed0b2d0bed0b520d0b8d0bcd18f20d0b8d0b7d0bdd0b0d187d0b0d0bbd18cd0bdd0bed0b3d0be20d181d0bbd0bed0b2d0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000080000004f726967696e616c3402000004000000010000000021000000d098d0b7d0bdd0b0d187d0b0d0bbd18cd0bdd0bed0b520d181d0bbd0bed0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010100050000000b0000005472616e736c6174654944ffffffff0000000000000000000b0000005472616e736c6174654944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000a0000004c616e67756167654944ffffffff0100000000000000000a0000004c616e67756167654944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000b0000004c616e6775616765734944ffffffff0200000000000000000b0000004c616e6775616765734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000090000004c616e67756167657380000000030000000100000000090000004c616e677561676573050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000090000005472616e736c617465cb010000040000000100000000090000005472616e736c617465050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000d800000005010000650000007801000000');
INSERT INTO "NewNavadvipa"."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvActionList.fmvActionList.ini', '\x002c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff68000000680000001a020000d3010000060000005461686f6d61080000ff080000000100000000ff0000000000000400000000000000000000000000000000');
INSERT INTO "NewNavadvipa"."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvExplorer.fmvExplorer.ini', '\x032c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff0d00000083000000be040000c4030000060000005461686f6d61080000ff080000000100000000ff0000000000002c000000000047405860436056604d60000000005980558000000000000000000000000041c041e0000054400000464072004540466051407a607b60000041600000000000007a4000000000000000000000000000000000000000000000000001000000001e0000000100000000000000000000000000000000000000005a00000000000000430000000000000000000000000000000000000000000000000000000000000000000000070000000000000000000800000000000000952800000000000000005b000000000000009a00000000000000000000000000000000000000000000000000000000000000000000000200000000000000000100000000000101010000000000060000005461686f6d61080000ff08000000010000000004000000060000005461686f6d61080000ff080000000100000000050000ff01010101010b00000009000000497344656c657465643e00000000000000010000000012000000d0a3d0b4d0b0d0bbd191d0bd20d0bbd0b83f050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff080000000100000000060000005573657249445e00000001000000010000000006000000557365724944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000040000004e616d65c400000002000000010000000011000000d09bd0bed0b3d0b8d0bd20d0b8d0bcd18f050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000040000004e6f74658f00000003000000010000000016000000d09ad0bed0bcd0bcd0b5d0bdd182d0b0d180d0b8d0b9050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000a000000416e6b6574612e46494f5c02000004000000010000000026000000d0a4d0b0d0bcd0b8d0bbd0b8d18f20d098d0bcd18f20d09ed182d187d0b5d181d182d0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000a000000416e6b6574612e494e4e640000000500000001000000003a000000d098d0bdd0b4d0b8d0b2d0b8d0b4d183d0b0d0bbd18cd0bdd18bd0b920d0bdd0b0d0bbd0bed0b3d0bed0b2d18bd0b920d0bdd0bed0bcd0b5d180050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000f000000416e6b6574612e50617373706f72744c0000000600000001000000000e000000d09fd0b0d181d0bfd0bed180d182050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000017000000416e6b6574612e50617373706f72744b656d567964616e6400000007000000010000000020000000d09ad0b5d0bc20d0b2d18bd0b4d0b0d0bd20d0bfd0b0d181d0bfd0bed180d182050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000013000000416e6b6574612e50617373706f7274446174657a00000008000000010000000026000000d094d0b0d182d0b020d0b2d18bd0b4d0b0d187d0b820d0bfd0b0d181d0bfd0bed180d182d0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000090000004269727468446174656400000009000000010000000009000000426972746844617465050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000a00000043726561746544617465640000000a00000001000000000a00000043726561746544617465050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101050000000600000041637475616c1e00000000000000010000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff01000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff020000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000456e74697479d60000000300000001000000000a000000d0a2d0bed0b2d0b0d180050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000500000050726963654000000004000000010000000008000000d0a6d0b5d0bdd0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff01010101010a0000000600000041637475616cffffffff00000000000000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff01000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff020000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000456e746974794e01000003000000010000000008000000d0a6d0b2d0b5d182050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000b000000456e756d4c69746572616c5a0000000400000001000000000e000000d09bd0b8d182d0b5d180d0b0d0bb050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000b000000566563746f72496e6465783c0000000500000001000000000c000000d098d0bdd0b4d0b5d0bad181050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000008000000466f6e436f6c6f724000000006000000010000000011000000d0a6d0b2d0b5d18220d184d0bed0bdd0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000009000000466f6e74436f6c6f724900000007000000010000000015000000d0a6d0b2d0b5d18220d188d180d0b8d184d182d0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000c000000466f6e436f6c6f7255736572850000000800000001000000002a000000d0a6d0b2d0b5d18220d184d0bed0bdd0b020d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000d000000466f6e74436f6c6f7255736572930000000900000001000000002e000000d0a6d0b2d0b5d18220d188d180d0b8d184d182d0b020d0bfd0bed0bbd18cd0b7d0bed0b2d0b0d182d0b5d0bbd18f050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff01010101010600000008000000456e746974794944ffffffff00000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff010000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000600000041637475616cffffffff02000000000000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000006000000456e746974792f0100000300000001000000000a000000d09fd180d0b0d0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000070000004c69746572616c570000000400000001000000000e000000d09bd0b8d182d0b5d180d0b0d0bb050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000b000000566563746f72496e6465785e0000000500000001000000000c000000d098d0bdd0b4d0b5d0bad181050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff01010101010400000008000000456e746974794944ffffffff00000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004b696e644944ffffffff010000000000000000060000004b696e644944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000600000041637475616c4c00000002000000010000000018000000d090d0bad182d183d0b0d0bbd18cd0bdd0bed181d182d18c050000ff0f0000ff0900000057696e6764696e6773080000ff080000000200000000060000005461686f6d61080000ff08000000010000000006000000456e746974799001000003000000010000000008000000d0a0d0bed0bbd18c050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101040000000c000000526f6c655269676874734944ffffffff0000000000000000000c000000526f6c655269676874734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000526f6c654944ffffffff01000000000000000006000000526f6c654944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff02000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000005269676874bd0100000300000001000000000a000000d09fd180d0b0d0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101050000000c000000557365725269676874734944ffffffff0000000000000000000c000000557365725269676874734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000557365724944ffffffff01000000000000000006000000557365724944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff02000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000004973506c75734200000003000000010000000013000000d09fd0bbd18ed1812dd09cd0b8d0bdd183d181050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff0800000001000000000500000052696768747f0100000400000001000000000a000000d09fd180d0b0d0b2d0be050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101040000000b00000055736572526f6c65734944ffffffff0000000000000000000b00000055736572526f6c65734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000006000000557365724944ffffffff01000000000000000006000000557365724944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000008000000456e746974794944ffffffff02000000000000000008000000456e746974794944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff08000000010000000004000000526f6c65a801000003000000010000000008000000d0a0d0bed0bbd18c050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000050000ff0101010101030000000b0000004c616e6775616765734944ffffffff0000000000000000000b0000004c616e6775616765734944050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000110000004c616e677561676573537472696e674944720000000100000001000000001d000000d0a1d182d180d0bed0bad0bed0b2d0b0d18f20d0bcd0b5d182d0bad0b0050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000090000004c616e677561676573fc00000002000000010000000008000000d0afd0b7d18bd0ba050000ff0f0000ff060000005461686f6d61080000ff080000000100000000060000005461686f6d61080000ff080000000100000000bd0000000a00000031323334353637383930290100005b010000ff01000003');
INSERT INTO "NewNavadvipa"."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TfmvJayaShrilaPrabhupada.fmvJayaShrilaPrabhupada.ini', '\x012c0000002c0000000000000001000000ffffffffffffffffffffffffffffffff0d0000000d000000b402000085000000060000005461686f6d61080000ff080000000100000000ff0000000000000e000000714000007b2000000000000000007a007a407b40786078404c40000000000000010000000000000001');
INSERT INTO "NewNavadvipa"."UserReg" ("UserRegKey", "UserData") VALUES ('Navadvipa Chandra das-JayaShrilaPrabhupada-TdmvNewNavadvipa.dmvNewNavadvipa.ini', '\x0000000000000000007f00000000000000ffffd20000000000caff950000000000ffff240000000000bcffc500000000008ac9fd000000000048ff480000000000fcfeb800ff000000ffff00008000ff00a4ffd100ffff00000000ff0000000000c0ffc000ff000000ffffff00ff000000ffffff0000000000eeeeee000000ff00ffffff0000000000ffffff0000800000ffffff00ff000000ffff00000000ff00ffff00000000ff0000ff000000000000ffffff00000000001cffc500ff00000062ffff00000000001cffc50000000000ffecff0000000000eaea0000ffffff008080ff00ff00ff00ffff800000000000e6ffff00ff000000ffffff000000ff00ffffff00ff000000ffffff00ff000000b7fea500ff000000ffff0000ff0000001cffc50080404000bbffc100ff000000bbffc1000000ff0062ffff000000ff00ddffff00ff000000ddffff0000000000ffffff000000000080ffff00ff00ff00ffecd900ff000000cbfe010000000000d3f3fe00ff000000dfdfff008000ff0000ffff000000ff00ffffff00ff000000ffffff00ff00ff00ffffff0000000000ffffff00ffff0000ff0000008000000072a0f8000000000084ffff00ffffff00ff00000000000000d9d9ff000000ff00ffffff00ff000000ffffff0000800000ffffff00ff000000ffff00000000ff00d9ffff0000000000ffff00000000ff0000ffff00ff000000ffff000000800000ffff000000000000ffff0000ff000000ffff00000000ff00a3fca0000000000080ff80000000ff00bff5f900ffffff008000ff0000000000e9ffca00ff000000ffff000000800000ffffff00ffffff00ff008000ff000000ffff0000ff000000b7ffb700ff0000009fffff0000808000ffaa5500ffff0000ff0000000000b900ddbbff000000ff00ffeaff000000ff00ffd2ff000000ff00ffb7ff000000ff00ffa4ff00ffffff00ff000000ff000000ffc68c00ff000000ffff000000800000ffff00000000ff00ffff0000ffff0000008000000000ff00ffff0000ffff0000ff0000000000ff0055ff5500ffff0000ff0000000000ff00ffffff00ffff0000ff0000000000ff0059e1f900ff000000ffc68c0000800000ffe1c4000000df009fffff00ff000000ffc68c0000000000c0c0c000ff000000ffc68c00ff000000ffc68c00ff000000ffff0000ffff00000000ff00ff000000ffe8ff000000000093ffff0000000000ddffdd0000000000aeffae00ffff00000000ff000000000079ff79000000000000ff00000000000000d700000000ff0000ffff00ffff00000000ff00ff000000ffff0000ff000000ffc68c0000000000ffffff00ffff0000ff0000000080c00080ff800000800000ffff8000ff000000ffffff00008000009efe9e00ffff0000ff000000ffff0000ff000000ffff00000000000000000000000001000000000001010100000000000000000000010000000000010101000000000500000050726963650000010000000000010101000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000000000000001000000000001010100000000000000000000010000000000010101000000000000000000000100000000000101010000000000');


--
-- Data for Name: UserRights; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (4, 1, 153, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (5, 4, 154, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (6, 4, 153, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (7, 9, 154, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (8, 9, 153, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (2, 3, 154, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (3, 3, 153, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (9, 5, 154, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (10, 7, 152, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (11, 7, 153, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (13, 5, 176, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (14, 5, 153, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (15, 5, 174, true);
INSERT INTO "NewNavadvipa"."UserRights" ("UserRightsID", "UserID", "EntityID", "IsPlus") VALUES (12, 7, 177, true);


--
-- Data for Name: UserRoles; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (3, 9, 155);
INSERT INTO "NewNavadvipa"."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (1, 1, 162);
INSERT INTO "NewNavadvipa"."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (2, 1, 156);
INSERT INTO "NewNavadvipa"."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (4, 3, 162);
INSERT INTO "NewNavadvipa"."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (5, 3, 156);
INSERT INTO "NewNavadvipa"."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (6, 5, 156);
INSERT INTO "NewNavadvipa"."UserRoles" ("UserRolesID", "UserID", "EntityID") VALUES (15, 7, 187);


--
-- Data for Name: Users; Type: TABLE DATA; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

INSERT INTO "NewNavadvipa"."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (7, 'Navadvipa Chandra das', 'Шримад Бхагаватам', false, NULL, '2022-04-11 21:14:10', NULL);
INSERT INTO "NewNavadvipa"."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (4, 'Борис', 'Бхагавад Гита как она есть', true, NULL, '1833-12-30 22:22:22', NULL);
INSERT INTO "NewNavadvipa"."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (1, 'Мыкыта', 'Шри Брихад Бхагаватамрита', true, NULL, NULL, NULL);
INSERT INTO "NewNavadvipa"."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (3, 'Мыкола', 'Шри Ишопанишад', false, NULL, NULL, NULL);
INSERT INTO "NewNavadvipa"."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (9, 'Petro', 'Харибол!', false, '2022-04-19 18:02:33', NULL, NULL);
INSERT INTO "NewNavadvipa"."Users" ("UserID", "Name", "Note", "IsDeleted", "BirthDate", "CreateDate", "Anketa") VALUES (5, 'Петро', 'Харе Кришна!', false, '2019-07-24 21:28:02', NULL, NULL);


--
-- Name: Entity_EntityID_seq; Type: SEQUENCE SET; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('"NewNavadvipa"."Entity_EntityID_seq"', 10389, true);


--
-- Name: Kind_KindID_seq; Type: SEQUENCE SET; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('"NewNavadvipa"."Kind_KindID_seq"', 117, true);


--
-- Name: Languages_LanguagesID_seq; Type: SEQUENCE SET; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('"NewNavadvipa"."Languages_LanguagesID_seq"', 5, true);


--
-- Name: RoleRights_RoleRightsID_seq; Type: SEQUENCE SET; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('"NewNavadvipa"."RoleRights_RoleRightsID_seq"', 27, true);


--
-- Name: Translate_TranslateID_seq; Type: SEQUENCE SET; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('"NewNavadvipa"."Translate_TranslateID_seq"', 28252, true);


--
-- Name: UserRights_UserRightsID_seq; Type: SEQUENCE SET; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('"NewNavadvipa"."UserRights_UserRightsID_seq"', 15, true);


--
-- Name: UserRoles_UserRolesID_seq; Type: SEQUENCE SET; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('"NewNavadvipa"."UserRoles_UserRolesID_seq"', 15, true);


--
-- Name: Users_UserID_seq; Type: SEQUENCE SET; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

SELECT pg_catalog.setval('"NewNavadvipa"."Users_UserID_seq"', 10, true);


--
-- Name: ColorKind ColorKind_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."ColorKind"
    ADD CONSTRAINT "ColorKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Color Color_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Color"
    ADD CONSTRAINT "Color_pkey" PRIMARY KEY ("EntityID");


--
-- Name: CommodKind CommodKind_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."CommodKind"
    ADD CONSTRAINT "CommodKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Commod Commod_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Commod"
    ADD CONSTRAINT "Commod_pkey" PRIMARY KEY ("EntityID");


--
-- Name: Entity Entity_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Entity"
    ADD CONSTRAINT "Entity_pkey" PRIMARY KEY ("EntityID");


--
-- Name: Color EnumLiteralUN; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Color"
    ADD CONSTRAINT "EnumLiteralUN" UNIQUE ("EnumLiteral");


--
-- Name: Kind Kind_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Kind"
    ADD CONSTRAINT "Kind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Language LanguageKindID_Entity_UN; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Language"
    ADD CONSTRAINT "LanguageKindID_Entity_UN" UNIQUE ("KindID", "Entity");


--
-- Name: LanguageKind LanguageKind_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."LanguageKind"
    ADD CONSTRAINT "LanguageKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Language Language_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Language"
    ADD CONSTRAINT "Language_pkey" PRIMARY KEY ("EntityID");


--
-- Name: Translate LanguagesCK; Type: CHECK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE "NewNavadvipa"."Translate"
    ADD CONSTRAINT "LanguagesCK" CHECK (("LanguagesID" > 1)) NOT VALID;


--
-- Name: Languages Languages_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Languages"
    ADD CONSTRAINT "Languages_pkey" PRIMARY KEY ("LanguagesID");


--
-- Name: Kind ParentKind; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Kind"
    ADD CONSTRAINT "ParentKind" UNIQUE ("ParentID", "Kind");


--
-- Name: RightsKind RightsKind_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RightsKind"
    ADD CONSTRAINT "RightsKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: Rights Rights_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Rights"
    ADD CONSTRAINT "Rights_pkey" PRIMARY KEY ("EntityID");


--
-- Name: RoleKind RoleKind_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RoleKind"
    ADD CONSTRAINT "RoleKind_pkey" PRIMARY KEY ("KindID");


--
-- Name: RoleRights RoleRights_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RoleRights"
    ADD CONSTRAINT "RoleRights_pkey" PRIMARY KEY ("RoleRightsID");


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY ("EntityID");


--
-- Name: Translate Translate_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Translate"
    ADD CONSTRAINT "Translate_pkey" PRIMARY KEY ("TranslateID");


--
-- Name: UserReg UserReg_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."UserReg"
    ADD CONSTRAINT "UserReg_pkey" PRIMARY KEY ("UserRegKey");


--
-- Name: UserRights UserRights_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."UserRights"
    ADD CONSTRAINT "UserRights_pkey" PRIMARY KEY ("UserRightsID");


--
-- Name: UserRoles UserRoles_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."UserRoles"
    ADD CONSTRAINT "UserRoles_pkey" PRIMARY KEY ("UserRolesID");


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY ("UserID");


--
-- Name: ColorKind ColorKindParentFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."ColorKind"
    ADD CONSTRAINT "ColorKindParentFK" FOREIGN KEY ("ParentID") REFERENCES "NewNavadvipa"."ColorKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Commod CommodKindFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Commod"
    ADD CONSTRAINT "CommodKindFK" FOREIGN KEY ("KindID") REFERENCES "NewNavadvipa"."CommodKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: CommodKind CommodKindParentFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."CommodKind"
    ADD CONSTRAINT "CommodKindParentFK" FOREIGN KEY ("ParentID") REFERENCES "NewNavadvipa"."CommodKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Entity KindFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Entity"
    ADD CONSTRAINT "KindFK" FOREIGN KEY ("KindID") REFERENCES "NewNavadvipa"."Kind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Kind KindParent_fk; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Kind"
    ADD CONSTRAINT "KindParent_fk" FOREIGN KEY ("ParentID") REFERENCES "NewNavadvipa"."Kind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Translate LanguageFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Translate"
    ADD CONSTRAINT "LanguageFK" FOREIGN KEY ("LanguageID") REFERENCES "NewNavadvipa"."Language"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Language LanguageKindFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Language"
    ADD CONSTRAINT "LanguageKindFK" FOREIGN KEY ("KindID") REFERENCES "NewNavadvipa"."LanguageKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: LanguageKind LanguageKindParentFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."LanguageKind"
    ADD CONSTRAINT "LanguageKindParentFK" FOREIGN KEY ("ParentID") REFERENCES "NewNavadvipa"."LanguageKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Translate LanguagesFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Translate"
    ADD CONSTRAINT "LanguagesFK" FOREIGN KEY ("LanguagesID") REFERENCES "NewNavadvipa"."Languages"("LanguagesID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Rights RightsKindFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Rights"
    ADD CONSTRAINT "RightsKindFK" FOREIGN KEY ("KindID") REFERENCES "NewNavadvipa"."RightsKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: RightsKind RightsKindParentFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RightsKind"
    ADD CONSTRAINT "RightsKindParentFK" FOREIGN KEY ("ParentID") REFERENCES "NewNavadvipa"."RightsKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: Role RoleKindFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."Role"
    ADD CONSTRAINT "RoleKindFK" FOREIGN KEY ("KindID") REFERENCES "NewNavadvipa"."RoleKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: RoleKind RoleKindParentFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RoleKind"
    ADD CONSTRAINT "RoleKindParentFK" FOREIGN KEY ("ParentID") REFERENCES "NewNavadvipa"."RoleKind"("KindID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: RoleRights RoleRightsRightsFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RoleRights"
    ADD CONSTRAINT "RoleRightsRightsFK" FOREIGN KEY ("EntityID") REFERENCES "NewNavadvipa"."Rights"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: RoleRights RoleRightsRoleFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."RoleRights"
    ADD CONSTRAINT "RoleRightsRoleFK" FOREIGN KEY ("RoleID") REFERENCES "NewNavadvipa"."Role"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: UserRights UserRightsRightsFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."UserRights"
    ADD CONSTRAINT "UserRightsRightsFK" FOREIGN KEY ("EntityID") REFERENCES "NewNavadvipa"."Rights"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: UserRights UserRightsUsersFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."UserRights"
    ADD CONSTRAINT "UserRightsUsersFK" FOREIGN KEY ("UserID") REFERENCES "NewNavadvipa"."Users"("UserID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: UserRoles UserRolesRoleFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."UserRoles"
    ADD CONSTRAINT "UserRolesRoleFK" FOREIGN KEY ("EntityID") REFERENCES "NewNavadvipa"."Role"("EntityID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: UserRoles UserRolesUsersFK; Type: FK CONSTRAINT; Schema: NewNavadvipa; Owner: Navadvipa Chandra das
--

ALTER TABLE ONLY "NewNavadvipa"."UserRoles"
    ADD CONSTRAINT "UserRolesUsersFK" FOREIGN KEY ("UserID") REFERENCES "NewNavadvipa"."Users"("UserID") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- PostgreSQL database dump complete
--

