﻿//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "FMX_NNFmDB.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "FMX_NNConfig"
#pragma link "FMX_NNFlagBox"
#pragma link "FMX_NNFmRes"
#pragma link "FMX_NNLanguageManager"
#pragma link "FMX_NNRightsManager"
#pragma resource "*.fmx"
TfmfRes3 *fmfRes3;
//---------------------------------------------------------------------------
__fastcall TfmfRes3::TfmfRes3(TComponent* Owner)
  : inherited( Owner )
{
}
//---------------------------------------------------------------------------

void __fastcall TfmfRes3::dsDataDataChange(TObject *Sender, TField *Field)
{
  TDataSet *ds = DataSet;
  if ( ds ) {
    edDBStatus->Text = NNF::DataSetStateToStr( dsData->State ) + NNFConst::Space +
                       String( ds->RecNo ) + NNFConst::AltDelimeter +
                       String( ds->RecordCount );
  }
}
//---------------------------------------------------------------------------
