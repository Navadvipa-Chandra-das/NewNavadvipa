// ---------------------------------------------------------------------------

#ifndef VCL_NNClipboardH
#define VCL_NNClipboardH
// ---------------------------------------------------------------------------

namespace NNV {

  PACKAGE enum TClipboardMode {
    cmRead, cmWrite
  };

  class PACKAGE TClipboardStream : public TMemoryStream {
  private:
    typedef TMemoryStream inherited;
    TClipboardMode FMode;
    Word FFormat;

  public:
    __fastcall TClipboardStream(Word Format, TClipboardMode Mode);
    __fastcall ~TClipboardStream();
  };

}

#endif
