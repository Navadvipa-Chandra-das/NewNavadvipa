// ---------------------------------------------------------------------------

#ifndef FMX_NNFormHistoryH
#define FMX_NNFormHistoryH
// ---------------------------------------------------------------------------

#include "NNNavHistory.h"
#include "NNNavCycle.h"
#include "FMX_NNCommon.h"

namespace NNF {

  typedef PACKAGE void __fastcall ( *TFormActiveProc )( TCommonCustomForm* );
  typedef PACKAGE NN::TNavHistory< TCommonCustomForm*, TFormActiveProc > TFormHistory;
  typedef PACKAGE NN::TNavCycle< TCommonCustomForm*, TFormActiveProc > TFormCycle;

  extern PACKAGE TFormHistory FormHistory;
  extern PACKAGE TFormCycle FormCycle;

}

#endif
