# NizhnyayaNavadvipa
 Библиотеки VCL_NewNavadvipa и FMX_NewNavadvipa для C++Builder
 Для ясного понимания работы компонентов, нужно скачать примеры TestVCL и TestFMX
