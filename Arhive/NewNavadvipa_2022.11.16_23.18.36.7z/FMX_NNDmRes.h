﻿//---------------------------------------------------------------------------

#ifndef FMX_NNDmResH
#define FMX_NNDmResH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include "FMX_NNDBMiracle.h"
#include "FMX_NNLanguageManager.h"
#include "FMX_NNRightsManager.h"
#include "FMX_NNConst.h"
#include "FMX_NNStrUtil.h"
//---------------------------------------------------------------------------
class TdmfRes : public TDataModule
{
__published:	// IDE-managed Components
  TNNFConfig *coData;
  TNNFRight *rrData;
  TNNFLanguage *lnData;
  void __fastcall dmfResCreate(TObject *Sender);
  void __fastcall dmfResDestroy(TObject *Sender);
  void __fastcall BoolGalkaGetText( TField *Sender, UnicodeString &Text, bool DisplayText );
  void __fastcall BoolPlusMinusGetText( TField *Sender, UnicodeString &Text, bool DisplayText );
  void __fastcall NationalNumdecGetText( TField *Sender, UnicodeString &Text
                                       , bool DisplayText);
  void __fastcall ClearDateSetText( TField *Sender, const UnicodeString Text );
  void __fastcall coDataGetFiler( TObject *Sender, TNNFTextStream *&Filer );
  void __fastcall MemoStringGetText( TField *Sender, UnicodeString &Text, bool DisplayText );
private:	// User declarations
  typedef TDataModule inherited;
protected:
  virtual void __fastcall Loaded();
public:		// User declarations
  __fastcall TdmfRes(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TdmfRes *dmfRes;
//---------------------------------------------------------------------------
#endif
