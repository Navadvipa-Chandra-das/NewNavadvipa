// ---------------------------------------------------------------------------

#ifndef VCL_NNFormHistoryH
#define VCL_NNFormHistoryH
// ---------------------------------------------------------------------------

#include "NNNavHistory.h"
#include "NNNavCycle.h"
#include "VCL_NNCommon.h"

namespace NNV {

  typedef PACKAGE void __fastcall ( *TFormActiveProc )( TCustomForm* );
  typedef PACKAGE NN::TNavHistory< TCustomForm*, TFormActiveProc > TFormHistory;
  typedef PACKAGE NN::TNavCycle< TCustomForm*, TFormActiveProc > TFormCycle;

  extern PACKAGE TFormHistory FormHistory;
  extern PACKAGE TFormCycle FormCycle;

}

#endif
