﻿//---------------------------------------------------------------------------

#ifndef FMX_NNDmvNewNavadvipaH
#define FMX_NNDmvNewNavadvipaH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include "FMX_NNDmRes.h"
#include "FMX_NNConfig.h"
#include "FMX_NNLanguageManager.h"
#include "FMX_NNRightsManager.h"
#include "FMX_NNColor.h"
#include <FMX.ImgList.hpp>
#include <System.ImageList.hpp>
//---------------------------------------------------------------------------
class TdmfNewNavadvipa : public TdmfRes
{
__published:	// IDE-managed Components
  TImageList *ilDB;
private:	// User declarations
  typedef TdmfRes inherited;
  NNF::TColorVector FColorVector;
public:		// User declarations
  __fastcall TdmfNewNavadvipa( TComponent* Owner );
  __property NNF::TColorVector ColorVector = { read = FColorVector };
};
//---------------------------------------------------------------------------
extern PACKAGE TdmfNewNavadvipa *dmfNewNavadvipa;
//---------------------------------------------------------------------------
#endif
