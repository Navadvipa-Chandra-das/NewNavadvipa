﻿//---------------------------------------------------------------------------

#ifndef FMX_NNDmResH
#define FMX_NNDmResH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include "FMX_NNConfig.h"
#include "FMX_NNLanguageManager.h"
#include "FMX_NNRightsManager.h"
//---------------------------------------------------------------------------
class TdmfRes : public TDataModule
{
__published:	// IDE-managed Components
  TNNFConfig *coData;
  TNNFRight *rrData;
  TNNFLanguage *lnData;
private:	// User declarations
public:		// User declarations
  __fastcall TdmfRes(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TdmfRes *dmfRes;
//---------------------------------------------------------------------------
#endif
