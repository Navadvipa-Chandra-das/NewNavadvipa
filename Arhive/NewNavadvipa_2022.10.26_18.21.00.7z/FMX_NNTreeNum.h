//---------------------------------------------------------------------------

#ifndef FMX_NNTreeNumH
#define FMX_NNTreeNumH
//---------------------------------------------------------------------------
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
//---------------------------------------------------------------------------
class PACKAGE TNNFTreeNum : public TComponent
{
private:
protected:
public:
	__fastcall TNNFTreeNum(TComponent* Owner);
__published:
};
//---------------------------------------------------------------------------
#endif
