//---------------------------------------------------------------------------

#include <System.hpp>
#pragma hdrstop
USEFORM("FMX_NNFmActionList.cpp", fmfActionList);
USEFORM("FMX_NNFmRes.cpp", fmfRes);
USEFORM("FMX_NNDmRes.cpp", dmfRes); /* TDataModule: File Type */
USEFORM("FMX_NNDmvNewNavadvipa.cpp", dmfNewNavadvipa); /* TDataModule: File Type */
USEFORM("FMX_NNFmDB.cpp", fmfRes3);
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------


#pragma argsused
extern "C" int _libmain(unsigned long reason)
{
	return 1;
}
//---------------------------------------------------------------------------
