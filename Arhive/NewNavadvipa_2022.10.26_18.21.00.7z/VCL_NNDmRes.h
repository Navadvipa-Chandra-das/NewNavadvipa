// ---------------------------------------------------------------------------

#ifndef VCL_NNDmResH
#define VCL_NNDmResH
// ---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include "VCL_NNConfig.h"
#include "VCL_NNRightsManager.h"
#include "VCL_NNLanguageManager.h"

// ---------------------------------------------------------------------------
class TdmvRes : public TDataModule {
__published: // IDE-managed Components
  TNNVConfig *coData;
  TNNVRight *rrData;
  TNNVLanguage *lnData;
  void __fastcall BoolGalkaGetText( TField *Sender, UnicodeString &Text, bool DisplayText );
  void __fastcall BoolPlusMinusGetText( TField *Sender, UnicodeString &Text, bool DisplayText );
  void __fastcall dmvResCreate( TObject *Sender );
  void __fastcall dmvResDestroy( TObject *Sender );
  void __fastcall NationalNumdecGetText( TField *Sender, UnicodeString &Text
                                       , bool DisplayText);
  void __fastcall ClearDateSetText( TField *Sender, const UnicodeString Text );
  void __fastcall coDataGetFiler( TObject *Sender, TNNVTextStream *&Filer );
  void __fastcall MemoStringGetText( TField *Sender, UnicodeString &Text, bool DisplayText );
private: // User declarations
  typedef TDataModule inherited;
protected:
  virtual void __fastcall Loaded();
public: // User declarations
  __fastcall TdmvRes( TComponent* Owner );
};

// ---------------------------------------------------------------------------
extern PACKAGE TdmvRes *dmvRes;
// ---------------------------------------------------------------------------
#endif
